# PHBAI Panel

A Minecraft server hosting panel. Users create Paper, Spigot, Purpur, Fabric, Forge or Vanilla servers that run in Docker,
manage files and plugins in the browser, and earn coins for more resources. Servers can run on this machine or on other
machines ("nodes").

## Install

You need a Linux machine with Docker (the installer adds it if it is missing).

```bash
bash install.sh
```

It creates `.env` (random session secret), starts the panel with `docker compose`, and offers to create the first
administrator. To do it without questions:

```bash
bash install.sh --admin-user admin --admin-pass 'a-long-password'
```

Open `http://YOUR_SERVER:5001`.

**One-line install from GitHub** (after you push this folder to your own repository, replace OWNER/REPO):

```bash
curl -sSL https://raw.githubusercontent.com/OWNER/REPO/main/install.sh | bash -s -- --repo https://github.com/OWNER/REPO.git
```

Manual install: `docker compose up -d --build`, then open the panel (the first visit shows a setup page for the admin).

## Users from the terminal

```bash
docker compose exec phpanel node scripts/user.js add NAME PASSWORD            # normal user
docker compose exec phpanel node scripts/user.js add NAME PASSWORD --admin    # administrator
docker compose exec phpanel node scripts/user.js list
docker compose exec phpanel node scripts/user.js passwd NAME NEWPASSWORD
docker compose exec phpanel node scripts/user.js admin NAME      # promote
docker compose exec phpanel node scripts/user.js demote NAME
docker compose exec phpanel node scripts/user.js limits NAME 4 100   # RAM GB, CPU % (100 = 1 core)
docker compose exec phpanel node scripts/user.js delete NAME
```

Without Docker use `npm run user -- add NAME PASSWORD --admin`.

## Limits

New users get **4 GB RAM and 1 CPU** in total, every server gets **10 GB disk** (all changeable in *Settings*, they only
affect new accounts and servers). A server cannot be created when the RAM or CPU pool is used up. Admins have no limits.
Disk is checked when a server starts: it will not start if its files are bigger than its limit.

## Nodes (run servers on other machines)

1. Panel → **Nodes** → type a name → **Add node**.
2. The panel shows a command. Run it on the other Linux machine:

```bash
curl -sSL https://YOUR_PANEL/install/agent.sh | sudo bash -s -- --panel https://YOUR_PANEL --key KEY --name 'Germany-1'
```

It installs Node.js and Docker if needed, downloads the agent from the panel and runs it as a service. The agent connects
**out** to the panel, so the node needs no open port for the panel (open the Minecraft ports you give your servers).
Use HTTPS for the panel when the node is on another network. The key is shown once; **New key** makes a fresh one.

## What users can do

* **Console, Files, Plugins, Players, Startup, Version, Backups** in every server window.
* **Files**: edit files, make folders, and **upload files or whole folders** from your computer (buttons, or drag & drop
  into the window; folder structure is kept). Max 500 MB per file (`MAX_UPLOAD_MB` in `.env` changes it). If the panel sits
  behind Cloudflare's free plan, Cloudflare itself limits uploads to 100 MB.
* **Start** runs in the background: the server shows *Starting…* (the first start downloads the game image, a few
  minutes) and you get a message when it is online, or the exact reason when it fails. The last failure also stays visible
  in the server window.
* **Plugins**: search and install from **Modrinth** and **Spigot**, filtered for the server's software and version.
* **Startup**: MOTD, max players, online mode, extra Java flags. **Version**: change software and Minecraft version.
* **AFK**: claim coins once every 24 hours (amount and interval in Settings). Admins can add a Google AdSense ad there.
* Admins see only their own servers on *Servers*. *All Servers* is a moderation list (stop, delete). Consoles and files of
  other people stay private, even from admins.

## Notes

* Minecraft 26.x needs Java 25. The panel chooses the right `itzg/minecraft-server` image for every version.
* When the panel runs in Docker, game servers store their files in `./storage/servers`. The panel finds the real host path
  by itself; if it cannot, set `HOST_DATA_DIR` in `.env` to the absolute path of `storage`.
* To pre-download the game image yourself (shows progress): `docker pull itzg/minecraft-server:java21`
  (`java25` for Minecraft 26.x, `java17` for 1.17-1.20.4, `java8-multiarch` for 1.16 and older).
* Set a real `SESSION_SECRET` (the installer does this).
* Tests: `npm test` (unit), `npm run test:e2e`, `npm run test:ui` (the last two start the panel on a spare port with fake
  Docker; they never touch your data).
