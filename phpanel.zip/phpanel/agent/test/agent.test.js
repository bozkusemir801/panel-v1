const assert = require('assert');
const fs   = require('fs');
const os   = require('os');
const path = require('path');
const { cleanSrv, demuxBuffer } = require('../src/agent');
const { safeJoin } = require('../src/safepath');

let n = 0;
const t = (name, fn) => { fn(); n++; console.log('  ok  ' + name); };

/* demux */
const frame = (stream, text) => {
  const b = Buffer.from(text);
  const h = Buffer.alloc(8); h[0] = stream; h.writeUInt32BE(b.length, 4);
  return Buffer.concat([h, b]);
};
t('demuxBuffer strips docker frame headers', () => {
  assert.strictEqual(demuxBuffer(Buffer.concat([frame(1, 'hello\n'), frame(2, 'err\n')])), 'hello\nerr\n');
});
t('demuxBuffer leaves plain text alone', () => {
  assert.strictEqual(demuxBuffer(Buffer.from('plain text here')), 'plain text here');
});

/* validation */
const good = { id: 'abcdef12-3456-7890-abcd-ef1234567890', type: 'paper', version: '1.21.4', port: 25565, ram: 2, cpu: 100 };
t('cleanSrv accepts a valid server', () => {
  const s = cleanSrv(good, true);
  assert.strictEqual(s.containerName, 'phpanel_abcdef12');
  assert.strictEqual(s.port, 25565);
});
t('cleanSrv rejects bad ids / types / versions / numbers', () => {
  assert.throws(() => cleanSrv({ ...good, id: '../etc' }, true));
  assert.throws(() => cleanSrv({ ...good, type: 'evil' }, true));
  assert.throws(() => cleanSrv({ ...good, version: '1.21\nEULA=FALSE' }, true));
  assert.throws(() => cleanSrv({ ...good, port: 70000 }, true));
  assert.throws(() => cleanSrv({ ...good, ram: 0 }, true));
  assert.throws(() => cleanSrv(null));
});

/* path safety */
const tmp  = fs.mkdtempSync(path.join(os.tmpdir(), 'agent-'));
const root = path.join(tmp, 'srv'); fs.mkdirSync(root);
fs.writeFileSync(path.join(tmp, 'secret.txt'), 'top secret');
fs.writeFileSync(path.join(root, 'server.properties'), 'ok');
fs.symlinkSync(tmp, path.join(root, 'escape'));

t('safeJoin allows normal paths', () => {
  assert.strictEqual(safeJoin(root, 'server.properties'), path.join(fs.realpathSync(root), 'server.properties'));
  assert.strictEqual(safeJoin(root, ''), fs.realpathSync(root));
  assert.ok(safeJoin(root, 'plugins/new/file.yml'));       // not existing yet (write)
});
t('safeJoin blocks ../ traversal', () => {
  assert.throws(() => safeJoin(root, '../secret.txt'));
  assert.throws(() => safeJoin(root, '../../../../etc/passwd'));
  assert.throws(() => safeJoin(root, 'a/../../secret.txt'));
});
t('safeJoin blocks symlink escapes', () => {
  assert.throws(() => safeJoin(root, 'escape/secret.txt'));
  assert.throws(() => safeJoin(root, 'escape'));
});

fs.rmSync(tmp, { recursive: true, force: true });
console.log(`\n  ${n} tests passed\n`);
