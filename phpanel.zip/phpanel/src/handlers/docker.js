const Docker = require('dockerode');
const fs     = require('fs');
const os     = require('os');
const path   = require('path');
const { PassThrough } = require('stream');
const config  = require('../config');
const servers = require('./servers');
const nodes   = require('./nodes');
const { TYPES, imageFor } = require('./versions');

const docker = new Docker({ socketPath: config.dockerSocket });

const containerName = (srv) => `phpanel_${srv.id.slice(0, 8)}`;
const GB = 1024 * 1024 * 1024;

// only the fields a node needs
const wire = (srv) => ({ id: srv.id, type: srv.type, version: srv.version, port: srv.port, ram: srv.ram, cpu: srv.cpu, disk: srv.disk, startup: srv.startup });

/** JVM heap is 85% of the RAM limit; the rest is room for the JVM itself, otherwise Docker kills the container. */
const heapMb = (ram) => Math.floor(ram * 1024 * 0.85);

function buildEnv(srv) {
  const st = { ...servers.DEFAULT_STARTUP, ...(srv.startup || {}) };
  const env = [
    'EULA=TRUE',
    `TYPE=${TYPES[srv.type]}`,
    `VERSION=${srv.version}`,
    `MEMORY=${heapMb(srv.ram)}M`,
    `MAX_PLAYERS=${st.maxPlayers}`,
    `ONLINE_MODE=${st.onlineMode ? 'TRUE' : 'FALSE'}`,
    `MOTD=${st.motd}`,
  ];
  if (st.jvmOpts) env.push(`JVM_OPTS=${st.jvmOpts}`);
  return env;
}

/**
 * The Docker daemon resolves bind-mount paths on the HOST. When the panel itself runs in a container,
 * /app/storage is not a host path, so find where it really lives (HOST_DATA_DIR, or ask Docker).
 */
let hostRoot = null;
async function hostDataDir() {
  if (process.env.HOST_DATA_DIR) return process.env.HOST_DATA_DIR;
  if (hostRoot) return hostRoot;
  hostRoot = config.dataDir;
  if (fs.existsSync('/.dockerenv')) {
    try {
      const info = await docker.getContainer(os.hostname()).inspect();
      const m = (info.Mounts || []).find((x) => config.dataDir === x.Destination || config.dataDir.startsWith(x.Destination + '/'));
      if (m) hostRoot = path.join(m.Source, path.relative(m.Destination, config.dataDir));
      else console.warn('[docker] Could not find the storage mount of this container; set HOST_DATA_DIR');
    } catch (e) {
      console.warn('[docker] Could not inspect own container; set HOST_DATA_DIR:', e.message);
    }
  }
  return hostRoot;
}

function dirSize(dir) {
  let total = 0;
  const stack = [dir];
  while (stack.length) {
    const d = stack.pop();
    let entries; try { entries = fs.readdirSync(d); } catch { continue; }
    for (const name of entries) {
      let st; try { st = fs.lstatSync(path.join(d, name)); } catch { continue; }
      if (st.isSymbolicLink()) continue;
      if (st.isDirectory()) stack.push(path.join(d, name)); else total += st.size;
    }
  }
  return total;
}

function checkDisk(dir, limitGb) {
  const used = dirSize(dir);
  if (used > limitGb * GB) throw new Error(`Disk limit reached (${(used / GB).toFixed(1)} of ${limitGb} GB used). Delete some files first.`);
}

/** Docker log buffers (non-TTY) are framed: [stream,0,0,0,size(4 bytes BE)] + payload. */
function demuxBuffer(buf) {
  if (!Buffer.isBuffer(buf)) return String(buf);
  if (buf.length < 8 || buf[0] > 2 || buf[1] !== 0 || buf[2] !== 0 || buf[3] !== 0) return buf.toString('utf8');
  let out = '', i = 0;
  while (i + 8 <= buf.length) {
    const size = buf.readUInt32BE(i + 4);
    out += buf.slice(i + 8, i + 8 + size).toString('utf8');
    i += 8 + size;
  }
  return out;
}
const cleanLine = (s) => s.replace(/[\x00-\x08\x0b\x0c\x0e-\x1f]/g, '').trimEnd();

async function ensureImage(image) {
  try { await docker.getImage(image).inspect(); return; } catch {}
  console.log(`[docker] Pulling ${image} …`);
  await new Promise((res, rej) => {
    docker.pull(image, (err, stream) => {
      if (err) return rej(err);
      docker.modem.followProgress(stream, (e) => (e ? rej(e) : res()));
    });
  });
}

async function removeContainer(name) {
  try { await docker.getContainer(name).remove({ force: true }); }
  catch (e) { if (e.statusCode !== 404) throw e; }
}

/* ───────────────────────── actions ───────────────────────── */
async function startServer(srv) {
  if (srv.nodeId) {
    const r = await nodes.call(srv.nodeId, 'server.start', { srv: wire(srv) }, 15 * 60 * 1000);
    servers.updateStatus(srv.id, 'running', r.containerId);
    return r.containerId;
  }

  const dataDir = path.join(config.dataDir, 'servers', srv.id);
  fs.mkdirSync(dataDir, { recursive: true });
  checkDisk(dataDir, srv.disk);

  const image = imageFor(srv.version);
  await ensureImage(image);
  const name = containerName(srv);
  await removeContainer(name);           // a leftover container would cause "name already in use" (409)

  const hostDir = path.join(await hostDataDir(), 'servers', srv.id);
  const container = await docker.createContainer({
    name,
    Image: image,
    Env: buildEnv(srv),
    ExposedPorts: { '25565/tcp': {} },
    HostConfig: {
      Memory:       srv.ram * GB,
      CpuPeriod:    100000,
      CpuQuota:     srv.cpu * 1000,
      Binds:        [`${hostDir}:/data`],
      PortBindings: { '25565/tcp': [{ HostPort: String(srv.port) }] },
      RestartPolicy: { Name: 'unless-stopped' },
    },
  });
  await container.start();
  servers.updateStatus(srv.id, 'running', container.id);
  return container.id;
}

async function stopServer(srv) {
  if (srv.nodeId) {
    await nodes.call(srv.nodeId, 'server.stop', { srv: wire(srv) }, 60000);
    servers.updateStatus(srv.id, 'offline', null);
    return;
  }
  const c = docker.getContainer(containerName(srv));
  try { await c.stop({ t: 10 }); } catch (e) { if (![304, 404].includes(e.statusCode)) throw e; }
  await removeContainer(containerName(srv));
  servers.updateStatus(srv.id, 'offline', null);
}

async function restartServer(srv) {
  if (srv.nodeId) return nodes.call(srv.nodeId, 'server.restart', { srv: wire(srv) }, 60000);
  await docker.getContainer(containerName(srv)).restart();
}

/** Stop everything and delete the server's files (used when a server is deleted). */
async function destroyServer(srv) {
  if (srv.nodeId) {
    await nodes.call(srv.nodeId, 'server.destroy', { srv: { id: srv.id } }, 60000);
    return;
  }
  await removeContainer(containerName(srv)).catch(() => {});
  fs.rmSync(path.join(config.dataDir, 'servers', srv.id), { recursive: true, force: true });
  fs.rmSync(path.join(config.dataDir, 'backups', srv.id), { recursive: true, force: true });
}

async function getStats(srv) {
  if (srv.nodeId) return nodes.call(srv.nodeId, 'server.stats', { srv: wire(srv) }, 15000).catch(() => null);
  try {
    const st = await docker.getContainer(containerName(srv)).stats({ stream: false });
    const cpuDelta = st.cpu_stats.cpu_usage.total_usage - st.precpu_stats.cpu_usage.total_usage;
    const sysDelta = st.cpu_stats.system_cpu_usage      - st.precpu_stats.system_cpu_usage;
    const cpu = sysDelta > 0 ? (cpuDelta / sysDelta) * (st.cpu_stats.online_cpus || 1) * 100 : 0;
    const ram = (st.memory_stats.usage || 0) / 1024 / 1024;
    return { cpu: cpu.toFixed(1), ram: ram.toFixed(0) };
  } catch { return null; }
}

async function execCommand(srv, cmd) {
  if (typeof cmd !== 'string' || !cmd.trim() || cmd.length > 500) throw new Error('Invalid command');
  if (srv.nodeId) return nodes.call(srv.nodeId, 'server.exec', { srv: wire(srv), cmd }, 30000);
  const exec = await docker.getContainer(containerName(srv)).exec({
    Cmd: ['rcon-cli', cmd], AttachStdout: true, AttachStderr: true, Tty: true,
  });
  const stream = await exec.start({ hijack: true, stdin: false, Tty: true });
  return new Promise((resolve) => {
    let out = '';
    const done = () => resolve(out.trim());
    const timer = setTimeout(() => { try { stream.destroy(); } catch {} done(); }, 15000);
    stream.on('data', (d) => { out += d.toString(); });
    stream.on('end',  () => { clearTimeout(timer); done(); });
    stream.on('error', () => { clearTimeout(timer); done(); });
  });
}

async function getContainerLogs(srv, tail = 50) {
  if (srv.nodeId) return nodes.call(srv.nodeId, 'server.logs', { srv: wire(srv), tail }, 15000).catch(() => []);
  try {
    const buf = await docker.getContainer(containerName(srv)).logs({ stdout: true, stderr: true, tail });
    return demuxBuffer(buf).split('\n').map(cleanLine).filter(Boolean);
  } catch { return []; }
}

/** Live log lines of a local server. Resolves to a function that stops following. */
async function followLogs(srv, onLine) {
  const raw = await docker.getContainer(containerName(srv)).logs({
    follow: true, stdout: true, stderr: true, since: Math.floor(Date.now() / 1000) - 5,
  });
  const out = new PassThrough();
  docker.modem.demuxStream(raw, out, out);
  let pending = '';
  out.on('data', (chunk) => {
    pending += chunk.toString('utf8');
    const lines = pending.split('\n');
    pending = lines.pop();
    for (const l of lines) { const line = cleanLine(l); if (line) onLine(line); }
  });
  return () => { try { raw.destroy(); } catch {} };
}

module.exports = {
  docker, startServer, stopServer, restartServer, destroyServer, getStats, execCommand,
  getContainerLogs, followLogs, buildEnv, demuxBuffer, dirSize, containerName, heapMb,
};
