const fs     = require('fs');
const path   = require('path');
const crypto = require('crypto');
const config = require('../config');
const servers = require('./servers');

const FILE   = path.join(config.dataDir, 'nodes', 'nodes.json');
const online = new Map();   // nodeId -> { socket }
let panelIo  = null;

/* ── persistence ── */
function load() {
  if (!fs.existsSync(FILE)) return [];
  try { return JSON.parse(fs.readFileSync(FILE, 'utf8')); } catch { return []; }
}
function save(list) {
  fs.mkdirSync(path.dirname(FILE), { recursive: true });
  fs.writeFileSync(FILE, JSON.stringify(list, null, 2));
}

/* Tokens are shown once and only their hash is stored. */
const hashToken = (t) => crypto.createHash('sha256').update(String(t)).digest('hex');
const newToken  = () => 'phb_' + crypto.randomBytes(24).toString('hex');

function findByToken(token) {
  if (typeof token !== 'string' || token.length < 8 || token.length > 200) return null;
  const h = Buffer.from(hashToken(token));
  let found = null;
  for (const n of load()) {
    if (!n.tokenHash) continue;
    const x = Buffer.from(n.tokenHash);
    if (x.length === h.length && crypto.timingSafeEqual(x, h)) found = n;
  }
  return found;
}

/* names can come from a remote machine: keep them boring so they can't break the UI */
const cleanName = (s, fb) => String(s || fb || '').replace(/[^\w .\-]/g, '').trim().slice(0, 60) || fb || '';

function patch(id, fields) {
  const list = load();
  const n = list.find((x) => x.id === id);
  if (!n) return null;
  Object.assign(n, fields);
  save(list);
  return n;
}

/* ── admin actions ── */
function create(name) {
  const clean = cleanName(name);
  if (!clean || clean.length < 2) throw new Error('Node name must be at least 2 characters (letters, numbers, space . _ -)');
  if (load().some((n) => n.name.toLowerCase() === clean.toLowerCase())) throw new Error('A node with this name already exists');
  const token = newToken();
  const node = { id: crypto.randomBytes(6).toString('hex'), name: clean, tokenHash: hashToken(token), createdAt: new Date().toISOString() };
  save([...load(), node]);
  return { node: view(node), token };
}

/** New token; the old one stops working at once and a connected agent is dropped. */
function regenerate(id) {
  const token = newToken();
  const n = patch(id, { tokenHash: hashToken(token) });
  if (!n) throw new Error('Node not found');
  const live = online.get(id);
  if (live) { online.delete(id); live.socket.disconnect(true); }
  return { node: view(n), token };
}

function remove(id) {
  const live = online.get(id);
  if (live) { online.delete(id); live.socket.disconnect(true); }
  save(load().filter((x) => x.id !== id));
}

const view = (n) => {
  const { tokenHash, ...rest } = n;
  return { ...rest, online: online.has(n.id), serverCount: servers.list().filter((s) => s.nodeId === n.id).length };
};
const list = () => load().map(view);
const get  = (id) => { const n = load().find((x) => x.id === id); return n ? view(n) : null; };
const isOnline = (id) => online.has(id);

/* ── socket namespace the agents connect to ── */
function attach(io) {
  panelIo = io;
  const ns = io.of('/agent');

  ns.use((socket, next) => {
    const node = findByToken(socket.handshake.auth && socket.handshake.auth.token);
    if (!node) return next(new Error('invalid token'));
    socket.data.nodeId = node.id;
    next();
  });

  ns.on('connection', (socket) => {
    const id = socket.data.nodeId;
    const a  = socket.handshake.auth || {};

    const prev = online.get(id);
    online.set(id, { socket });
    if (prev) prev.socket.disconnect(true);

    patch(id, {
      hostname:     cleanName(a.hostname),
      platform:     cleanName(a.platform),
      agentVersion: cleanName(a.agentVersion),
      lastSeen:     new Date().toISOString(),
    });
    const name = (get(id) || {}).name;
    console.log(`[nodes] "${name}" connected`);

    socket.on('hello', (info) => {
      if (!info || typeof info !== 'object') return;
      patch(id, {
        docker:      info.docker ? cleanName(info.docker) : null,
        dockerError: info.dockerError ? String(info.dockerError).slice(0, 200) : null,
      });
    });

    // live console lines from a remote server -> browsers watching that server
    socket.on('log-line', (msg) => {
      if (!msg || typeof msg.serverId !== 'string' || typeof msg.line !== 'string') return;
      const srv = servers.findById(msg.serverId);
      if (!srv || srv.nodeId !== id) return;   // a node may only speak for its own servers
      panelIo.to(`srv:${msg.serverId}`).emit('log-line', msg.line.slice(0, 2000));
    });

    socket.on('disconnect', () => {
      if (online.get(id) && online.get(id).socket === socket) online.delete(id);
      patch(id, { lastSeen: new Date().toISOString() });
      console.log(`[nodes] "${name}" disconnected`);
    });
  });
}

/* ── ask a node to do something ── */
function call(nodeId, method, params = {}, timeoutMs = 60000) {
  const n = online.get(nodeId);
  if (!n) return Promise.reject(new Error('Node is offline'));
  return new Promise((resolve, reject) => {
    n.socket.timeout(timeoutMs).emit('rpc', { method, params }, (err, res) => {
      if (err) return reject(new Error('Node did not respond in time'));
      if (res && res.error) return reject(new Error(res.error));
      resolve(res ? res.result : undefined);
    });
  });
}

module.exports = { attach, call, list, get, create, regenerate, remove, isOnline };
