const docker  = require('./docker');
const servers = require('./servers');
const nodes   = require('./nodes');

// Only the owner opens a server's console (admins moderate from the All Servers page, they do not read consoles).
function canAccess(socket, srv) {
  const s = socket.request && socket.request.session;
  return !!(s && s.userId && srv.ownerId === s.userId);
}

module.exports = function (io) {
  // The panel's own Socket.IO namespace is only for logged-in browsers
  // (session cookie is shared with Express, see index.js).
  io.use((socket, next) => {
    const s = socket.request && socket.request.session;
    if (s && s.userId) return next();
    next(new Error('unauthorized'));
  });

  // stop the remote log stream once nobody watches that server any more
  function detachIfEmpty(srv) {
    const room = io.sockets.adapter.rooms.get(`srv:${srv.id}`);
    if (!room || room.size === 0) {
      nodes.call(srv.nodeId, 'logs.detach', { srv: { id: srv.id } }, 10000).catch(() => {});
    }
  }

  io.on('connection', (socket) => {

    // Join server console room
    socket.on('join-server', async (serverId) => {
      const srv = servers.findById(serverId);
      if (!srv || !canAccess(socket, srv)) return;
      socket.join(`srv:${serverId}`);
      if (!srv.containerId) return;

      /* ── server running on a remote node ── */
      if (srv.nodeId) {
        try {
          socket.emit('log-history', await docker.getContainerLogs(srv, 100));
          await nodes.call(srv.nodeId, 'logs.attach', { srv: { id: srv.id } }, 15000);
        } catch (e) {
          socket.emit('log-line', `[PHBAI] Could not attach to node: ${e.message}`);
        }
        socket.on('leave-server', () => { socket.leave(`srv:${serverId}`); detachIfEmpty(srv); });
        socket.on('disconnect', () => detachIfEmpty(srv));
        return;
      }

      /* ── local server ── */
      socket.emit('log-history', await docker.getContainerLogs(srv, 100));
      try {
        const stop = await docker.followLogs(srv, (line) => socket.emit('log-line', line));
        socket.on('disconnect', stop);
        socket.on('leave-server', () => { stop(); socket.leave(`srv:${serverId}`); });
      } catch (e) {
        socket.emit('log-line', `[PHBAI] Could not attach to container: ${e.message}`);
      }
    });

    // Execute command
    socket.on('exec-cmd', async ({ serverId, cmd } = {}) => {
      const srv = servers.findById(serverId);
      if (!srv || !canAccess(socket, srv)) return socket.emit('cmd-result', 'Server not found');
      try {
        const out = await docker.execCommand(srv, cmd);
        socket.emit('cmd-result', out || '(no output)');
      } catch (e) {
        socket.emit('cmd-result', `Error: ${e.message}`);
      }
    });
  });
};
