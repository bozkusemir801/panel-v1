/** File operations for a server: on this machine, or on a node through its agent. */
const fs   = require('fs');
const path = require('path');
const config  = require('../config');
const nodes   = require('./nodes');
const plugins = require('./plugins');
const { safeJoin } = require('./safepath');
const { dirSize } = require('./docker');

const MAX_TEXT = 2 * 1024 * 1024;
const rootOf = (id) => path.join(config.dataDir, 'servers', id);

const local = {
  list(root, { path: rel }) {
    const dir = safeJoin(root, rel);
    if (!fs.existsSync(dir) || !fs.statSync(dir).isDirectory()) return [];
    return fs.readdirSync(dir).map((name) => {
      const st = fs.statSync(path.join(dir, name));
      return { name, isDir: st.isDirectory(), size: st.size, mtime: st.mtime };
    });
  },
  read(root, { path: rel }) {
    const p = safeJoin(root, rel);
    if (!fs.existsSync(p) || !fs.statSync(p).isFile()) throw new Error('File not found');
    if (fs.statSync(p).size > MAX_TEXT) throw new Error('File is too large to edit (max 2 MB)');
    const buf = fs.readFileSync(p);
    if (buf.includes(0)) throw new Error('This looks like a binary file and cannot be edited as text');
    return buf.toString('utf8');
  },
  write(root, { path: rel, content }) {
    if (typeof rel !== 'string' || !rel) throw new Error('Path required');
    const text = typeof content === 'string' ? content : '';
    if (Buffer.byteLength(text) > MAX_TEXT) throw new Error('Content is too large (max 2 MB)');
    const p = safeJoin(root, rel);
    fs.mkdirSync(path.dirname(p), { recursive: true });
    fs.writeFileSync(p, text);
    return { ok: true };
  },
  mkdir(root, { path: rel }) {
    if (typeof rel !== 'string' || !rel) throw new Error('Path required');
    fs.mkdirSync(safeJoin(root, rel), { recursive: true });
    return { ok: true };
  },
  delete(root, { path: rel }) {
    if (typeof rel !== 'string' || !rel.replace(/^[/\\]+/, '')) throw new Error('Refusing to delete the server root');
    const p = safeJoin(root, rel);
    if (!fs.existsSync(p)) throw new Error('Not found');
    fs.rmSync(p, { recursive: true, force: true });
    return { ok: true };
  },
  async download(root, { dir, filename, url }) {
    if (!['plugins', 'mods'].includes(dir)) throw new Error('Invalid folder');
    if (!/^[\w .+()\-]{1,100}\.jar$/.test(filename || '')) throw new Error('Invalid file name');
    const target = safeJoin(root, `${dir}/${filename}`);
    fs.mkdirSync(path.dirname(target), { recursive: true });
    await plugins.download(url, target);
    return { ok: true, file: filename };
  },
};

/* ───────── uploads (files and whole folders from the user's computer) ───────── */
const GB = 1024 ** 3;
const MAX_UPLOAD = Math.floor(Number(process.env.MAX_UPLOAD_MB || 500) * 1024 * 1024);   // per file
const CHUNK = 512 * 1024;                                                                  // size of the pieces sent to a node

const usage = new Map();   // serverId -> { size, at }  (a folder with thousands of files must not be re-measured for every file)
function usedBytes(id, root) {
  const c = usage.get(id);
  if (c && Date.now() - c.at < 10000) return c.size;
  const size = dirSize(root);
  usage.set(id, { size, at: Date.now() });
  return size;
}
const addUsage = (id, n) => { const c = usage.get(id); if (c) c.size += n; };

const err = (status, message) => Object.assign(new Error(message), { status });

/** "world/region/r.0.0.mca" -> checked relative path. Rejects "..", empty parts, control characters. */
function cleanUploadPath(rel) {
  if (typeof rel !== 'string' || !rel || rel.length > 1000) throw err(400, 'Invalid upload path');
  const parts = rel.replace(/^\/+/, '').split('/');
  for (const p of parts) if (!p || p === '.' || p === '..' || p.length > 255 || /[\x00-\x1f\\]/.test(p)) throw err(400, 'Invalid file or folder name in the upload');
  return parts.join('/');
}

const mb = (n) => Math.round(n / 1024 / 1024);

/**
 * Stream the request body into <rel> inside the server's folder.
 * Keeps reading (and discarding) after a refusal so the browser can read the error message.
 */
async function upload(srv, rel, req) {
  rel = cleanUploadPath(rel);
  const declared = Number(req.headers['content-length']) || 0;
  const limit = srv.disk * GB;
  let failure = null, size = 0;
  const check = (n) => {
    if (n > MAX_UPLOAD) return err(413, `File is too large (max ${mb(MAX_UPLOAD)} MB per file)`);
    return null;
  };
  failure = check(declared);

  if (srv.nodeId) {                                                     // ── on a node: send it in pieces
    let offset = 0, buf = [], buffered = 0, started = false;
    const send = async (last) => {
      const data = Buffer.concat(buf); buf = []; buffered = 0;
      await nodes.call(srv.nodeId, 'files.upload', { serverId: srv.id, path: rel, offset, data, last, total: declared, limitBytes: limit }, 60000);
      offset += data.length; started = true;
    };
    try {
      for await (const chunk of req) {
        size += chunk.length;
        if (failure) continue;
        failure = check(size);
        if (failure) continue;
        buf.push(chunk); buffered += chunk.length;
        if (buffered >= CHUNK) { try { await send(false); } catch (e) { failure = err(400, e.message); } }
      }
      if (!failure) { try { await send(true); } catch (e) { failure = err(400, e.message); } }
    } catch (e) { failure = failure || err(400, 'Upload was interrupted'); }
    if (failure) { if (started) nodes.call(srv.nodeId, 'files.uploadAbort', { serverId: srv.id, path: rel }, 10000).catch(() => {}); throw failure; }
    return { ok: true, size };
  }

  const root   = rootOf(srv.id);                                        // ── on this machine
  const target = safeJoin(root, rel);
  fs.mkdirSync(path.dirname(target), { recursive: true });
  if (fs.existsSync(target) && fs.statSync(target).isDirectory()) throw err(400, 'A folder with this name already exists');
  const used = usedBytes(srv.id, root);
  const full = () => err(400, `Disk limit reached (${(used / GB).toFixed(1)} of ${srv.disk} GB used). Delete some files first.`);
  if (!failure && declared && used + declared > limit) failure = full();

  const tmp = `${target}.upload-${process.pid}-${Date.now()}`;
  const out = failure ? null : fs.createWriteStream(tmp);
  try {
    for await (const chunk of req) {
      size += chunk.length;
      if (failure) continue;
      failure = check(size) || (used + size > limit ? full() : null);
      if (failure) continue;
      if (!out.write(chunk)) await new Promise((r) => out.once('drain', r));
    }
    if (out) await new Promise((res, rej) => out.end((e) => (e ? rej(e) : res())));
  } catch (e) { failure = failure || err(400, 'Upload was interrupted'); if (out) out.destroy(); }
  if (failure) { fs.rmSync(tmp, { force: true }); throw failure; }
  fs.renameSync(tmp, target);
  addUsage(srv.id, size);
  return { ok: true, size };
}

/** op(srv, 'list' | 'read' | 'write' | 'mkdir' | 'delete' | 'download', params) */
async function op(srv, name, params = {}) {
  if (srv.nodeId) return nodes.call(srv.nodeId, `files.${name}`, { serverId: srv.id, ...params }, name === 'download' ? 150000 : 30000);
  return local[name](rootOf(srv.id), params);
}

module.exports = { op, upload, cleanUploadPath, MAX_UPLOAD };
