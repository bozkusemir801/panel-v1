/**
 * Plugin / mod search and install (Modrinth + Spigot via Spiget).
 * The browser never gives us a URL: we resolve the download URL ourselves from an ID,
 * and only download from known hosts.
 */
const fs   = require('fs');
const { Readable, Transform } = require('stream');
const { pipeline } = require('stream/promises');

const UA = 'PHBAI-Panel/1.0 (minecraft server panel)';
const MODRINTH = (process.env.MODRINTH_API_URL || 'https://api.modrinth.com/v2').replace(/\/+$/, '');
const SPIGET   = (process.env.SPIGET_API_URL   || 'https://api.spiget.org/v2').replace(/\/+$/, '');

const ALLOWED_HOSTS = new Set([
  'cdn.modrinth.com', 'api.modrinth.com', 'api.spiget.org', 'cdn.spiget.org', 'spigotmc.org', 'www.spigotmc.org',
]);
const BASE_ORIGINS = [MODRINTH, SPIGET].map((b) => new URL(b).origin);
const MAX_BYTES = 100 * 1024 * 1024;

const FOLDER  = { paper: 'plugins', spigot: 'plugins', purpur: 'plugins', fabric: 'mods', forge: 'mods' };
const LOADERS = {
  paper:  ['paper', 'spigot', 'bukkit'],
  spigot: ['spigot', 'bukkit'],
  purpur: ['purpur', 'paper', 'spigot', 'bukkit'],
  fabric: ['fabric'],
  forge:  ['forge'],
};

const folderFor = (type) => FOLDER[type] || null;

const allowedUrl = (u) =>
  (u.protocol === 'https:' && ALLOWED_HOSTS.has(u.hostname)) || BASE_ORIGINS.includes(u.origin);

async function getJson(url) {
  const res = await fetch(url, { headers: { 'User-Agent': UA, Accept: 'application/json' }, signal: AbortSignal.timeout(12000) });
  if (!res.ok) throw new Error(`${new URL(url).hostname} answered ${res.status}`);
  return res.json();
}

const gameVersion = (v) => (/^\d{1,2}\.\d{1,2}(\.\d{1,2})?$/.test(v || '') ? v : null);

function safeName(name) {
  let n = String(name).replace(/[^\w .+()\-]/g, '_').replace(/^\.+/, '').slice(0, 100);
  if (!n.toLowerCase().endsWith('.jar')) n += '.jar';
  return n;
}

/* ── search ── */
async function searchModrinth({ q, type, version }) {
  const facets = [LOADERS[type].map((l) => `categories:${l}`)];
  if (gameVersion(version)) facets.push([`versions:${version}`]);
  const u = new URL(MODRINTH + '/search');
  u.searchParams.set('query', q || '');
  u.searchParams.set('limit', '20');
  u.searchParams.set('index', q ? 'relevance' : 'downloads');
  u.searchParams.set('facets', JSON.stringify(facets));
  const d = await getJson(u.toString());
  return (d.hits || []).map((h) => ({
    source: 'modrinth', id: h.project_id, title: h.title, author: h.author || '',
    description: h.description || '', downloads: h.downloads || 0,
    icon: /^https:\/\//.test(h.icon_url || '') ? h.icon_url : null,
  }));
}

async function searchSpiget({ q }) {
  const fields = 'id,name,tag,downloads,external,premium,file';
  const url = q
    ? `${SPIGET}/search/resources/${encodeURIComponent(q)}?field=name&size=30&sort=-downloads&fields=${fields}`
    : `${SPIGET}/resources?size=30&sort=-downloads&fields=${fields}`;
  const list = await getJson(url);
  return (Array.isArray(list) ? list : [])
    .filter((r) => !r.premium && !r.external && r.file && r.file.type === '.jar')   // only free, directly downloadable jars
    .slice(0, 20)
    .map((r) => ({ source: 'spiget', id: String(r.id), title: r.name, author: '', description: r.tag || '', downloads: r.downloads || 0, icon: null }));
}

async function search({ source, q, type, version }) {
  if (!LOADERS[type]) throw new Error('This server type has no plugins or mods');
  q = String(q || '').trim().slice(0, 60);
  if (source === 'modrinth') return searchModrinth({ q, type, version });
  if (source === 'spiget') {
    if (!['paper', 'spigot', 'purpur'].includes(type)) throw new Error('Spigot plugins only work on Paper, Spigot and Purpur servers');
    return searchSpiget({ q });
  }
  throw new Error('Unknown source');
}

/* ── resolve an install request into { url, filename } ── */
async function resolve({ source, id, type, version }) {
  if (!LOADERS[type]) throw new Error('This server type has no plugins or mods');

  if (source === 'modrinth') {
    if (!/^[A-Za-z0-9_-]{2,64}$/.test(String(id))) throw new Error('Invalid project');
    const u = new URL(`${MODRINTH}/project/${id}/version`);
    u.searchParams.set('loaders', JSON.stringify(LOADERS[type]));
    if (gameVersion(version)) u.searchParams.set('game_versions', JSON.stringify([version]));
    const versions = await getJson(u.toString());
    if (!Array.isArray(versions) || !versions.length) throw new Error(`No version of this project works with ${type} ${version}`);
    const v = versions.find((x) => x.version_type === 'release') || versions[0];
    const f = (v.files || []).find((x) => x.primary) || (v.files || [])[0];
    if (!f || !/\.jar$/i.test(f.filename || '')) throw new Error('This project has no .jar file');
    return { url: f.url, filename: safeName(f.filename) };
  }

  if (source === 'spiget') {
    if (!/^\d{1,10}$/.test(String(id))) throw new Error('Invalid resource');
    if (!['paper', 'spigot', 'purpur'].includes(type)) throw new Error('Spigot plugins only work on Paper, Spigot and Purpur servers');
    const info = await getJson(`${SPIGET}/resources/${id}?fields=id,name,external,premium,file`);
    if (info.premium || info.external || !info.file || info.file.type !== '.jar')
      throw new Error('This plugin cannot be installed automatically (paid, external or not a .jar). Download it from SpigotMC manually.');
    return { url: `${SPIGET}/resources/${id}/download`, filename: safeName(`${info.name}-${id}.jar`) };
  }
  throw new Error('Unknown source');
}

/* ── download (used by the panel for local servers; nodes have their own copy of this logic) ── */
async function download(url, dest, maxBytes = MAX_BYTES) {
  let res, cur = url;
  for (let hop = 0; hop < 4; hop++) {
    const u = new URL(cur);
    if (!allowedUrl(u)) throw new Error('Download blocked: host is not allowed');
    res = await fetch(u, { redirect: 'manual', headers: { 'User-Agent': UA }, signal: AbortSignal.timeout(120000) });
    if ([301, 302, 303, 307, 308].includes(res.status) && res.headers.get('location')) { cur = new URL(res.headers.get('location'), u).toString(); continue; }
    break;
  }
  if (!res.ok) throw new Error(`Download failed (HTTP ${res.status})`);

  const tmp = dest + '.part';
  let size = 0;
  const limit = new Transform({ transform(chunk, _e, cb) { size += chunk.length; cb(size > maxBytes ? new Error('File is too large') : null, chunk); } });
  try {
    await pipeline(Readable.fromWeb(res.body), limit, fs.createWriteStream(tmp));
    const fd = fs.openSync(tmp, 'r'); const head = Buffer.alloc(4); fs.readSync(fd, head, 0, 4, 0); fs.closeSync(fd);
    if (head.toString('hex') !== '504b0304') throw new Error('The download is not a valid .jar (the site may have blocked it). Try another source.');
    fs.renameSync(tmp, dest);
  } catch (e) {
    fs.rmSync(tmp, { force: true });
    throw e;
  }
  return size;
}

module.exports = { search, resolve, download, folderFor, safeName };
