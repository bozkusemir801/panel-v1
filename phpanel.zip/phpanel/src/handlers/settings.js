const fs   = require('fs');
const path = require('path');

const config = require('../config');
const FILE = path.join(config.configDir, 'panel.json');

const DEFAULTS = {
  panelName:        'PHBAI Panel',
  registrationOpen: true,
  defaultRam:       4,     // GB pool for every new user
  defaultCpu:       100,   // % pool for every new user (100 = 1 core)
  defaultDisk:      10,    // GB for every server
  afkReward:        50,    // coins
  afkIntervalHours: 24,
  adsEnabled:       true,
  adClientId:       '',
  adSlotId:         '',
  adInterval:       60,
  adFormat:         'auto',
};

const int  = (min, max) => (v) => { const n = Number(v); if (!Number.isInteger(n) || n < min || n > max) throw new Error(`must be a whole number between ${min} and ${max}`); return n; };
const bool = (v) => { if (typeof v === 'boolean') return v; if (v === 'true') return true; if (v === 'false') return false; throw new Error('must be true or false'); };
const str  = (re, max) => (v) => { const s = String(v ?? '').trim(); if (s.length > max || !re.test(s)) throw new Error('has an invalid format'); return s; };

const SCHEMA = {
  panelName:        str(/^[\w .\-]{1,40}$/, 40),
  registrationOpen: bool,
  defaultRam:       int(1, 512),
  defaultCpu:       int(10, 10000),
  defaultDisk:      int(1, 1000),
  afkReward:        int(0, 100000),
  afkIntervalHours: int(1, 720),
  adsEnabled:       bool,
  adClientId:       str(/^(ca-pub-\d{6,32})?$/, 40),
  adSlotId:         str(/^\d{0,20}$/, 20),
  adInterval:       int(10, 3600),
  adFormat:         (v) => { if (!['auto', 'rectangle', 'horizontal', 'vertical'].includes(v)) throw new Error('must be auto, rectangle, horizontal or vertical'); return v; },
};

function readFile() {
  try { return JSON.parse(fs.readFileSync(FILE, 'utf8')); } catch { return {}; }
}

function get() {
  const f = readFile();
  const out = { ...DEFAULTS };
  for (const k of Object.keys(DEFAULTS)) if (f[k] !== undefined) out[k] = f[k];
  if (out.panelName === 'PHPanel') out.panelName = DEFAULTS.panelName;   // old default name
  return out;
}

/** Validate + save. Unknown keys in the file (port, sessionSecret…) are left untouched. */
function update(patch) {
  const clean = {};
  for (const [k, v] of Object.entries(patch || {})) {
    if (!SCHEMA[k]) continue;                       // ignore anything that is not a setting
    try { clean[k] = SCHEMA[k](v); }
    catch (e) { throw new Error(`${k} ${e.message}`); }
  }
  const merged = { ...readFile(), ...clean };
  fs.mkdirSync(path.dirname(FILE), { recursive: true });
  fs.writeFileSync(FILE, JSON.stringify(merged, null, 2));
  return get();
}

module.exports = { get, update, DEFAULTS };
