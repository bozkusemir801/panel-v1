/**
 * Server types, version lists and the Docker image (Java version) each version needs.
 * Version lists are fetched live and cached for an hour; a built-in list is the fallback.
 */
const TYPES  = { paper: 'PAPER', spigot: 'SPIGOT', purpur: 'PURPUR', fabric: 'FABRIC', forge: 'FORGE', vanilla: 'VANILLA' };
const LABELS = { paper: 'Paper', spigot: 'Spigot', purpur: 'Purpur', fabric: 'Fabric', forge: 'Forge', vanilla: 'Vanilla' };

const VERSION_RE = /^(LATEST|\d{1,2}\.\d{1,2}(\.\d{1,2})?)$/;

// Oldest version each type supports
const MIN = { vanilla: '1.8', spigot: '1.8', paper: '1.8.8', purpur: '1.14.1', fabric: '1.14', forge: '1.8' };

const FALLBACK = ['26.3', '26.2', '26.1', '1.21.8', '1.21.5', '1.21.4', '1.21.1', '1.20.6', '1.20.4', '1.20.2', '1.20.1',
  '1.19.4', '1.19.2', '1.18.2', '1.17.1', '1.16.5', '1.15.2', '1.14.4', '1.12.2', '1.8.8'];
const FORGE_FALLBACK = ['1.21.4', '1.21.1', '1.20.6', '1.20.4', '1.20.1', '1.19.4', '1.19.2', '1.18.2', '1.16.5', '1.12.2', '1.8.9'];

const cmp = (a, b) => {
  const x = a.split('.').map(Number), y = b.split('.').map(Number);
  for (let i = 0; i < Math.max(x.length, y.length); i++) {
    const d = (x[i] || 0) - (y[i] || 0);
    if (d) return d;
  }
  return 0;
};
const newestFirst = (list) => [...new Set(list)].filter((v) => /^\d{1,2}\.\d{1,2}(\.\d{1,2})?$/.test(v)).sort((a, b) => cmp(b, a));

/** Which itzg/minecraft-server tag (Java version) can run this Minecraft version. */
function javaTag(version) {
  if (version === 'LATEST') return 'java25';
  const [maj, min = 0, patch = 0] = String(version).split('.').map(Number);
  if (maj >= 26) return 'java25';                     // new 2026 numbering
  if (min <= 16) return 'java8-multiarch';
  if (min <= 19) return 'java17';
  if (min === 20) return patch >= 5 ? 'java21' : 'java17';
  return 'java21';
}
const imageFor = (version) => `itzg/minecraft-server:${javaTag(version)}`;

/* ── live sources ── */
async function getJson(url) {
  const res = await fetch(url, { headers: { 'User-Agent': 'PHBAI-Panel/1.0' }, signal: AbortSignal.timeout(6000) });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

const SOURCES = {
  async mojang() {
    const m = await getJson('https://piston-meta.mojang.com/mc/game/version_manifest_v2.json');
    return m.versions.filter((v) => v.type === 'release').map((v) => v.id);
  },
  async fabric() {
    const l = await getJson('https://meta.fabricmc.net/v2/versions/game');
    return l.filter((v) => v.stable).map((v) => v.version);
  },
  async forge() {
    const p = await getJson('https://files.minecraftforge.net/net/minecraftforge/forge/promotions_slim.json');
    return Object.keys(p.promos || {}).map((k) => k.replace(/-(latest|recommended)$/, ''));
  },
  async purpur() {
    const p = await getJson('https://api.purpurmc.org/v2/purpur');
    return p.versions || [];
  },
};

const cache = new Map();    // type -> { at, versions, source }
const TTL = 60 * 60 * 1000;

async function list(type) {
  if (!TYPES[type]) throw new Error('Unknown server type');
  const hit = cache.get(type);
  if (hit && Date.now() - hit.at < TTL) return hit;

  let versions = null, source = 'fallback';
  try {
    const fn = { fabric: SOURCES.fabric, forge: SOURCES.forge, purpur: SOURCES.purpur }[type] || SOURCES.mojang;
    versions = newestFirst(await fn());
    if (versions.length) source = 'live'; else versions = null;
  } catch { versions = null; }

  if (!versions) versions = type === 'forge' ? FORGE_FALLBACK : FALLBACK;
  versions = versions.filter((v) => cmp(v, MIN[type]) >= 0);
  const entry = { at: Date.now(), versions, source };
  if (source === 'live') cache.set(type, entry);       // do not cache failures
  return entry;
}

module.exports = { TYPES, LABELS, VERSION_RE, MIN, FALLBACK, javaTag, imageFor, list, cmp, newestFirst };
