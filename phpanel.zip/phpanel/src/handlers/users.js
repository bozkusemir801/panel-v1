const fs      = require('fs');
const path    = require('path');
const bcrypt  = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
const config  = require('../config');
const settings = require('./settings');

const FILE = path.join(config.dataDir, 'users', 'users.json');

const USERNAME_RE = /^[A-Za-z0-9_.-]{3,20}$/;
const EMAIL_RE    = /^[^\s@]{1,64}@[^\s@]{1,255}$/;

function isFirstRun() {
  return !fs.existsSync(FILE);
}

function load() {
  if (!fs.existsSync(FILE)) return [];
  return JSON.parse(fs.readFileSync(FILE, 'utf8'));
}

function save(users) {
  fs.mkdirSync(path.dirname(FILE), { recursive: true });
  fs.writeFileSync(FILE, JSON.stringify(users, null, 2));
}

const same = (a, b) => String(a).toLowerCase() === String(b).toLowerCase();

function findById(id)         { return load().find(u => u.id === id); }
function findByUsername(name) { return load().find(u => same(u.username, name)); }

function checkUsername(username) {
  if (typeof username !== 'string' || !USERNAME_RE.test(username))
    throw new Error('Username must be 3-20 characters: letters, numbers, _ . -');
}
function checkPassword(password) {
  if (typeof password !== 'string' || password.length < 6) throw new Error('Password must be at least 6 characters.');
  if (password.length > 128) throw new Error('Password is too long.');
}
function checkEmail(email) {
  if (email && (typeof email !== 'string' || !EMAIL_RE.test(email))) throw new Error('Please enter a valid email address.');
}

/** New users start with the pool configured in Settings (default 4 GB RAM, 1 CPU, 10 GB disk). */
function create({ username, email, password }) {
  checkUsername(username); checkPassword(password); checkEmail(email);
  const users = load();
  if (users.find(u => same(u.username, username))) throw new Error('Username taken');
  const s = settings.get();
  const user = {
    id: uuidv4(), username, email: email || '',
    password: bcrypt.hashSync(password, 10),
    role: 'user', coins: 0,
    ram: s.defaultRam, cpu: s.defaultCpu, disk: s.defaultDisk,
    tokens: [],
    createdAt: new Date().toISOString()
  };
  users.push(user);
  save(users);
  return user;
}

/** Trusted internal update (role, coins, resources…). Never pass request bodies straight in here. */
function update(id, fields) {
  const users = load();
  const idx   = users.findIndex(u => u.id === id);
  if (idx === -1) throw new Error('User not found');
  if (fields.password) fields = { ...fields, password: bcrypt.hashSync(fields.password, 10) };
  users[idx] = { ...users[idx], ...fields };
  save(users);
  return users[idx];
}

/** What a user may change about themselves: username, email, password. Nothing else. */
function updateProfile(id, { username, email, password }) {
  const fields = {};
  if (username !== undefined && username !== '') {
    checkUsername(username);
    const other = load().find(u => same(u.username, username) && u.id !== id);
    if (other) throw new Error('Username taken');
    fields.username = username;
  }
  if (email !== undefined && email !== '') { checkEmail(email); fields.email = email; }
  if (password) { checkPassword(password); fields.password = password; }
  return update(id, fields);
}

function remove(id) {
  const users = load();
  if (!users.some(u => u.id === id)) throw new Error('User not found');
  save(users.filter(u => u.id !== id));
}

function addToken(userId, name) {
  const token   = uuidv4();
  const users   = load();
  const user    = users.find(u => u.id === userId);
  if (!user) throw new Error('User not found');
  user.tokens.push({ name, token, createdAt: new Date().toISOString() });
  save(users);
  return token;
}

const publicUser = (u) => { const { password, tokens, ...rest } = u; return rest; };
function list() { return load().map(publicUser); }

module.exports = { findById, findByUsername, create, update, updateProfile, remove, list, publicUser, addToken, load, save, isFirstRun, checkUsername, checkPassword };
