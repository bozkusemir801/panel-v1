/** Parse the answer of the `list` command: "There are 2 of a max of 20 players online: Steve, Alex" */
function parsePlayers(output) {
  const clean = String(output || '').replace(/\x1b\[[0-9;]*m/g, '').replace(/§./g, '');
  const m = clean.match(/There are (\d+)(?: of a max(?: of)? (\d+))? players? online:?\s*(.*)/i);
  if (!m) return { count: 0, max: null, players: [] };
  const names = (m[3] || '').split(/,\s*/).map((s) => s.trim()).filter((n) => /^\.?[A-Za-z0-9_ ]{1,20}$/.test(n));
  return { count: Number(m[1]), max: m[2] ? Number(m[2]) : null, players: names };
}
module.exports = { parsePlayers };
