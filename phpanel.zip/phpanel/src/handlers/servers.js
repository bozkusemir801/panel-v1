const fs   = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const config = require('../config');

const FILE = path.join(config.dataDir, 'servers', 'servers.json');

const DEFAULT_STARTUP = { motd: 'A Minecraft Server', maxPlayers: 20, onlineMode: false, jvmOpts: '' };

/** Validate the "Startup" settings a user may edit. Throws a readable error. */
function sanitizeStartup(input = {}) {
  const out = {};
  if (input.motd !== undefined) {
    const m = String(input.motd).replace(/[\x00-\x1f\x7f]/g, '').trim();
    if (m.length > 100) throw new Error('MOTD can be at most 100 characters');
    out.motd = m || DEFAULT_STARTUP.motd;
  }
  if (input.maxPlayers !== undefined) {
    const n = Number(input.maxPlayers);
    if (!Number.isInteger(n) || n < 1 || n > 1000) throw new Error('Max players must be between 1 and 1000');
    out.maxPlayers = n;
  }
  if (input.onlineMode !== undefined) out.onlineMode = input.onlineMode === true || input.onlineMode === 'true';
  if (input.jvmOpts !== undefined) {
    const j = String(input.jvmOpts).trim();
    if (j.length > 300 || !/^[A-Za-z0-9 _.:=,+\-\/@%]*$/.test(j)) throw new Error('JVM flags contain characters that are not allowed');
    out.jvmOpts = j;
  }
  return out;
}

function load() {
  if (!fs.existsSync(FILE)) { save([]); return []; }
  return JSON.parse(fs.readFileSync(FILE, 'utf8'));
}

function save(servers) {
  fs.mkdirSync(path.dirname(FILE), { recursive: true });
  fs.writeFileSync(FILE, JSON.stringify(servers, null, 2));
}

function list()      { return load(); }
function findById(id){ return load().find(s => s.id === id); }

function create({ name, type, version, port, ram, cpu, disk, ownerId, nodeId = null, startup }) {
  const servers = load();
  const id      = uuidv4();
  const server  = {
    id, name, type, version,
    port:    parseInt(port) || 25565,
    ram:     parseInt(ram)  || 2,
    cpu:     parseInt(cpu)  || 100,
    disk:    parseInt(disk) || 10,
    ownerId,
    nodeId:  nodeId || null,
    startup: { ...DEFAULT_STARTUP, ...sanitizeStartup(startup) },
    status:  'offline',
    containerId: null,
    createdAt: new Date().toISOString()
  };
  servers.push(server);
  save(servers);

  // create data dir for server files (remote servers keep theirs on the node)
  if (!nodeId) fs.mkdirSync(path.join(config.dataDir, 'servers', id), { recursive: true });

  return server;
}

/** Pass containerId to set it, null to clear it, leave it out to keep it. */
function updateStatus(id, status, containerId) {
  const servers = load();
  const srv     = servers.find(s => s.id === id);
  if (!srv) throw new Error('Server not found');
  srv.status = status;
  if (containerId !== undefined) srv.containerId = containerId;
  save(servers);
  return srv;
}

/** Change fields. Callers must have validated them already. */
function update(id, fields) {
  const servers = load();
  const srv     = servers.find(s => s.id === id);
  if (!srv) throw new Error('Server not found');
  Object.assign(srv, fields);
  save(servers);
  return srv;
}

function remove(id) {
  save(load().filter(s => s.id !== id));
}

module.exports = { list, findById, create, update, updateStatus, remove, load, sanitizeStartup, DEFAULT_STARTUP };
