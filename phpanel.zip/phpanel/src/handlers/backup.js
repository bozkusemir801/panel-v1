const fs       = require('fs');
const path     = require('path');
const archiver = require('archiver');
const config   = require('../config');
const docker   = require('./docker');
const servers  = require('./servers');

function backupDir(serverId) {
  const dir = path.join(config.dataDir, 'backups', serverId);
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

async function create(serverId) {
  const srv = servers.findById(serverId);
  if (!srv) throw new Error('Server not found');

  const srcDir  = path.join(config.dataDir, 'servers', serverId);
  const outDir  = backupDir(serverId);
  const stamp   = new Date().toISOString().replace(/[:.]/g, '-');
  const outFile = path.join(outDir, `backup_${stamp}.tar.gz`);

  // If running, ask minecraft to save-off before backup
  if (srv.containerId) {
    try { await docker.execCommand(srv, 'save-off'); } catch {}
    try { await docker.execCommand(srv, 'save-all'); } catch {}
  }

  await new Promise((resolve, reject) => {
    const output  = fs.createWriteStream(outFile);
    const archive = archiver('tar', { gzip: true });
    output.on('close', resolve);
    archive.on('error', reject);
    archive.pipe(output);
    archive.directory(srcDir, false);
    archive.finalize();
  });

  // Re-enable saves
  if (srv.containerId) {
    try { await docker.execCommand(srv, 'save-on'); } catch {}
  }

  const stat = fs.statSync(outFile);
  return { file: path.basename(outFile), size: stat.size, createdAt: new Date().toISOString() };
}

function list(serverId) {
  const dir = backupDir(serverId);
  if (!fs.existsSync(dir)) return [];
  return fs.readdirSync(dir)
    .filter(f => f.endsWith('.tar.gz'))
    .map(f => {
      const stat = fs.statSync(path.join(dir, f));
      return { file: f, size: stat.size, createdAt: stat.mtime.toISOString() };
    })
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
}

function remove(serverId, file) {
  const p = path.join(backupDir(serverId), file);
  if (fs.existsSync(p)) fs.unlinkSync(p);
}

module.exports = { create, list, remove };
