const fs   = require('fs');
const path = require('path');

const configDir = process.env.CONFIG_DIR || path.join(__dirname, '..', 'config');
const cfgPath = path.join(configDir, 'panel.json');

let fileCfg = {};
if (fs.existsSync(cfgPath)) {
  fileCfg = JSON.parse(fs.readFileSync(cfgPath, 'utf8'));
}

module.exports = {
  port:          process.env.PORT          || fileCfg.port          || 5001,
  sessionSecret: process.env.SESSION_SECRET|| fileCfg.sessionSecret || 'changeme-secret-phpanel',
  dockerSocket:  process.env.DOCKER_SOCKET || fileCfg.dockerSocket  || '/var/run/docker.sock',
  configDir,
  dataDir:       process.env.DATA_DIR || path.join(__dirname, '..', 'storage'),   // panel name, disk, ads… live in handlers/settings.js
};
