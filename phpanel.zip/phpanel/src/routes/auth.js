const router    = require('express').Router();
const bcrypt    = require('bcryptjs');
const rateLimit = require('express-rate-limit');
const users     = require('../handlers/users');
const settings  = require('../handlers/settings');

// Slows down password guessing. Successful logins do not count.
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, limit: 15, standardHeaders: true, legacyHeaders: false, skipSuccessfulRequests: true,
  handler: (req, res) => res.status(429).render('login', { error: 'Too many attempts. Please try again in a few minutes.' }),
});

const DUMMY_HASH = bcrypt.hashSync('not-a-real-password', 10);   // keeps timing equal for unknown users

// GET /auth/login
router.get('/login', (req, res) => {
  if (users.isFirstRun()) return res.redirect('/setup');
  if (req.session.userId) return res.redirect('/');
  res.render('login', { error: null });
});

// POST /auth/login
router.post('/login', limiter, (req, res) => {
  const username = typeof req.body.username === 'string' ? req.body.username : '';
  const password = typeof req.body.password === 'string' ? req.body.password : '';
  const user = users.findByUsername(username);
  const ok = bcrypt.compareSync(password, user ? user.password : DUMMY_HASH) && !!user;
  if (!ok) return res.status(401).render('login', { error: 'Invalid username or password' });

  req.session.regenerate((err) => {            // new session id on login (prevents session fixation)
    if (err) return res.status(500).render('login', { error: 'Could not start a session. Try again.' });
    req.session.userId   = user.id;
    req.session.username = user.username;
    req.session.role     = user.role;
    req.session.save(() => res.redirect('/'));
  });
});

// POST /auth/register
router.post('/register', limiter, (req, res) => {
  if (!settings.get().registrationOpen) return res.status(403).render('login', { error: 'Registration is closed. Ask an administrator for an account.' });
  const { username, email, password } = req.body;
  try {
    users.create({ username, email, password });
    res.redirect('/auth/login');
  } catch (e) {
    res.status(400).render('login', { error: e.message });
  }
});

// GET /auth/logout
router.get('/logout', (req, res) => {
  req.session.destroy(() => res.redirect('/auth/login'));
});

module.exports = router;
