const router = require('express').Router();
const users  = require('../handlers/users');

// Middleware: redirect to setup if first run, block setup if already done
function setupGuard(req, res, next) {
  if (users.isFirstRun()) return res.redirect('/setup');
  next();
}

// GET /setup
router.get('/', (req, res) => {
  if (!users.isFirstRun()) return res.redirect('/');
  res.render('setup', { error: null });
});

// POST /setup
router.post('/', (req, res) => {
  if (!users.isFirstRun()) return res.redirect('/');

  const { username, email, password, confirm } = req.body;

  if (!username || username.length < 3)
    return res.render('setup', { error: 'Username must be at least 3 characters.' });

  if (!email || !email.includes('@'))
    return res.render('setup', { error: 'Please enter a valid email address.' });

  if (!password || password.length < 6)
    return res.render('setup', { error: 'Password must be at least 6 characters.' });

  if (password !== confirm)
    return res.render('setup', { error: 'Passwords do not match.' });

  try {
    const admin = users.create({ username, email, password });
    // Upgrade to admin role
    users.update(admin.id, { role: 'admin', coins: 0, ram: null, cpu: null, disk: null });
    res.redirect('/auth/login');
  } catch (e) {
    res.render('setup', { error: e.message });
  }
});

module.exports = { router, setupGuard };
