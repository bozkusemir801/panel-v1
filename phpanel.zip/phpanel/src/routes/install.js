const router   = require('express').Router();
const fs       = require('fs');
const path     = require('path');
const archiver = require('archiver');

const ROOT = path.join(__dirname, '..', '..');

// curl -sSL https://PANEL/install/agent.sh | sudo bash -s -- --panel https://PANEL --key TOKEN --name NAME
router.get('/agent.sh', (req, res) => {
  const f = path.join(ROOT, 'scripts', 'install-agent.sh');
  if (!fs.existsSync(f)) return res.status(404).send('install script missing');
  res.type('text/x-shellscript').send(fs.readFileSync(f));
});

// the agent's source code (no secrets in it)
router.get('/agent.tgz', (req, res) => {
  const dir = path.join(ROOT, 'agent');
  if (!fs.existsSync(path.join(dir, 'package.json'))) return res.status(404).send('agent files missing');
  res.type('application/gzip');
  const tar = archiver('tar', { gzip: true });
  tar.on('error', () => res.destroy());
  tar.pipe(res);
  tar.glob('**/*', { cwd: dir, ignore: ['node_modules/**', 'config/agent.json', 'data/**', 'test/**', '**/*.log'], dot: false });
  tar.finalize();
});

module.exports = router;
