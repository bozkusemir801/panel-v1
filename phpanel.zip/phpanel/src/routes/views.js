const router = require('express').Router();

// Everything goes to the SPA shell — client-side routing handles the rest
router.get('*', (req, res) => {
  res.render('app', {
    user: {
      username: req.session.username,
      role:     req.session.role,
      userId:   req.session.userId,
    },
    isAdmin: req.session.role === 'admin',
  });
});

module.exports = router;
