const router   = require('express').Router();
const { adminOnly } = require('../middleware/auth');
const servers  = require('../handlers/servers');
const users    = require('../handlers/users');
const docker   = require('../handlers/docker');
const backup   = require('../handlers/backup');
const nodes    = require('../handlers/nodes');
const files    = require('../handlers/files');
const plugins  = require('../handlers/plugins');
const versions = require('../handlers/versions');
const settings = require('../handlers/settings');
const { parsePlayers } = require('../handlers/players');
const config   = require('../config');

/* ───────── helpers ───────── */
const fail = (status, message) => Object.assign(new Error(message), { status });

const intIn = (v, min, max, label) => {
  const n = Number(v);
  if (!Number.isInteger(n) || n < min || n > max) throw fail(400, `${label} must be a whole number between ${min} and ${max}`);
  return n;
};

const cleanServerName = (v) => {
  const n = String(v ?? '').replace(/[\x00-\x1f\x7f]/g, '').trim();
  if (!n || n.length > 32) throw fail(400, 'Server name must be 1-32 characters');
  return n;
};

function checkTypeVersion(type, version) {
  if (!versions.TYPES[type]) throw fail(400, 'Unknown server type');
  if (!versions.VERSION_RE.test(String(version))) throw fail(400, 'Invalid version');
}

const usageOf = (userId) => {
  const mine = servers.list().filter((s) => s.ownerId === userId);
  return { ram: mine.reduce((a, s) => a + s.ram, 0), cpu: mine.reduce((a, s) => a + s.cpu, 0), count: mine.length };
};

/** Wrap an async handler: JSON result, errors become { error } */
const h = (fn) => async (req, res) => {
  try {
    const out = await fn(req, res);
    if (out !== undefined && !res.headersSent) res.json(out);
  } catch (e) { if (!res.headersSent) res.status(e.status || 400).json({ error: e.message }); }
};

/* ───────── who am I ───────── */
router.get('/me', h((req) => {
  const u = users.findById(req.session.userId);
  const used = usageOf(u.id);
  const s = settings.get();
  return {
    id: u.id, username: u.username, email: u.email || '', role: u.role, coins: u.coins,
    ram: u.role === 'admin' ? null : u.ram, cpu: u.role === 'admin' ? null : u.cpu,   // null = unlimited
    usedRam: used.ram, usedCpu: used.cpu, servers: used.count,
    diskPerServer: s.defaultDisk, panelName: s.panelName,
  };
}));

/* ───────── servers ───────── */
// Every /servers/:id/... route: the server must exist and belong to the caller.
// Admins may stop/restart/delete any server (moderation) but never see its files or console.
router.param('id', (req, res, next, id) => {
  const srv = servers.findById(id);
  if (!srv) return res.status(404).json({ error: 'Not found' });
  req.isOwner = srv.ownerId === req.session.userId;
  if (!req.isOwner && req.session.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
  req.srv = srv;
  next();
});
const ownerOnly = (req, res, next) => (req.isOwner ? next() : res.status(403).json({ error: 'Only the owner can do this' }));

// your own servers, for everybody (admins included)
router.get('/servers', (req, res) => res.json(servers.list().filter((s) => s.ownerId === req.session.userId)));

// admin moderation list: everybody's servers, metadata only
router.get('/servers/all', adminOnly, (req, res) => {
  const owners = new Map(users.load().map((u) => [u.id, u.username]));
  const nodeNames = new Map(nodes.list().map((n) => [n.id, n.name]));
  res.json(servers.list().map((s) => ({
    id: s.id, name: s.name, type: s.type, version: s.version, port: s.port, ram: s.ram, cpu: s.cpu, disk: s.disk, status: s.status,
    ownerName: owners.get(s.ownerId) || 'deleted user', nodeName: s.nodeId ? (nodeNames.get(s.nodeId) || 'unknown node') : 'Local',
  })));
});

router.post('/servers', h((req) => {
  const b = req.body || {};
  const user = users.findById(req.session.userId);
  const admin = user.role === 'admin';
  const s = settings.get();

  const name = cleanServerName(b.name);
  checkTypeVersion(b.type, b.version);
  const port = intIn(b.port, 1024, 65535, 'Port');
  const ram  = intIn(b.ram, 1, admin ? 256 : 64, 'RAM (GB)');
  const cpu  = intIn(b.cpu, 10, 10000, 'CPU (%)');
  const disk = admin && b.disk ? intIn(b.disk, 1, 1000, 'Disk (GB)') : s.defaultDisk;   // everybody else: fixed
  const nodeId = b.nodeId || null;
  if (nodeId && !nodes.get(nodeId)) throw fail(400, 'Unknown node');

  if (!nodeId && port === Number(config.port)) throw fail(409, `Port ${port} is used by the panel itself`);
  if (servers.list().some((x) => x.port === port && (x.nodeId || null) === nodeId)) throw fail(409, `Port ${port} is already used by another server`);

  if (!admin) {
    const used = usageOf(user.id);
    if (used.ram + ram > user.ram) throw fail(400, `Not enough RAM: you have ${Math.max(0, user.ram - used.ram)} GB left of ${user.ram} GB`);
    if (used.cpu + cpu > user.cpu) throw fail(400, `Not enough CPU: you have ${Math.max(0, user.cpu - used.cpu)}% left of ${user.cpu}%`);
  }
  const startup = servers.sanitizeStartup(b.startup || {});
  return servers.create({ name, type: b.type, version: b.version, port, ram, cpu, disk, ownerId: user.id, nodeId, startup });
}));

router.patch('/servers/:id', ownerOnly, h((req) => {
  const b = req.body || {};
  const fields = {};
  if (b.name !== undefined) fields.name = cleanServerName(b.name);
  if (b.type !== undefined || b.version !== undefined) {
    const type = b.type ?? req.srv.type, version = b.version ?? req.srv.version;
    checkTypeVersion(type, version);
    fields.type = type; fields.version = version;
  }
  if (b.startup !== undefined) fields.startup = { ...(req.srv.startup || servers.DEFAULT_STARTUP), ...servers.sanitizeStartup(b.startup) };
  return servers.update(req.srv.id, fields);
}));

// Starting can take minutes (first start downloads the game image), so it runs in the background:
// the request returns at once, the server shows "Starting" and the outcome is stored on the server (status / lastError).
router.post('/servers/:id/start', ownerOnly, h((req) => {
  const srv = req.srv;
  if (srv.status === 'starting') throw fail(409, 'This server is already starting');
  servers.update(srv.id, { status: 'starting', lastError: null, startedAt: new Date().toISOString() });
  docker.startServer(srv).then(
    () => servers.update(srv.id, { lastError: null }),
    (e) => { console.error(`[start] ${srv.name}: ${e.message}`); try { servers.update(srv.id, { status: 'offline', containerId: null, lastError: String(e.message).slice(0, 600) }); } catch {} });
  return { ok: true, status: 'starting' };
}));

router.post('/servers/:id/stop',    h(async (req) => { await docker.stopServer(req.srv);    return { ok: true }; }));
router.post('/servers/:id/restart', h(async (req) => { await docker.restartServer(req.srv); return { ok: true }; }));

router.delete('/servers/:id', h(async (req) => {
  try { await docker.destroyServer(req.srv); }
  catch (e) {
    // e.g. the node is offline: only an admin may remove the record anyway
    if (!(req.session.role === 'admin' && req.query.force === '1')) throw fail(500, `${e.message}. (Admins can force-remove the record.)`);
  }
  servers.remove(req.srv.id);
  return { ok: true };
}));

router.get('/servers/:id/stats', h(async (req) => (await docker.getStats(req.srv)) || {}));

/* ── console command & players (console is owner-only) ── */
router.post('/servers/:id/command', ownerOnly, h(async (req) => {
  const out = await docker.execCommand(req.srv, req.body && req.body.cmd);
  return { output: out || '' };
}));

router.get('/servers/:id/players', ownerOnly, h(async (req) => {
  if (req.srv.status !== 'running') return { online: false, count: 0, max: null, players: [] };
  return { online: true, ...parsePlayers(await docker.execCommand(req.srv, 'list')) };
}));

/* ── files (this machine, or the node's agent) ── */
const pth = (v) => (typeof v === 'string' ? v : '');
router.get('/servers/:id/files', ownerOnly, h((req) => files.op(req.srv, 'list', { path: pth(req.query.path) })));
router.get('/servers/:id/files/read', ownerOnly, h(async (req, res) => {
  res.type('text/plain').send(await files.op(req.srv, 'read', { path: pth(req.query.path) }));
}));
router.post('/servers/:id/files/write',  ownerOnly, h((req) => files.op(req.srv, 'write',  { path: pth(req.body.path), content: req.body.content })));
router.post('/servers/:id/files/mkdir',  ownerOnly, h((req) => files.op(req.srv, 'mkdir',  { path: pth(req.body.path) })));
// Upload: the request body IS the file (no multipart). path = where to put it, e.g. plugins/MyPlugin.jar or world/level.dat
router.put('/servers/:id/files/upload', ownerOnly, h((req) => files.upload(req.srv, pth(req.query.path), req)));
router.post('/servers/:id/files/delete', ownerOnly, h((req) => files.op(req.srv, 'delete', { path: pth(req.body.path) })));

/* ── plugins & mods (Modrinth, Spigot) ── */
router.get('/plugins/search', h(async (req) => {
  const { source, q, type, version } = req.query;
  return { results: await plugins.search({ source, q, type, version }) };
}));

router.get('/servers/:id/plugins', ownerOnly, h(async (req) => {
  const folder = plugins.folderFor(req.srv.type);
  if (!folder) return { supported: false, folder: null, files: [] };
  const list = await files.op(req.srv, 'list', { path: folder });
  return { supported: true, folder, files: list.filter((f) => !f.isDir && /\.jar(\.disabled)?$/i.test(f.name)) };
}));

router.post('/servers/:id/plugins/install', ownerOnly, h(async (req) => {
  const folder = plugins.folderFor(req.srv.type);
  if (!folder) throw fail(400, 'Vanilla servers do not support plugins or mods. Switch to Paper, Fabric… in the Version tab.');
  const { source, id } = req.body || {};
  const r = await plugins.resolve({ source, id, type: req.srv.type, version: req.srv.version });
  await files.op(req.srv, 'download', { dir: folder, filename: r.filename, url: r.url });
  return { ok: true, file: r.filename, folder };
}));

router.delete('/servers/:id/plugins/:file', ownerOnly, h(async (req) => {
  const folder = plugins.folderFor(req.srv.type);
  if (!folder || !/^[\w .+()\-]{1,120}\.jar(\.disabled)?$/i.test(req.params.file)) throw fail(400, 'Invalid file');
  return files.op(req.srv, 'delete', { path: `${folder}/${req.params.file}` });
}));

/* ── backups (this machine only for now) ── */
const noRemoteBackups = (req, res, next) => {
  if (!req.srv.nodeId) return next();
  if (req.method === 'GET') return res.json([]);
  res.status(501).json({ error: 'Backups are not supported on remote nodes yet' });
};
router.get('/servers/:id/backups',  ownerOnly, noRemoteBackups, h((req) => backup.list(req.srv.id)));
router.post('/servers/:id/backups', ownerOnly, noRemoteBackups, h((req) => backup.create(req.srv.id)));
router.delete('/servers/:id/backups/:file', ownerOnly, noRemoteBackups, h((req) => {
  if (!/^backup_[\w.\-]+\.tar\.gz$/.test(req.params.file)) throw fail(400, 'Invalid backup name');
  backup.remove(req.srv.id, req.params.file);
  return { ok: true };
}));

/* ───────── versions ───────── */
router.get('/versions/:type', h(async (req) => {
  if (!versions.TYPES[req.params.type]) throw fail(404, 'Unknown server type');
  const { versions: list, source } = await versions.list(req.params.type);
  return { versions: list, source };
}));

/* ───────── nodes (admins manage; everyone can see which ones are online) ───────── */
router.get('/nodes', h((req) => {
  const list = nodes.list();
  return req.session.role === 'admin' ? list : list.map((n) => ({ id: n.id, name: n.name, online: n.online }));
}));
router.post('/nodes', adminOnly, h((req) => nodes.create(req.body && req.body.name)));
router.post('/nodes/:nid/token', adminOnly, h((req) => nodes.regenerate(req.params.nid)));
router.delete('/nodes/:nid', adminOnly, h((req) => {
  const n = nodes.get(req.params.nid);
  if (!n) throw fail(404, 'Not found');
  if (servers.list().some((s) => s.nodeId === n.id)) throw fail(400, 'This node still has servers on it. Delete them first.');
  nodes.remove(n.id);
  return { ok: true };
}));

/* ───────── settings (admin) ───────── */
router.get('/settings',  adminOnly, h(() => settings.get()));
router.post('/settings', adminOnly, h((req) => settings.update(req.body)));

/* ───────── users ───────── */
router.get('/users', adminOnly, h(() => users.list().map(({ tokens, ...u }) => u)));

// A user may only change username, email and password. Never role, coins or resources.
router.patch('/users/me', h((req) => {
  const updated = users.updateProfile(req.session.userId, req.body || {});
  req.session.username = updated.username;
  return { ok: true, username: updated.username };
}));

router.post('/users/me/token', h((req) => ({ token: users.addToken(req.session.userId, String((req.body && req.body.name) || 'Token').slice(0, 40)) })));

/* ───────── shop ───────── */
const PRICES = { 'ram-1': { cost: 200, ram: 1 }, 'ram-4': { cost: 700, ram: 4 }, 'cpu-100': { cost: 250, cpu: 100 } };
router.post('/shop/buy', h((req) => {
  const user = users.findById(req.session.userId);
  const p = PRICES[req.body && req.body.item];
  if (!p) throw fail(400, 'Invalid item');
  if (user.coins < p.cost) throw fail(400, 'Not enough coins');
  const fields = { coins: user.coins - p.cost };
  if (p.ram) fields.ram = (user.ram || 0) + p.ram;
  if (p.cpu) fields.cpu = (user.cpu || 0) + p.cpu;
  const u = users.update(user.id, fields);
  return { ok: true, coins: u.coins, ram: u.ram, cpu: u.cpu };
}));

/* ───────── AFK: free coins once per interval ───────── */
function afkState(u) {
  const s = settings.get();
  const next = (u.lastAfkClaim ? Date.parse(u.lastAfkClaim) : 0) + s.afkIntervalHours * 3600 * 1000;
  const canClaim = Date.now() >= next;
  return {
    reward: s.afkReward, intervalHours: s.afkIntervalHours, coins: u.coins, canClaim,
    nextClaimAt: canClaim ? null : new Date(next).toISOString(),
    ads: { enabled: s.adsEnabled, clientId: s.adClientId, slotId: s.adSlotId, interval: s.adInterval, format: s.adFormat },
  };
}
router.get('/afk', h((req) => afkState(users.findById(req.session.userId))));
router.post('/afk/claim', h((req) => {
  const u = users.findById(req.session.userId);
  const st = afkState(u);
  if (!st.canClaim) throw fail(429, 'Already claimed. Come back later.');
  const updated = users.update(u.id, { coins: (u.coins || 0) + st.reward, lastAfkClaim: new Date().toISOString() });
  return { ok: true, earned: st.reward, ...afkState(updated) };
}));

module.exports = router;
