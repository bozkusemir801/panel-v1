require('dotenv').config();
const express     = require('express');
const http        = require('http');
const { Server }  = require('socket.io');
const session     = require('express-session');
const helmet      = require('helmet');
const morgan      = require('morgan');
const path        = require('path');
const cron        = require('node-cron');

const config      = require('./config');
const authRouter  = require('./routes/auth');
const apiRouter   = require('./routes/api');
const viewRouter  = require('./routes/views');
const { router: setupRouter, setupGuard } = require('./routes/setup');
const { authMiddleware } = require('./middleware/auth');
const dockerHandler = require('./handlers/docker');
const backupHandler = require('./handlers/backup');
const socketHandler = require('./handlers/socket');
const nodesHandler  = require('./handlers/nodes');
const settings      = require('./handlers/settings');
const servers_      = require('./handlers/servers');
const installRouter = require('./routes/install');

const app    = express();
const server = http.createServer(app);
const io     = new Server(server, { cors: { origin: '*' } });

/* ── Security & logging ── */
app.set('trust proxy', Number(process.env.TRUST_PROXY ?? 1));   // behind one reverse proxy (Codespaces, nginx, Cloudflare tunnel…)
app.use(helmet({ contentSecurityPolicy: false }));
app.use(morgan('dev'));

/* ── Session ── */
const sessionMiddleware = session({
  secret: config.sessionSecret,
  resave: false,
  saveUninitialized: false,
  cookie: { secure: false, httpOnly: true, sameSite: 'lax', maxAge: 7 * 24 * 60 * 60 * 1000 }
});
app.use(sessionMiddleware);
io.engine.use(sessionMiddleware);   // lets Socket.IO see who is logged in

/* ── Body parsers ── */
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

/* ── Static files ── */
app.use(express.static(path.join(__dirname, 'public')));

/* ── View engine ── */
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

/* ── Panel name & registration flag are available in every template ── */
app.use((req, res, next) => {
  const s = settings.get();
  res.locals.panelName = s.panelName;
  res.locals.registrationOpen = s.registrationOpen;
  next();
});

/* ── Routes ── */
app.use('/install', installRouter);     // public: used by `curl … | bash` on node machines
app.use('/setup', setupRouter);
app.use('/auth', setupGuard, authRouter);
app.use('/api',  setupGuard, authMiddleware, apiRouter);
app.use('/',     setupGuard, authMiddleware, viewRouter);

/* ── a start that was interrupted by a restart of the panel must not stay "starting" forever ── */
for (const srv of servers_.list()) if (srv.status === 'starting') servers_.update(srv.id, { status: 'offline', lastError: 'The panel was restarted while this server was starting. Start it again.' });

/* ── Node agents connect on /agent, browsers on / ── */
nodesHandler.attach(io);

/* ── Socket.IO (console streaming) ── */
socketHandler(io);

/* ── Auto backup cron (every day at 03:00) ── */
cron.schedule('0 3 * * *', async () => {
  console.log('[CRON] Running scheduled backups…');
  const servers = require('./handlers/servers').list();
  for (const srv of servers) {
    if (srv.nodeId) continue;            // remote servers are not backed up yet
    try { await backupHandler.create(srv.id); } catch (e) { console.error('[CRON] backup error:', e.message); }
  }
});

/* ── Start ── */
server.listen(config.port, () => {
  console.log(`\n  ${settings.get().panelName} running on http://localhost:${config.port}`);
  if (config.sessionSecret === 'changeme-secret-phpanel' || config.sessionSecret === 'change-this-in-production')
    console.warn('  WARNING: SESSION_SECRET is still the default. Set a random one (openssl rand -hex 32).');
  console.log(`  Docker socket: ${config.dockerSocket}\n`);
});
