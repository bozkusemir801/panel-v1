const users = require('../handlers/users');

function authMiddleware(req, res, next) {
  const wantsApi = req.originalUrl.startsWith('/api');
  if (req.session && req.session.userId) {
    const u = users.findById(req.session.userId);
    if (u) {                                  // role changes and deleted accounts take effect immediately
      req.session.role = u.role;
      req.session.username = u.username;
      return next();
    }
    req.session.destroy(() => {});
  }
  if (wantsApi) return res.status(401).json({ error: 'Unauthorized' });
  res.redirect('/auth/login');
}

function adminOnly(req, res, next) {
  if (req.session && req.session.role === 'admin') return next();
  res.status(403).json({ error: 'Admin only' });
}

module.exports = { authMiddleware, adminOnly };
