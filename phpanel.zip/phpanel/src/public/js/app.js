/* PHBAI Panel — frontend (single page app) */
const { user, isAdmin, panelName } = window.PHPANEL;
const socket = io();
let ME = null;                       // /api/me

/* ═══ HELPERS ═══ */
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fmtSize = (b) => (b < 1024 ? b + ' B' : b < 1048576 ? (b / 1024).toFixed(1) + ' KB' : (b / 1048576).toFixed(1) + ' MB');
const num = (n) => Number(n || 0).toLocaleString();
const TYPE_NAMES = { paper: 'Paper', spigot: 'Spigot', purpur: 'Purpur', fabric: 'Fabric', forge: 'Forge', vanilla: 'Vanilla' };
const TYPES = Object.keys(TYPE_NAMES);

function toast(msg, type = '') {
  const c = $('toast-container');
  const t = document.createElement('div');
  t.className = 'toast' + (type ? ' ' + type : '');
  t.textContent = msg;
  c.appendChild(t);
  setTimeout(() => { t.style.opacity = '0'; setTimeout(() => t.remove(), 300); }, type === 'error' ? 9000 : 3200);
}

async function api(method, path, body) {
  const res = await fetch('/api' + path, {
    method,
    headers: { 'Content-Type': 'application/json' },
    body: body ? JSON.stringify(body) : undefined,
  });
  if (res.status === 401) { location.href = '/auth/login'; throw new Error('Signed out'); }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}
async function apiText(path) {
  const res = await fetch('/api' + path);
  const text = await res.text();
  if (!res.ok) { let m = text; try { m = JSON.parse(text).error; } catch {} throw new Error(m || 'Request failed'); }
  return text;
}

async function copyText(text) {
  try { await navigator.clipboard.writeText(text); }
  catch {
    const t = document.createElement('textarea'); t.value = text; document.body.appendChild(t); t.select();
    document.execCommand('copy'); t.remove();
  }
  toast('Copied!', 'success');
}

async function refreshMe() {
  ME = await api('GET', '/me');
  $('sb-coins').textContent = num(ME.coins);
  return ME;
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const pill = (st) => st === 'running' ? '<span class="sp-pill s-on"><span class="dot"></span>Online</span>'
  : st === 'starting' ? '<span class="sp-pill s-wait"><span class="dot"></span>Starting…</span>'
  : '<span class="sp-pill s-off"><span class="dot"></span>Offline</span>';
const emptyMsg = (t) => `<p style="color:var(--sl-400);padding:20px;">${esc(t)}</p>`;
const help = (t) => `<div class="help">${t}</div>`;

/* ═══ NAV ═══ */
const PAGE_TITLES = {
  dashboard:    ['Dashboard', 'Overview'],
  servers:      ['Servers', 'Your servers'],
  shop:         ['Shop', 'Resource shop'],
  afk:          ['AFK', 'Free daily coins'],
  adminservers: ['All Servers', 'Moderation (admins only)'],
  nodes:        ['Nodes', 'Run servers on other machines'],
  users:        ['Users', 'User accounts'],
  settings:     ['Settings', 'Panel configuration'],
};
const ADMIN_PAGES = ['adminservers', 'nodes', 'users', 'settings'];
let afkTimer = null;

function nav(id) {
  if (ADMIN_PAGES.includes(id) && !isAdmin) id = 'dashboard';
  document.querySelectorAll('.ni').forEach((n) => n.classList.toggle('active', n.dataset.page === id));
  const info = PAGE_TITLES[id] || [id, ''];
  $('pg-title').textContent = info[0];
  $('pg-sub').textContent = info[1];
  $('tb-new-btn').style.display = ['dashboard', 'servers'].includes(id) ? '' : 'none';
  clearInterval(afkTimer);
  renderPage(id);
}
document.querySelectorAll('.ni').forEach((n) => n.addEventListener('click', () => nav(n.dataset.page)));
$('tb-new-btn').addEventListener('click', openNewServer);
const currentPage = () => document.querySelector('.ni.active')?.dataset.page || 'dashboard';

let renderSeq = 0;      // only the newest navigation may draw (a slow answer for an old page must not replace the new one)
async function renderPage(id) {
  const my = ++renderSeq;
  const el = $('page-content');
  el.innerHTML = '<div style="padding:40px;text-align:center;color:var(--sl-400);">Loading…</div>';
  try {
    await refreshMe();
    const pages = { dashboard: pageDashboard, servers: pageServers, shop: pageShop, afk: pageAfk, adminservers: pageAdminServers, nodes: pageNodes, users: pageUsers, settings: pageSettings };
    const html = pages[id] ? await pages[id]() : '<p>Page not found.</p>';
    if (my !== renderSeq) return;
    el.innerHTML = html;
    bindPageEvents(id);
  } catch (e) {
    if (my !== renderSeq) return;
    el.innerHTML = `<div style="padding:20px;color:var(--red-500);">Error: ${esc(e.message)}</div>`;
  }
}

function bindPageEvents(id) {
  document.querySelectorAll('.sc[data-id]').forEach((el) => el.addEventListener('click', () => openServerModal(el.dataset.id)));
  if (id === 'afk') startAfk();
  if (id === 'settings') bindSettings();
}

/* ═══ SERVERS (own) ═══ */
function srvCard(s) {
  return `<div class="sc" data-id="${esc(s.id)}">
    <div class="sc-top">
      <div class="sc-ico ${esc(s.type)}"><svg viewBox="0 0 24 24"><rect x="2" y="2" width="20" height="8" rx="2"/><rect x="2" y="14" width="20" height="8" rx="2"/></svg></div>
      <div style="flex:1;min-width:0"><div class="sc-name">${esc(s.name)}</div><div class="sc-meta">${esc(TYPE_NAMES[s.type] || s.type)} ${esc(s.version)} · :${esc(s.port)}</div></div>
      ${pill(s.status)}
    </div>
    <div class="sc-stats">
      <div><div class="ms-l">RAM</div><div class="ms-v">${esc(s.ram)}GB</div></div>
      <div><div class="ms-l">CPU</div><div class="ms-v">${esc(s.cpu)}%</div></div>
      <div><div class="ms-l">Disk</div><div class="ms-v">${esc(s.disk)}GB</div></div>
      <div><div class="ms-l">Port</div><div class="ms-v">${esc(s.port)}</div></div>
    </div>
    <div class="sc-open-hint">Click to manage</div>
  </div>`;
}

const limitText = (used, max, unit) => (max === null ? `${used}${unit} <span class="dim">/ unlimited</span>` : `${used}${unit} <span class="dim">/ ${max}${unit}</span>`);

async function pageDashboard() {
  const srvs = await api('GET', '/servers');
  $('srv-count-badge').textContent = srvs.length;
  srvs.filter((x) => x.status === 'starting').forEach((x) => watchStart(x.id));
  return `<div class="stats-row">
    <div class="stat-card"><div class="stat-lbl">Servers</div><div class="stat-val">${srvs.length}</div><div class="stat-sub">${srvs.filter((s) => s.status === 'running').length} running</div></div>
    <div class="stat-card"><div class="stat-lbl">RAM used</div><div class="stat-val stat-sm">${limitText(ME.usedRam, ME.ram, ' GB')}</div><div class="stat-sub">of your pool</div></div>
    <div class="stat-card"><div class="stat-lbl">CPU used</div><div class="stat-val stat-sm">${limitText(ME.usedCpu, ME.cpu, '%')}</div><div class="stat-sub">100% = 1 core</div></div>
    <div class="stat-card"><div class="stat-lbl">Your Coins</div><div class="stat-val">${num(ME.coins)}</div><div class="stat-sub">earn more on the AFK page</div></div>
  </div>
  <div class="sec-row"><div class="sec-title">Your servers</div><div class="sec-cnt">${srvs.length}</div></div>
  <div class="servers-grid">${srvs.map(srvCard).join('') || emptyMsg('No servers yet. Click "+ New Server" to create one!')}</div>`;
}

async function pageServers() {
  const srvs = await api('GET', '/servers');
  $('srv-count-badge').textContent = srvs.length;
  srvs.filter((x) => x.status === 'starting').forEach((x) => watchStart(x.id));
  return `<div class="sec-row" style="margin-bottom:16px;">
    <div class="sec-title">Your servers</div><div class="sec-cnt">${srvs.length}</div>
    <button class="btn btn-primary" style="margin-left:auto;" onclick="openNewServer()">+ New Server</button>
  </div>
  <div class="servers-grid">${srvs.map(srvCard).join('') || emptyMsg('No servers yet.')}</div>`;
}

/* ═══ NEW SERVER ═══ */
async function fillVersions(selectEl, type, selected) {
  selectEl.innerHTML = '<option>Loading…</option>';
  selectEl.disabled = true;
  try {
    const r = await api('GET', '/versions/' + type);
    const list = ['LATEST', ...r.versions];
    if (selected && !list.includes(selected)) list.splice(1, 0, selected);
    selectEl.innerHTML = list.map((v) => `<option value="${esc(v)}" ${v === selected ? 'selected' : ''}>${v === 'LATEST' ? 'Latest' : esc(v)}</option>`).join('');
    selectEl.dataset.source = r.source;
  } catch (e) { selectEl.innerHTML = '<option value="LATEST">Latest</option>'; }
  selectEl.disabled = false;
}

const TYPE_NOTE = {
  spigot: 'Spigot is built on the first start, this can take a few minutes.',
  forge:  'Forge needs a version that has a Forge release.',
};

async function openNewServer() {
  await refreshMe();
  const nodeList = (await api('GET', '/nodes').catch(() => [])).filter((n) => n.online);
  const ramLeft = ME.ram === null ? 256 : Math.max(0, ME.ram - ME.usedRam);
  const cpuLeft = ME.cpu === null ? 10000 : Math.max(0, ME.cpu - ME.usedCpu);
  const blocked = ramLeft < 1 || cpuLeft < 10;
  const quota = ME.ram === null ? 'Administrator: no limits.' : `You can still use <b>${ramLeft} GB</b> RAM and <b>${cpuLeft}%</b> CPU. Each server gets <b>${ME.diskPerServer} GB</b> disk.`;

  $('modal-root').innerHTML = `
  <div class="modal-overlay open" id="ns-modal" onclick="if(event.target===this)closeModal('ns-modal')">
    <div class="modal" style="width:560px;">
      <div class="modal-hdr"><div><div class="modal-title">New Server</div><div class="modal-meta">${quota}</div></div>
        <div class="modal-close" onclick="closeModal('ns-modal')"><svg viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></div></div>
      <div class="modal-body"><div style="padding:20px;">
        ${blocked ? `<div class="warn">You have no RAM or CPU left. Delete a server or buy more in the Shop.</div>` : ''}
        <div class="ns-form">
          <div class="ns-field full"><label>SERVER NAME</label><input id="ns-name" maxlength="32" placeholder="My Survival Server"></div>
          <div class="ns-field"><label>TYPE</label><select id="ns-type">${TYPES.map((t) => `<option value="${t}">${TYPE_NAMES[t]}</option>`).join('')}</select></div>
          <div class="ns-field"><label>VERSION</label><select id="ns-ver"></select></div>
          <div class="ns-field full"><div id="ns-note" class="help" style="margin:0;"></div></div>
          <div class="ns-field"><label>PORT</label><input id="ns-port" type="number" min="1024" max="65535" value="25565"></div>
          <div class="ns-field"><label>RAM (GB)</label><input id="ns-ram" type="number" min="1" max="${ramLeft}" value="${Math.min(2, ramLeft) || 1}"></div>
          <div class="ns-field"><label>CPU (%) <span class="dim">100 = 1 core</span></label><input id="ns-cpu" type="number" min="10" max="${cpuLeft}" step="10" value="${Math.min(100, cpuLeft) || 10}"></div>
          <div class="ns-field"><label>DISK (GB)</label>${isAdmin
            ? `<input id="ns-disk" type="number" min="1" value="${ME.diskPerServer}">`
            : `<input id="ns-disk" value="${ME.diskPerServer} (fixed)" disabled>`}</div>
          ${nodeList.length ? `<div class="ns-field full"><label>RUN ON</label><select id="ns-node"><option value="">This panel (local)</option>${nodeList.map((n) => `<option value="${esc(n.id)}">${esc(n.name)}</option>`).join('')}</select></div>` : ''}
        </div>
        <div style="display:flex;gap:8px;margin-top:18px;">
          <button class="btn btn-ghost" onclick="closeModal('ns-modal')">Cancel</button>
          <button class="btn btn-primary" style="margin-left:auto;" ${blocked ? 'disabled' : ''} onclick="submitNewServer()">Create Server</button>
        </div>
      </div></div>
    </div>
  </div>`;
  const typeSel = $('ns-type'), verSel = $('ns-ver');
  const onType = () => { fillVersions(verSel, typeSel.value); $('ns-note').textContent = TYPE_NOTE[typeSel.value] || ''; };
  typeSel.addEventListener('change', onType);
  onType();
}

async function submitNewServer() {
  const body = {
    name: $('ns-name').value.trim(), type: $('ns-type').value, version: $('ns-ver').value,
    port: $('ns-port').value, ram: $('ns-ram').value, cpu: $('ns-cpu').value,
    nodeId: $('ns-node')?.value || null,
  };
  if (isAdmin) body.disk = $('ns-disk').value;
  try {
    await api('POST', '/servers', body);
    closeModal('ns-modal');
    toast('Server created!', 'success');
    renderPage(currentPage());
  } catch (e) { toast(e.message, 'error'); }
}

/* ═══ SERVER MODAL ═══ */
let S = null;      // state of the open server modal { srv, path, editing }

const TABS = [['console', 'Console'], ['files', 'Files'], ['plugins', 'Plugins'], ['players', 'Players'], ['startup', 'Startup'], ['version', 'Version'], ['backup', 'Backups']];

async function openServerModal(id) {
  const srv = (await api('GET', '/servers')).find((s) => s.id === id);
  if (!srv) return;
  S = { srv, path: '', editing: null, dirty: false };
  const on = srv.status === 'running';
  $('modal-root').innerHTML = `
  <div class="modal-overlay open" id="srv-modal" onclick="if(event.target===this)closeModal('srv-modal')">
    <div class="modal">
      <div class="modal-hdr">
        <div class="sc-ico ${esc(srv.type)}" style="width:36px;height:36px;border-radius:8px;flex-shrink:0;display:flex;align-items:center;justify-content:center;">
          <svg viewBox="0 0 24 24" style="width:20px;height:20px;fill:currentColor"><rect x="2" y="2" width="20" height="8" rx="2"/><rect x="2" y="14" width="20" height="8" rx="2"/></svg>
        </div>
        <div style="min-width:0"><div class="modal-title">${esc(srv.name)}</div><div class="modal-meta" id="srv-meta">${esc(TYPE_NAMES[srv.type])} ${esc(srv.version)} · :${esc(srv.port)}</div></div>
        <div style="margin-left:auto;display:flex;gap:7px;align-items:center;">
          ${pill(srv.status)}
          ${on
            ? `<button class="btn btn-danger sm" onclick="srvAction('${esc(srv.id)}','stop')">Stop</button><button class="btn btn-ghost sm" onclick="srvAction('${esc(srv.id)}','restart')">Restart</button>`
            : srv.status === 'starting'
              ? `<button class="btn btn-ghost sm" disabled>Starting…</button>`
              : `<button class="btn btn-success sm" onclick="srvAction('${esc(srv.id)}','start')">Start</button>`}
          <button class="btn btn-ghost sm" title="Delete server" onclick="deleteServer('${esc(srv.id)}')">Delete</button>
          <div class="modal-close" onclick="closeModal('srv-modal')"><svg viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></div>
        </div>
      </div>
      <div class="modal-tabs">${TABS.map(([k, label], i) => `<div class="modal-tab ${i ? '' : 'active'}" data-tab="${k}" onclick="switchMTab('${k}')">${label}</div>`).join('')}</div>
      <div class="modal-body">
        <div class="modal-panel active" id="tab-console">
          ${srv.status === 'starting' ? `<div class="help">Starting… the first start downloads the game files and can take several minutes. You will get a message when it is ready.</div>` : ''}
          ${srv.status === 'offline' && srv.lastError ? `<div class="warn"><b>The last start failed:</b> ${esc(srv.lastError)}</div>` : ''}
          <div class="console-wrap">
            <div class="con-hdr"><div class="cdots"><div class="cdot cr"></div><div class="cdot cy"></div><div class="cdot cg"></div></div><div class="con-label">${esc(srv.name)} — Docker</div></div>
            <div class="con-body" id="con-body">${on ? '' : '<div class="ll li">Server is not running. Press Start to boot it.</div>'}</div>
            <div class="con-inp-row"><span class="con-prompt">$</span><input class="con-inp" id="con-inp" placeholder="Enter command…"></div>
          </div>
        </div>
        ${TABS.slice(1).map(([k]) => `<div class="modal-panel" id="tab-${k}"></div>`).join('')}
      </div>
    </div>
  </div>`;
  wireConsole(srv);
}

function wireConsole(srv) {
  const addLine = (text, cls) => {
    const body = $('con-body'); if (!body) return;
    const d = document.createElement('div'); d.className = 'll ' + cls; d.textContent = text;
    body.appendChild(d); body.scrollTop = body.scrollHeight;
  };
  socket.emit('join-server', srv.id);
  socket.on('log-history', (lines) => {
    const body = $('con-body'); if (!body) return;
    body.innerHTML = lines.map((l) => `<div class="ll li">${esc(l)}</div>`).join('');
    body.scrollTop = body.scrollHeight;
  });
  socket.on('log-line', (line) => addLine(line, 'li'));
  socket.on('cmd-result', (out) => addLine(out, 'ls'));
  $('con-inp').addEventListener('keydown', (e) => {
    if (e.key !== 'Enter' || !e.target.value.trim()) return;
    addLine('$ ' + e.target.value.trim(), 'lt');
    socket.emit('exec-cmd', { serverId: srv.id, cmd: e.target.value.trim() });
    e.target.value = '';
  });
}

const TAB_LOADERS = { files: () => loadFiles(S.path), plugins: loadPlugins, players: loadPlayers, startup: loadStartup, version: loadVersion, backup: loadBackups };

function switchMTab(id) {
  if (S && S.editing && S.dirty && id !== 'files' && !confirm('You have unsaved changes in the editor. Leave anyway?')) return;
  document.querySelectorAll('.modal-tab').forEach((t) => t.classList.toggle('active', t.dataset.tab === id));
  document.querySelectorAll('.modal-panel').forEach((p) => p.classList.remove('active'));
  $('tab-' + id)?.classList.add('active');
  if (TAB_LOADERS[id]) TAB_LOADERS[id]().catch((e) => { $('tab-' + id).innerHTML = `<div class="warn">${esc(e.message)}</div>`; });
}

async function srvAction(id, action) {
  try {
    await api('POST', `/servers/${id}/${action}`);
    closeModal('srv-modal');
    if (action === 'start') {
      toast('Starting… the first start downloads the game files and can take a few minutes.', 'success');
      watchStart(id);
    } else toast(action === 'stop' ? 'Server stopped.' : 'Server restarting…', 'success');
    renderPage(currentPage());
  } catch (e) { toast(e.message, 'error'); }
}

/** Follows a server that is starting and tells you how it went (including WHY, when it failed). */
const WATCH = new Set();
async function watchStart(id) {
  if (WATCH.has(id)) return;
  WATCH.add(id);
  const t0 = Date.now();
  try {
    for (;;) {
      await sleep(2500);
      const s = (await api('GET', '/servers')).find((x) => x.id === id);
      if (!s) break;
      if (s.status !== 'starting') {
        if (s.status === 'running') toast(`${s.name} is online!`, 'success');
        else toast(`${s.name} could not start: ${s.lastError || 'unknown error'}`, 'error');
        if (['dashboard', 'servers'].includes(currentPage())) renderPage(currentPage());
        break;
      }
      if (Date.now() - t0 > 20 * 60 * 1000) break;
    }
  } catch {} finally { WATCH.delete(id); }
}

async function deleteServer(id, force = false) {
  if (!force && !confirm('Delete this server and ALL its files? This cannot be undone.')) return;
  try {
    await api('DELETE', `/servers/${id}${force ? '?force=1' : ''}`);
    toast('Server deleted.', 'success');
    closeModal('srv-modal');
    renderPage(currentPage());
  } catch (e) {
    if (isAdmin && !force && confirm(`${e.message}\n\nForce-remove the server record anyway?`)) return deleteServer(id, true);
    toast(e.message, 'error');
  }
}

function closeModal(id) {
  if (id === 'srv-modal' && S && S.editing && S.dirty && !confirm('You have unsaved changes in the editor. Close anyway?')) return;
  if (id === 'srv-modal') { socket.emit('leave-server'); socket.off('log-history'); socket.off('log-line'); socket.off('cmd-result'); S = null; }
  $(id)?.remove();
}

/* ── Files ── */
const joinPath = (a, b) => (a ? a + '/' + b : b);
const ICON_DIR  = '<svg viewBox="0 0 24 24" style="width:15px;height:15px"><path d="M3 6a2 2 0 012-2h4l2 2h8a2 2 0 012 2v10a2 2 0 01-2 2H5a2 2 0 01-2-2z"/></svg>';
const ICON_FILE = '<svg viewBox="0 0 24 24" style="width:15px;height:15px;fill:none;stroke:var(--sl-400);stroke-width:2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>';
const filesUrl = (p) => `/servers/${S.srv.id}/files?path=${encodeURIComponent(p)}`;

async function loadFiles(path) {
  S.path = path; S.editing = null; S.dirty = false;
  const el = $('tab-files');
  const list = await api('GET', filesUrl(path));
  list.sort((a, b) => (b.isDir - a.isDir) || a.name.localeCompare(b.name));
  const parts = path ? path.split('/') : [];
  const crumbs = [`<a data-act="dir" data-path="">/ server</a>`].concat(parts.map((p, i) => `<a data-act="dir" data-path="${esc(parts.slice(0, i + 1).join('/'))}">${esc(p)}</a>`)).join(' <span class="dim">/</span> ');
  el.innerHTML = `
    <div class="fm-bar"><div class="fm-crumbs">${crumbs}</div>
      <div style="display:flex;gap:6px;flex-wrap:wrap;"><button class="btn btn-primary sm" data-act="upload-files">Upload files</button><button class="btn btn-primary sm" data-act="upload-folder">Upload folder</button><button class="btn btn-ghost sm" data-act="newfile">New file</button><button class="btn btn-ghost sm" data-act="newdir">New folder</button><button class="btn btn-ghost sm" data-act="refresh">Refresh</button></div></div>
    <input type="file" id="up-files" multiple hidden><input type="file" id="up-folder" webkitdirectory multiple hidden>
    <div id="up-box">${UP ? '' : ''}</div>
    <div class="dim up-hint">Drag files or a whole folder from your computer into this window to upload them here (max ${MAX_UPLOAD_MB} MB per file).</div>
    <table class="file-table"><thead><tr><th>Name</th><th style="width:90px">Size</th><th style="width:170px">Modified</th><th style="width:110px"></th></tr></thead><tbody>
      ${path ? `<tr class="fm-row" data-act="dir" data-path="${esc(parts.slice(0, -1).join('/'))}"><td colspan="4"><div class="fn folder">${ICON_DIR} ..</div></td></tr>` : ''}
      ${list.map((f) => { const p = joinPath(path, f.name); return `<tr class="fm-row" data-act="${f.isDir ? 'dir' : 'edit'}" data-path="${esc(p)}">
        <td><div class="fn ${f.isDir ? 'folder' : ''}">${f.isDir ? ICON_DIR : ICON_FILE} ${esc(f.name)}</div></td>
        <td class="dim mono">${f.isDir ? '—' : fmtSize(f.size)}</td>
        <td class="dim" style="font-size:11px;">${new Date(f.mtime).toLocaleString()}</td>
        <td style="text-align:right;white-space:nowrap;">${f.isDir ? '' : `<button class="mini" data-act="edit" data-path="${esc(p)}">Edit</button>`}<button class="mini red" data-act="del" data-path="${esc(p)}" data-dir="${f.isDir ? 1 : 0}">Delete</button></td></tr>`; }).join('')
        || (path ? '' : '<tr><td colspan="4" class="dim" style="padding:18px;text-align:center;">No files yet. Start the server once to generate them.</td></tr>')}
    </tbody></table>`;
  bindUploads(el);
}

/* ── Upload from your computer: files, folders, drag & drop ── */
const MAX_UPLOAD_MB = 500;
let UP = null;       // upload in progress

function putFile(serverId, relPath, file, onProgress) {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    UP.xhr = xhr;
    xhr.open('PUT', `/api/servers/${serverId}/files/upload?path=${encodeURIComponent(relPath)}`);
    xhr.setRequestHeader('Content-Type', 'application/octet-stream');
    xhr.upload.onprogress = (e) => onProgress && onProgress(e.loaded);
    xhr.onload = () => {
      let d = {}; try { d = JSON.parse(xhr.responseText); } catch {}
      if (xhr.status >= 200 && xhr.status < 300) resolve(d);
      else if (xhr.status === 401) location.href = '/auth/login';
      else reject(new Error(d.error || `Upload failed (${xhr.status})`));
    };
    xhr.onerror = () => reject(new Error('Network error during the upload'));
    xhr.onabort = () => reject(new Error('Cancelled'));
    xhr.send(file);
  });
}

/** items: [{ file, rel }] with rel like "name.jar" or "world/region/r.0.0.mca". dirs: empty folders to create. */
async function uploadFiles(items, dirs = []) {
  if (!S) return;
  if (UP) return toast('An upload is already running. Wait for it or cancel it.', 'error');
  const base = S.path, srvId = S.srv.id, max = MAX_UPLOAD_MB * 1024 * 1024;
  items = items.filter((i) => i.rel && i.file);
  if (!items.length && !dirs.length) return;
  const total = items.reduce((a, i) => a + i.file.size, 0);
  UP = { cancel: false, xhr: null };
  const failed = []; let done = 0, sent = 0, cur = '';

  const paint = (loaded = 0) => {
    const box = $('up-box'); if (!box || !UP) return;
    const pct = total ? Math.min(100, Math.round(((sent + loaded) / total) * 100)) : 100;
    box.innerHTML = `<div class="up-box"><div class="up-row"><b>Uploading ${Math.min(done + 1, items.length)} / ${items.length}</b>
      <span class="dim up-name">${esc(cur)}</span><span class="dim">${fmtSize(sent + loaded)} of ${fmtSize(total)} (${pct}%)</span>
      <button class="mini red" data-act="up-cancel">Cancel</button></div><div class="up-bar"><div style="width:${pct}%"></div></div></div>`;
  };

  for (const d of dirs) { try { await api('POST', `/servers/${srvId}/files/mkdir`, { path: joinPath(base, d) }); } catch {} }
  for (const { file, rel } of items) {
    if (UP.cancel) break;
    cur = rel; paint();
    if (file.size > max) { failed.push(`${rel}: bigger than ${MAX_UPLOAD_MB} MB`); done++; continue; }
    try { await putFile(srvId, joinPath(base, rel), file, paint); sent += file.size; }
    catch (e) {
      if (UP.cancel) break;
      failed.push(`${rel}: ${e.message}`);
      if (/Disk limit/i.test(e.message)) break;          // every other file would fail the same way
    }
    done++;
  }
  const cancelled = UP.cancel; UP = null;
  const box = $('up-box'); if (box) box.innerHTML = '';
  const okCount = items.length - failed.length - (cancelled ? items.length - done : 0);
  if (cancelled) toast(`Upload cancelled. ${Math.max(okCount, 0)} file(s) were uploaded.`, 'error');
  else if (failed.length) { toast(`${okCount} uploaded, ${failed.length} failed. ${failed[0]}`, 'error'); if (failed.length > 1) console.warn('Upload errors:\n' + failed.join('\n')); }
  else toast(`Uploaded ${items.length} file${items.length === 1 ? '' : 's'}.`, 'success');
  if (S && S.srv.id === srvId && !S.editing && $('tab-files')?.classList.contains('active')) await loadFiles(S.path);
}

/** Dropped files and folders -> { items, dirs }. Must read dataTransfer.items before the first await. */
async function collectDropped(dt) {
  const entries = [...(dt.items || [])].map((i) => (i.webkitGetAsEntry ? i.webkitGetAsEntry() : null)).filter(Boolean);
  const items = [], dirs = [];
  if (!entries.length) return { items: [...(dt.files || [])].map((f) => ({ file: f, rel: f.name })), dirs };
  const readAll = async (reader) => { const all = []; for (;;) { const b = await new Promise((res, rej) => reader.readEntries(res, rej)); if (!b.length) return all; all.push(...b); } };
  const walk = async (entry, prefix) => {
    if (entry.isFile) { items.push({ file: await new Promise((res, rej) => entry.file(res, rej)), rel: prefix + entry.name }); return 1; }
    if (!entry.isDirectory) return 0;
    let n = 0;
    for (const child of await readAll(entry.createReader())) n += await walk(child, prefix + entry.name + '/');
    if (!n) dirs.push(prefix + entry.name);            // empty folder: keep it
    return n;
  };
  for (const e of entries) await walk(e, '');
  return { items, dirs };
}

function bindUploads(el) {
  const fromInput = (inp, folder) => inp.addEventListener('change', () => {
    const files = [...inp.files];
    inp.value = '';
    uploadFiles(files.map((f) => ({ file: f, rel: folder && f.webkitRelativePath ? f.webkitRelativePath : f.name })));
  });
  fromInput($('up-files'), false); fromInput($('up-folder'), true);
  el.addEventListener('dragover', (e) => { if (S && S.editing) return; e.preventDefault(); el.classList.add('fm-drop-active'); });
  el.addEventListener('dragleave', (e) => { if (e.target === el) el.classList.remove('fm-drop-active'); });
  el.addEventListener('drop', async (e) => {
    e.preventDefault(); el.classList.remove('fm-drop-active');
    if (S && S.editing) return;
    try { const { items, dirs } = await collectDropped(e.dataTransfer); await uploadFiles(items, dirs); }
    catch (err) { toast(err.message, 'error'); }
  });
}

async function openEditor(path) {
  const text = await apiText(`/servers/${S.srv.id}/files/read?path=${encodeURIComponent(path)}`);
  S.editing = path; S.dirty = false;
  $('tab-files').innerHTML = `
    <div class="fm-bar"><div class="fm-crumbs"><b>${esc(path)}</b></div>
      <div style="display:flex;gap:6px;"><button class="btn btn-ghost sm" data-act="closeedit">Back</button><button class="btn btn-primary sm" data-act="save">Save</button></div></div>
    <textarea id="editor" class="editor" spellcheck="false"></textarea>
    <div class="dim" style="font-size:11px;margin-top:6px;">Tip: Ctrl+S saves. Changes to server files are used after a restart.</div>`;
  const ed = $('editor'); ed.value = text;
  ed.addEventListener('input', () => { S.dirty = true; });
  ed.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') { e.preventDefault(); saveEditor(); }
    if (e.key === 'Tab') { e.preventDefault(); const s = ed.selectionStart; ed.setRangeText('  ', s, ed.selectionEnd, 'end'); S.dirty = true; }
  });
}
async function saveEditor() {
  await api('POST', `/servers/${S.srv.id}/files/write`, { path: S.editing, content: $('editor').value });
  S.dirty = false; toast('Saved.', 'success');
}

$('modal-root').addEventListener('click', async (e) => {
  const t = e.target.closest('[data-act]');
  if (!t || !S) return;
  const act = t.dataset.act, path = t.dataset.path;
  if (t.tagName === 'TR' && e.target.closest('button')) return;   // buttons inside a row handle themselves
  try {
    const leaveOk = () => !(S.editing && S.dirty) || confirm('You have unsaved changes. Leave anyway?');
    if (act === 'dir')       { if (leaveOk()) await loadFiles(path); }
    else if (act === 'refresh') await loadFiles(S.path);
    else if (act === 'upload-files')  $('up-files').click();
    else if (act === 'upload-folder') $('up-folder').click();
    else if (act === 'up-cancel') { if (UP) { UP.cancel = true; if (UP.xhr) UP.xhr.abort(); } }
    else if (act === 'edit')    await openEditor(path);
    else if (act === 'save')    await saveEditor();
    else if (act === 'closeedit') { if (leaveOk()) await loadFiles(S.path); }
    else if (act === 'newfile') {
      const n = (prompt('File name (e.g. config.yml):') || '').trim(); if (!n) return;
      if (/[\\/]/.test(n) || n === '..') return toast('Use a plain name, no slashes.', 'error');
      await api('POST', `/servers/${S.srv.id}/files/write`, { path: joinPath(S.path, n), content: '' });
      await openEditor(joinPath(S.path, n));
    } else if (act === 'newdir') {
      const n = (prompt('Folder name:') || '').trim(); if (!n) return;
      if (/[\\/]/.test(n) || n === '..') return toast('Use a plain name, no slashes.', 'error');
      await api('POST', `/servers/${S.srv.id}/files/mkdir`, { path: joinPath(S.path, n) });
      await loadFiles(S.path);
    } else if (act === 'del') {
      if (!confirm(`Delete "${path.split('/').pop()}"${t.dataset.dir === '1' ? ' and everything inside it' : ''}?`)) return;
      await api('POST', `/servers/${S.srv.id}/files/delete`, { path });
      await loadFiles(S.path);
    } else if (act === 'install') await installPlugin(t.dataset.source, t.dataset.id, t.dataset.title, t);
    else if (act === 'rmplugin') {
      if (!confirm(`Remove ${path}?`)) return;
      await api('DELETE', `/servers/${S.srv.id}/plugins/${encodeURIComponent(path)}`);
      toast('Removed.', 'success'); await refreshInstalled();
    } else if (act === 'cmd') await playerCmd(t.dataset.cmd);
    else if (act === 'search') await runSearch();
    else if (act === 'players-refresh') await loadPlayers();
    else if (act === 'rmbackup') { await api('DELETE', `/servers/${S.srv.id}/backups/${encodeURIComponent(path)}`); await loadBackups(); }
    else if (act === 'mkbackup') { t.disabled = true; try { const b = await api('POST', `/servers/${S.srv.id}/backups`); toast(`Backup created: ${b.file}`, 'success'); } finally { t.disabled = false; } await loadBackups(); }
  } catch (err) { toast(err.message, 'error'); }
});

/* ── Plugins & mods ── */
let PL = { source: 'modrinth' };
const dl = (n) => (n >= 1e6 ? (n / 1e6).toFixed(1) + 'M' : n >= 1e3 ? (n / 1e3).toFixed(1) + 'K' : String(n));

async function loadPlugins() {
  const info = await api('GET', `/servers/${S.srv.id}/plugins`);
  const el = $('tab-plugins');
  if (!info.supported) {
    el.innerHTML = `<div class="warn">Vanilla servers cannot use plugins or mods. Switch to Paper, Spigot, Purpur (plugins) or Fabric, Forge (mods) in the <b>Version</b> tab.</div>`;
    return;
  }
  const kind = info.folder === 'mods' ? 'mods' : 'plugins';
  const spigotOk = ['paper', 'spigot', 'purpur'].includes(S.srv.type);
  el.innerHTML = `
    <div class="pl-title">Installed ${kind} <span class="dim">(${esc(info.folder)}/)</span></div>
    <div id="pl-installed"></div>
    <div class="pl-title" style="margin-top:22px;">Find ${kind}</div>
    <div class="pl-search">
      <select id="pl-source"><option value="modrinth">Modrinth</option>${spigotOk ? '<option value="spiget">Spigot</option>' : ''}</select>
      <input id="pl-q" placeholder="Search ${kind}… (leave empty for the most popular)">
      <button class="btn btn-primary sm" data-act="search">Search</button>
    </div>
    ${help(`Only ${kind} that work with <b>${esc(TYPE_NAMES[S.srv.type])} ${esc(S.srv.version)}</b> are installed. Restart the server afterwards to load them.`)}
    <div id="pl-results" class="pl-results"></div>`;
  renderInstalled(info.files);
  $('pl-source').addEventListener('change', (e) => { PL.source = e.target.value; runSearch(); });
  $('pl-q').addEventListener('keydown', (e) => { if (e.key === 'Enter') runSearch(); });
  $('pl-source').value = PL.source === 'spiget' && spigotOk ? 'spiget' : 'modrinth';
  PL.source = $('pl-source').value;
  runSearch();
}

function renderInstalled(files) {
  $('pl-installed').innerHTML = files.length
    ? files.map((f) => `<div class="pl-inst"><span class="mono">${esc(f.name)}</span><span class="dim">${fmtSize(f.size)}</span><button class="mini red" data-act="rmplugin" data-path="${esc(f.name)}">Remove</button></div>`).join('')
    : '<div class="dim" style="padding:6px 0;">Nothing installed yet.</div>';
}
async function refreshInstalled() { const info = await api('GET', `/servers/${S.srv.id}/plugins`); renderInstalled(info.files); }

async function runSearch() {
  const box = $('pl-results'); if (!box) return;
  const source = $('pl-source').value, q = $('pl-q').value.trim();
  box.innerHTML = '<div class="dim" style="padding:14px;">Searching…</div>';
  try {
    const r = await api('GET', `/plugins/search?source=${source}&q=${encodeURIComponent(q)}&type=${S.srv.type}&version=${encodeURIComponent(S.srv.version)}`);
    box.innerHTML = r.results.map((p) => `<div class="pl-card">
        ${p.icon ? `<img src="${esc(p.icon)}" alt="" loading="lazy" referrerpolicy="no-referrer">` : '<div class="pl-noimg"></div>'}
        <div style="flex:1;min-width:0;"><div class="pl-name">${esc(p.title)} ${p.author ? `<span class="dim">by ${esc(p.author)}</span>` : ''}</div>
          <div class="pl-desc">${esc(p.description)}</div><div class="dim" style="font-size:11px;">${dl(p.downloads)} downloads</div></div>
        <button class="btn btn-success sm" data-act="install" data-source="${esc(p.source)}" data-id="${esc(p.id)}" data-title="${esc(p.title)}">Install</button>
      </div>`).join('') || '<div class="dim" style="padding:14px;">No results for this server version.</div>';
  } catch (e) { box.innerHTML = `<div class="warn">${esc(e.message)}</div>`; }
}

async function installPlugin(source, id, title, btn) {
  btn.disabled = true; const old = btn.textContent; btn.textContent = 'Installing…';
  try {
    const r = await api('POST', `/servers/${S.srv.id}/plugins/install`, { source, id });
    toast(`Installed ${r.file}. Restart the server to load it.`, 'success');
    await refreshInstalled();
  } finally { btn.disabled = false; btn.textContent = old; }
}

/* ── Players ── */
async function loadPlayers() {
  const el = $('tab-players');
  el.innerHTML = '<div class="dim" style="padding:14px;">Loading players…</div>';
  const r = await api('GET', `/servers/${S.srv.id}/players`);
  if (!r.online) { el.innerHTML = `<div class="warn">The server is offline. Start it to see who is playing.</div>`; return; }
  el.innerHTML = `
    <div class="fm-bar"><div class="fm-crumbs"><b>${r.count}</b> player${r.count === 1 ? '' : 's'} online${r.max ? ` <span class="dim">of ${r.max}</span>` : ''}</div>
      <button class="btn btn-ghost sm" data-act="players-refresh">Refresh</button></div>
    ${r.players.length ? r.players.map((n) => `<div class="pl-row"><div class="pl-av">${esc(n.replace(/^\./, '').slice(0, 2).toUpperCase())}</div><div class="pl-name" style="flex:1">${esc(n)}</div>
        <button class="mini" data-act="cmd" data-cmd="op ${esc(n)}">OP</button><button class="mini" data-act="cmd" data-cmd="deop ${esc(n)}">De-OP</button>
        <button class="mini" data-act="cmd" data-cmd="kick ${esc(n)}">Kick</button><button class="mini red" data-act="cmd" data-cmd="ban ${esc(n)}">Ban</button></div>`).join('')
      : '<div class="dim" style="padding:18px;text-align:center;">Nobody is online right now.</div>'}`;
}
async function playerCmd(cmd) {
  const r = await api('POST', `/servers/${S.srv.id}/command`, { cmd });
  toast(r.output || 'Done.', 'success');
  setTimeout(() => S && loadPlayers().catch(() => {}), 800);
}

/* ── Startup ── */
async function loadStartup() {
  const st = { motd: 'A Minecraft Server', maxPlayers: 20, onlineMode: false, jvmOpts: '', ...(S.srv.startup || {}) };
  $('tab-startup').innerHTML = `
    ${help('These settings are used every time the server starts. Press <b>Restart</b> after saving to apply them.')}
    <div class="ns-form">
      <div class="ns-field full"><label>MOTD <span class="dim">(the text under the server name in the game list)</span></label><input id="st-motd" maxlength="100" value="${esc(st.motd)}"></div>
      <div class="ns-field"><label>MAX PLAYERS</label><input id="st-max" type="number" min="1" max="1000" value="${esc(st.maxPlayers)}"></div>
      <div class="ns-field"><label>ONLINE MODE <span class="dim">(checks accounts with Mojang)</span></label>
        <select id="st-online"><option value="false" ${st.onlineMode ? '' : 'selected'}>Off: cracked/offline clients can join</option><option value="true" ${st.onlineMode ? 'selected' : ''}>On: only paid accounts, safer</option></select></div>
      <div class="ns-field full"><label>EXTRA JAVA FLAGS <span class="dim">(optional, advanced)</span></label><input id="st-jvm" maxlength="300" placeholder="-XX:+UseG1GC" value="${esc(st.jvmOpts)}"></div>
    </div>
    <div class="spec">
      <div><span class="dim">RAM</span> ${esc(S.srv.ram)} GB</div><div><span class="dim">CPU</span> ${esc(S.srv.cpu)}%</div>
      <div><span class="dim">Disk</span> ${esc(S.srv.disk)} GB</div><div><span class="dim">Port</span> ${esc(S.srv.port)}</div>
    </div>
    <div style="margin-top:14px;"><button class="btn btn-primary" onclick="saveStartup()">Save startup settings</button></div>`;
}
async function saveStartup() {
  try {
    const srv = await api('PATCH', `/servers/${S.srv.id}`, { startup: {
      motd: $('st-motd').value, maxPlayers: $('st-max').value, onlineMode: $('st-online').value === 'true', jvmOpts: $('st-jvm').value } });
    S.srv = srv; toast('Saved. Restart the server to apply.', 'success');
  } catch (e) { toast(e.message, 'error'); }
}

/* ── Version ── */
async function loadVersion() {
  $('tab-version').innerHTML = `
    ${help('Change the server software or Minecraft version. <b>Back up first</b>: worlds from newer versions may not load on older ones. Press Restart afterwards.')}
    <div class="ns-form">
      <div class="ns-field"><label>SOFTWARE</label><select id="vs-type">${TYPES.map((t) => `<option value="${t}" ${t === S.srv.type ? 'selected' : ''}>${TYPE_NAMES[t]}</option>`).join('')}</select></div>
      <div class="ns-field"><label>VERSION</label><select id="vs-ver"></select></div>
      <div class="ns-field full"><div id="vs-note" class="help" style="margin:0;"></div></div>
    </div>
    <div style="margin-top:14px;"><button class="btn btn-primary" onclick="saveVersion()">Save version</button></div>`;
  const t = $('vs-type'), v = $('vs-ver');
  const refresh = async (keep) => {
    await fillVersions(v, t.value, keep);
    $('vs-note').textContent = (TYPE_NOTE[t.value] || '') + (v.dataset.source === 'fallback' ? ' (Live version list unreachable, showing a built-in list.)' : '');
  };
  t.addEventListener('change', () => refresh(null));
  await refresh(S.srv.version);
}
async function saveVersion() {
  try {
    const srv = await api('PATCH', `/servers/${S.srv.id}`, { type: $('vs-type').value, version: $('vs-ver').value });
    S.srv = srv; $('srv-meta').textContent = `${TYPE_NAMES[srv.type]} ${srv.version} · :${srv.port}`;
    toast('Saved. Restart the server to apply.', 'success');
  } catch (e) { toast(e.message, 'error'); }
}

/* ── Backups ── */
async function loadBackups() {
  const bk = await api('GET', `/servers/${S.srv.id}/backups`);
  $('tab-backup').innerHTML = `
    <div style="display:flex;justify-content:flex-end;margin-bottom:12px;"><button class="btn btn-primary" data-act="mkbackup">Create Backup</button></div>
    <div class="backup-list">${bk.map((b) => `
      <div class="backup-item">
        <div class="backup-icon"><svg viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg></div>
        <div><div class="backup-name">${esc(b.file)}</div><div class="backup-meta">${new Date(b.createdAt).toLocaleString()}</div></div>
        <div style="margin-left:auto;display:flex;gap:10px;align-items:center;"><span class="mono" style="font-size:11px;">${fmtSize(b.size)}</span><button class="mini red" data-act="rmbackup" data-path="${esc(b.file)}">Delete</button></div>
      </div>`).join('') || '<p style="color:var(--sl-400);">No backups yet. A daily backup also runs at 03:00.</p>'}</div>`;
}

/* ═══ SHOP ═══ */
async function pageShop() {
  const item = (id, name, desc, price, cls = '') => `<div class="shop-card ${cls}"><div class="shop-name">${name}</div><div class="shop-desc">${desc}</div>
    <div class="shop-price">${price} <span>coins</span></div><button class="shop-btn" onclick="buy('${id}')">Buy Now</button></div>`;
  return `<div class="my-resources"><div class="my-res-title">Your Resources</div><div class="my-res-grid">
      <div class="my-res-item"><div class="mri-label">COINS</div><div class="mri-val">${num(ME.coins)}</div></div>
      <div class="my-res-item"><div class="mri-label">RAM POOL</div><div class="mri-val">${ME.ram === null ? 'Unlimited' : `${ME.usedRam} / ${ME.ram} GB`}</div></div>
      <div class="my-res-item"><div class="mri-label">CPU POOL</div><div class="mri-val">${ME.cpu === null ? 'Unlimited' : `${ME.usedCpu} / ${ME.cpu}%`}</div></div>
    </div></div>
    <div class="shop-grid">${item('ram-1', '1 GB RAM', 'Add 1 GB to your pool', 200, 'featured')}${item('ram-4', '4 GB RAM', 'Best value bundle', 700)}${item('cpu-100', '100 CPU', 'Add 100% CPU (1 core)', 250)}</div>
    ${help('Need coins? Claim your free daily reward on the <b>AFK</b> page.')}`;
}
async function buy(item) {
  try { const r = await api('POST', '/shop/buy', { item }); toast(`Purchased! Coins left: ${r.coins}`, 'success'); renderPage('shop'); }
  catch (e) { toast(e.message, 'error'); }
}

/* ═══ AFK: daily coins + ads ═══ */
let AFK = null;
const countdown = (iso) => {
  let s = Math.max(0, Math.floor((Date.parse(iso) - Date.now()) / 1000));
  const h = Math.floor(s / 3600); s -= h * 3600; const m = Math.floor(s / 60);
  return `${h}h ${String(m).padStart(2, '0')}m ${String(s - m * 60).padStart(2, '0')}s`;
};

async function pageAfk() {
  AFK = await api('GET', '/afk');
  const ad = AFK.ads;
  const adsOn = ad.enabled && ad.clientId && ad.slotId;
  const admin = isAdmin ? await adminAdsCard() : '';
  return `<div class="sec-row" style="margin-bottom:16px;"><div class="sec-title">AFK</div></div>
  <div class="card pad" style="max-width:560px;margin-bottom:18px;">
    <div class="card-title">Daily reward</div>
    <p class="muted">Claim <b>${num(AFK.reward)} coins</b> once every <b>${AFK.intervalHours} hours</b>. Spend them in the Shop for more RAM and CPU.</p>
    <div id="afk-claim" style="margin-top:12px;"></div>
  </div>
  ${adsOn ? `<div class="afk-section"><div class="afk-section-hdr"><div class="afk-status-dot"></div><div class="afk-title-text">Advertisement</div></div>
      <div class="afk-ad-frame"><ins class="adsbygoogle" style="display:block;width:100%;min-height:120px;" data-ad-client="${esc(ad.clientId)}" data-ad-slot="${esc(ad.slotId)}" data-ad-format="${esc(ad.format)}"></ins></div>
      <div class="afk-ad-info">Ads help keep ${esc(panelName)} running. Thank you!</div></div>` : ''}
  ${admin}`;
}

function paintClaim() {
  const el = $('afk-claim'); if (!el || !AFK) return;
  if (AFK.canClaim || Date.now() >= Date.parse(AFK.nextClaimAt)) {
    el.innerHTML = `<button class="btn btn-primary" onclick="claimAfk()">Claim ${num(AFK.reward)} coins</button>`;
  } else {
    el.innerHTML = `<div class="countdown">Next reward in <b>${countdown(AFK.nextClaimAt)}</b></div>`;
  }
}
function startAfk() {
  paintClaim();
  afkTimer = setInterval(paintClaim, 1000);
  const ad = AFK && AFK.ads;
  if (ad && ad.enabled && ad.clientId && ad.slotId) {
    if (!document.getElementById('adsense-js')) {
      const s = document.createElement('script');
      s.id = 'adsense-js'; s.async = true; s.crossOrigin = 'anonymous';
      s.src = 'https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=' + encodeURIComponent(ad.clientId);
      document.head.appendChild(s);
    }
    setTimeout(() => { try { (window.adsbygoogle = window.adsbygoogle || []).push({}); } catch {} }, 400);
  }
}
async function claimAfk() {
  try {
    const r = await api('POST', '/afk/claim');
    AFK = r; toast(`+${num(r.earned)} coins!`, 'success'); await refreshMe(); paintClaim();
  } catch (e) { toast(e.message, 'error'); }
}

async function adminAdsCard() {
  const s = await api('GET', '/settings');
  return `<div class="card pad" style="max-width:560px;">
    <div class="card-title">Ads <span class="badge">Admin only</span></div>
    <p class="muted">Show a Google AdSense ad on this page. Create an account at adsense.google.com, add an <b>ad unit</b>, then copy two numbers from it:</p>
    <ul class="muted" style="margin:6px 0 12px 18px;line-height:1.7;"><li><b>Publisher ID</b> looks like <code>ca-pub-1234567890123456</code></li><li><b>Ad slot ID</b> is the number in <code>data-ad-slot="…"</code></li></ul>
    <div class="ns-form">
      <div class="ns-field"><label>PUBLISHER ID</label><input id="ads-client" value="${esc(s.adClientId)}" placeholder="ca-pub-0000000000000000"></div>
      <div class="ns-field"><label>AD SLOT ID</label><input id="ads-slot" value="${esc(s.adSlotId)}" placeholder="1234567890"></div>
      <div class="ns-field full"><label><input type="checkbox" id="ads-on" ${s.adsEnabled ? 'checked' : ''} style="width:auto;margin-right:6px;">Show ads</label></div>
    </div>
    ${help('The ad is loaded once per visit. AdSense does not allow ads that refresh by themselves.')}
    <button class="btn btn-primary" onclick="saveAds()">Save ads</button>
  </div>`;
}
async function saveAds() {
  try {
    await api('POST', '/settings', { adClientId: $('ads-client').value.trim(), adSlotId: $('ads-slot').value.trim(), adsEnabled: $('ads-on').checked });
    toast('Ads saved.', 'success');
  } catch (e) { toast(e.message, 'error'); }
}

/* ═══ ADMIN: ALL SERVERS ═══ */
async function pageAdminServers() {
  const list = await api('GET', '/servers/all');
  return `${help('Moderation view: you can stop or delete servers here. Owners’ consoles and files stay private, even from admins.')}
  <table class="users-table"><thead><tr><th>Server</th><th>Owner</th><th>Software</th><th>Node</th><th>RAM / CPU</th><th>Status</th><th></th></tr></thead><tbody>
  ${list.map((s) => `<tr><td><b>${esc(s.name)}</b><div class="dim" style="font-size:11px;">:${esc(s.port)}</div></td><td>${esc(s.ownerName)}</td>
    <td>${esc(TYPE_NAMES[s.type] || s.type)} ${esc(s.version)}</td><td>${esc(s.nodeName)}</td><td>${esc(s.ram)} GB / ${esc(s.cpu)}%</td>
    <td>${pill(s.status)}</td>
    <td style="text-align:right;white-space:nowrap;"><button class="mini" onclick="adminStop('${esc(s.id)}')">Stop</button><button class="mini red" onclick="deleteServer('${esc(s.id)}')">Delete</button></td></tr>`).join('')
    || '<tr><td colspan="7" class="dim" style="padding:18px;text-align:center;">No servers yet.</td></tr>'}
  </tbody></table>`;
}
async function adminStop(id) {
  try { await api('POST', `/servers/${id}/stop`); toast('Stopped.', 'success'); renderPage('adminservers'); } catch (e) { toast(e.message, 'error'); }
}

/* ═══ NODES ═══ */
const installCmd = (token, name) => `curl -sSL ${location.origin}/install/agent.sh | sudo bash -s -- --panel ${location.origin} --key ${token} --name '${name}'`;
const manualCmd  = (token, name) => `cd phbai-agent && npm install && npm run configure -- --panel ${location.origin} --key ${token} --name '${name}' && npm start`;
let NODE_SECRET = null;      // { name, token } shown once

async function pageNodes() {
  const list = await api('GET', '/nodes');
  const secret = NODE_SECRET ? `
    <div class="card pad" style="border-color:var(--sky-400);margin-bottom:18px;">
      <div class="card-title">Connect “${esc(NODE_SECRET.name)}”</div>
      <p class="muted">Run this on the <b>other machine</b> (Linux, as root or with sudo). It installs Docker and Node.js if needed, then connects it to this panel.</p>
      <div class="npm-box cmd" id="cmd-auto">${esc(installCmd(NODE_SECRET.token, NODE_SECRET.name))}</div>
      <button class="btn btn-primary sm" onclick="copyText(installCmd(NODE_SECRET.token, NODE_SECRET.name))">Copy command</button>
      <details style="margin-top:12px;"><summary class="muted" style="cursor:pointer;">Install by hand instead</summary>
        <p class="muted" style="margin:8px 0;">Download the agent from <code>${esc(location.origin)}/install/agent.tgz</code>, unpack it into a folder called <code>phbai-agent</code>, then:</p>
        <div class="npm-box cmd">${esc(manualCmd(NODE_SECRET.token, NODE_SECRET.name))}</div>
        <button class="btn btn-ghost sm" onclick="copyText(manualCmd(NODE_SECRET.token, NODE_SECRET.name))">Copy</button></details>
      <p class="warn" style="margin-top:12px;">The key is shown only now. If you lose it, use “New key” on the node.</p>
    </div>` : '';
  return `<div class="sec-row" style="margin-bottom:12px;"><div class="sec-title">Nodes</div><div class="sec-cnt">${list.length}</div></div>
  ${help('A node is another machine that runs Minecraft servers for this panel. Add a node, then run the command it gives you on that machine.')}
  ${secret}
  <div class="card pad" style="margin-bottom:18px;">
    <div class="card-title">Add a node</div>
    <div style="display:flex;gap:8px;"><input id="node-name" class="plain" maxlength="40" placeholder="Name, e.g. Germany-1" style="flex:1;">
    <button class="btn btn-primary" onclick="addNode()">Add node</button></div>
  </div>
  <div style="display:flex;flex-direction:column;gap:9px;">
  ${list.map((n) => `<div class="token-item"><div style="min-width:0;flex:1;"><div class="token-name">${esc(n.name)}
      <span class="sp-pill ${n.online ? 's-on' : 's-off'}" style="margin-left:8px;"><span class="dot"></span>${n.online ? 'Online' : 'Offline'}</span></div>
    <div class="token-val">${n.tokenHash === undefined && !n.platform ? 'Waiting for the first connection' : esc(n.platform || '')}${n.docker ? ' · Docker ' + esc(n.docker) : ''}${n.dockerError ? ' · <b style="color:var(--red-500)">Docker not reachable</b>' : ''} · ${n.serverCount} server${n.serverCount === 1 ? '' : 's'}</div></div>
    <button class="token-copy" onclick="newNodeKey('${esc(n.id)}','${esc(n.name)}')">New key</button>
    <button class="token-copy" onclick="removeNode('${esc(n.id)}')">Remove</button></div>`).join('') || '<p style="color:var(--sl-400);">No nodes yet.</p>'}
  </div>`;
}
async function addNode() {
  try {
    const r = await api('POST', '/nodes', { name: $('node-name').value });
    NODE_SECRET = { name: r.node.name, token: r.token };
    renderPage('nodes');
  } catch (e) { toast(e.message, 'error'); }
}
async function newNodeKey(id, name) {
  if (!confirm('Create a new key? The old key stops working and the node disconnects until you run the new command.')) return;
  try { const r = await api('POST', `/nodes/${id}/token`); NODE_SECRET = { name, token: r.token }; renderPage('nodes'); }
  catch (e) { toast(e.message, 'error'); }
}
async function removeNode(id) {
  if (!confirm('Remove this node?')) return;
  try { await api('DELETE', '/nodes/' + id); NODE_SECRET = null; toast('Node removed', 'success'); renderPage('nodes'); }
  catch (e) { toast(e.message, 'error'); }
}

/* ═══ USERS ═══ */
async function pageUsers() {
  const list = await api('GET', '/users');
  return `<div class="sec-row" style="margin-bottom:16px;"><div class="sec-title">Users</div><div class="sec-cnt">${list.length}</div></div>
  ${help('Add or manage users from the terminal: <code>docker compose exec phpanel node scripts/user.js add NAME PASSWORD [--admin]</code>')}
  <table class="users-table"><thead><tr><th>Username</th><th>Email</th><th>Role</th><th>Coins</th><th>Pool</th><th>Joined</th></tr></thead><tbody>
  ${list.map((u) => `<tr><td><b>${esc(u.username)}</b></td><td style="color:var(--sl-500)">${esc(u.email || '—')}</td>
    <td><span class="role-badge ${u.role === 'admin' ? 'rb-admin' : 'rb-user'}">${esc(u.role)}</span></td><td>${num(u.coins)}</td>
    <td>${u.role === 'admin' ? 'unlimited' : `${esc(u.ram)} GB / ${esc(u.cpu)}%`}</td>
    <td style="color:var(--sl-400);font-size:11.5px;">${new Date(u.createdAt).toLocaleDateString()}</td></tr>`).join('')}
  </tbody></table>`;
}

/* ═══ SETTINGS ═══ */
async function pageSettings() {
  const s = await api('GET', '/settings');
  const f = (id, label, val, hint, type = 'number', extra = '') => `<div class="ns-field"><label>${label}</label><input id="${id}" type="${type}" value="${esc(val)}" ${extra}>${hint ? `<div class="hint2">${hint}</div>` : ''}</div>`;
  return `<div class="sec-row" style="margin-bottom:16px;"><div class="sec-title">Settings</div></div>
  <div class="card pad" style="max-width:640px;margin-bottom:16px;"><div class="card-title">General</div>
    <div class="ns-form">${f('set-name', 'PANEL NAME', s.panelName, 'Shown in the sidebar and on the login page.', 'text', 'maxlength="40"')}
      <div class="ns-field"><label>NEW ACCOUNTS</label><select id="set-reg"><option value="true" ${s.registrationOpen ? 'selected' : ''}>Anyone can register</option><option value="false" ${s.registrationOpen ? '' : 'selected'}>Closed (admin adds users)</option></select>
      <div class="hint2">Closed: use the terminal command on the Users page.</div></div></div></div>
  <div class="card pad" style="max-width:640px;margin-bottom:16px;"><div class="card-title">Resources for new users</div>
    <div class="ns-form">${f('set-ram', 'RAM POOL (GB)', s.defaultRam, 'Total RAM a new user can use across all servers.')}${f('set-cpu', 'CPU POOL (%)', s.defaultCpu, '100 = 1 core.')}
      ${f('set-disk', 'DISK PER SERVER (GB)', s.defaultDisk, 'Every new server gets this much. The server will not start if its files grow past it.')}</div>
    ${help('Changing these only affects <b>new</b> accounts and servers.')}</div>
  <div class="card pad" style="max-width:640px;margin-bottom:16px;"><div class="card-title">AFK reward</div>
    <div class="ns-form">${f('set-afk', 'COINS PER CLAIM', s.afkReward, '')}${f('set-afkh', 'HOURS BETWEEN CLAIMS', s.afkIntervalHours, '24 = once a day.')}</div></div>
  <button class="btn btn-primary" id="set-save">Save settings</button>
  ${help('Ads are configured on the <b>AFK</b> page.')}`;
}
function bindSettings() {
  $('set-save').addEventListener('click', async () => {
    try {
      const s = await api('POST', '/settings', {
        panelName: $('set-name').value, registrationOpen: $('set-reg').value === 'true',
        defaultRam: $('set-ram').value, defaultCpu: $('set-cpu').value, defaultDisk: $('set-disk').value,
        afkReward: $('set-afk').value, afkIntervalHours: $('set-afkh').value,
      });
      document.querySelector('.sb-name').textContent = s.panelName; document.title = s.panelName;
      toast('Settings saved.', 'success');
    } catch (e) { toast(e.message, 'error'); }
  });
}

/* ═══ PROFILE ═══ */
$('profile-trigger').addEventListener('click', openProfile);
function openProfile() {
  $('modal-root').innerHTML = `
  <div class="modal-overlay open" onclick="if(event.target===this)this.remove()">
    <div class="modal" style="width:460px;">
      <div class="modal-hdr">
        <div class="u-av" style="width:36px;height:36px;font-size:14px;" id="pm-av">${esc(user.username.slice(0, 2).toUpperCase())}</div>
        <div><div class="modal-title">Edit Profile</div><div class="modal-meta">Your account settings</div></div>
        <div class="modal-close" onclick="this.closest('.modal-overlay').remove()"><svg viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></div>
      </div>
      <div class="modal-body"><div style="padding:20px;display:flex;flex-direction:column;gap:14px;">
        <div class="ns-form">
          <div class="ns-field"><label>USERNAME</label><input id="pf-user" value="${esc(ME ? ME.username : user.username)}" oninput="$('pm-av').textContent=this.value.slice(0,2).toUpperCase()"></div>
          <div class="ns-field"><label>EMAIL</label><input id="pf-email" type="email" value="${esc(ME ? ME.email : '')}" placeholder="your@email.com"></div>
        </div>
        <div class="ns-field"><label>NEW PASSWORD</label><input type="password" id="pf-pass" placeholder="Leave blank to keep the current one"></div>
        <div style="display:flex;gap:8px;">
          <button class="btn btn-ghost" onclick="this.closest('.modal-overlay').remove()">Cancel</button>
          <a href="/auth/logout" class="btn btn-danger">Log Out</a>
          <button class="btn btn-primary" style="margin-left:auto;" onclick="saveProfile()">Save</button>
        </div>
      </div></div>
    </div>
  </div>`;
}
async function saveProfile() {
  const body = { username: $('pf-user').value.trim() };
  if ($('pf-email').value) body.email = $('pf-email').value;
  if ($('pf-pass').value)  body.password = $('pf-pass').value;
  try {
    const r = await api('PATCH', '/users/me', body);
    $('sb-name').textContent = r.username; $('sb-av').textContent = r.username.slice(0, 2).toUpperCase();
    document.querySelector('.modal-overlay')?.remove();
    toast('Profile updated!', 'success');
  } catch (e) { toast(e.message, 'error'); }
}

/* ═══ INIT ═══ */
nav('dashboard');
