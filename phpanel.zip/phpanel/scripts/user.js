#!/usr/bin/env node
/**
 * Manage panel users from the terminal.
 *
 *   npm run user -- add <username> [password] [--admin] [--email you@mail.com]
 *   npm run user -- list
 *   npm run user -- passwd <username> [password]
 *   npm run user -- admin <username>        make a user administrator
 *   npm run user -- demote <username>       back to a normal user
 *   npm run user -- limits <username> <ramGB> <cpu%>   set a user's RAM / CPU pool (100 = 1 core)
 *   npm run user -- delete <username>
 *
 * With Docker:  docker compose exec phpanel node scripts/user.js add <username> <password> --admin
 */
const readline = require('readline');
const users    = require('../src/handlers/users');
const servers  = require('../src/handlers/servers');
const settings = require('../src/handlers/settings');

const argv  = process.argv.slice(2);
const flags = { admin: argv.includes('--admin') };
const ei = argv.indexOf('--email');
if (ei !== -1) flags.email = argv[ei + 1];
const pos = argv.filter((a, i) => !a.startsWith('--') && argv[i - 1] !== '--email');
const [cmd, name, passArg] = pos;

const die = (m) => { console.error(`\n  ${m}\n`); process.exit(1); };

function ask(question, hidden = false) {
  return new Promise((resolve) => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout, terminal: true });
    if (hidden) {
      rl._writeToOutput = (s) => { if (s.includes(question)) process.stdout.write(question); else if (s.includes('\n')) process.stdout.write('\n'); };
    }
    rl.question(question, (a) => { rl.close(); resolve(a.trim()); });
  });
}

const makeAdmin = (id) => users.update(id, { role: 'admin', ram: null, cpu: null, disk: null });

async function main() {
  const s = settings.get();
  switch (cmd) {
    case 'add': {
      const username = name || (process.stdin.isTTY ? await ask('Username: ') : '');
      if (!username) die('Usage: npm run user -- add <username> [password] [--admin]');
      const password = passArg || (process.stdin.isTTY ? await ask('Password (min 6): ', true) : '');
      if (!password) die('A password is required.');
      let u = users.create({ username, email: flags.email, password });
      if (flags.admin) u = makeAdmin(u.id);
      console.log(`\n  Created ${flags.admin ? 'ADMIN' : 'user'} "${u.username}"` + (flags.admin ? '' : ` (${s.defaultRam} GB RAM, ${s.defaultCpu}% CPU)`) + '\n');
      break;
    }
    case 'list': {
      const list = users.list();
      if (!list.length) return console.log('\n  No users yet.\n');
      console.log('');
      for (const u of list) console.log(`  ${u.username.padEnd(22)} ${u.role.padEnd(6)} coins:${String(u.coins).padEnd(7)} ${u.role === 'admin' ? 'unlimited' : `${u.ram} GB / ${u.cpu}%`}`);
      console.log('');
      break;
    }
    case 'passwd': {
      const u = users.findByUsername(name || ''); if (!u) die(`No such user: ${name || '(missing)'}`);
      const password = passArg || (process.stdin.isTTY ? await ask('New password (min 6): ', true) : '');
      users.checkPassword(password);
      users.update(u.id, { password });
      console.log(`\n  Password changed for "${u.username}"\n`);
      break;
    }
    case 'admin':
    case 'demote': {
      const u = users.findByUsername(name || ''); if (!u) die(`No such user: ${name || '(missing)'}`);
      if (cmd === 'admin') makeAdmin(u.id);
      else users.update(u.id, { role: 'user', ram: s.defaultRam, cpu: s.defaultCpu, disk: s.defaultDisk });
      console.log(`\n  "${u.username}" is now ${cmd === 'admin' ? 'an administrator' : 'a normal user'}\n`);
      break;
    }
    case 'limits': {
      const u = users.findByUsername(name || ''); if (!u) die(`No such user: ${name || '(missing)'}`);
      const ram = Number(passArg), cpu = Number(pos[3]);
      if (!Number.isInteger(ram) || ram < 1 || !Number.isInteger(cpu) || cpu < 10) die('Usage: limits <username> <ramGB> <cpu%>   e.g. limits bob 4 100');
      users.update(u.id, { ram, cpu });
      console.log(`\n  "${u.username}" now has ${ram} GB RAM and ${cpu}% CPU\n`);
      break;
    }
    case 'delete': {
      const u = users.findByUsername(name || ''); if (!u) die(`No such user: ${name || '(missing)'}`);
      if (servers.list().some((x) => x.ownerId === u.id)) die(`"${u.username}" still owns servers. Delete those in the panel first.`);
      users.remove(u.id);
      console.log(`\n  Deleted "${u.username}"\n`);
      break;
    }
    default:
      console.log('\n  Usage:\n    add <username> [password] [--admin] [--email x]\n    list\n    passwd <username> [password]\n    admin <username>\n    demote <username>\n    limits <username> <ramGB> <cpu%>\n    delete <username>\n');
  }
}

main().catch((e) => die(e.message));
