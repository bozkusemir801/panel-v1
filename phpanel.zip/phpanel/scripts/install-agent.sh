#!/usr/bin/env bash
# PHBAI node agent installer.
#   curl -sSL https://YOUR_PANEL/install/agent.sh | sudo bash -s -- --panel https://YOUR_PANEL --key TOKEN --name node-1
# Installs Node.js and Docker if they are missing, downloads the agent from the panel,
# configures it and (when systemd is available) runs it as a service.
set -euo pipefail

PANEL=""; KEY=""; NAME="$(hostname)"
DIR="${PHBAI_INSTALL_DIR:-/opt/phbai-agent}"
DATA="${PHBAI_DATA_DIR:-/var/lib/phbai-agent}"

say()  { printf '\n\033[1;36m==>\033[0m %s\n' "$*"; }
die()  { printf '\n\033[1;31mError:\033[0m %s\n\n' "$*" >&2; exit 1; }

while [ $# -gt 0 ]; do
  case "$1" in
    --panel) PANEL="${2:-}"; shift 2 ;;
    --key)   KEY="${2:-}";   shift 2 ;;
    --name)  NAME="${2:-}";  shift 2 ;;
    --dir)   DIR="${2:-}";   shift 2 ;;
    --data-dir) DATA="${2:-}"; shift 2 ;;
    *) die "Unknown option: $1" ;;
  esac
done
[ -n "$PANEL" ] && [ -n "$KEY" ] || die "Usage: install-agent.sh --panel https://YOUR_PANEL --key TOKEN [--name node-1]"
PANEL="${PANEL%/}"
case "$PANEL" in http://*|https://*) ;; *) die "--panel must start with http:// or https://" ;; esac

SUDO=""
if [ "$(id -u)" -ne 0 ]; then
  if [ "${SKIP_DEPS:-0}" = "1" ] && [ "${SKIP_SERVICE:-0}" = "1" ]; then :; else
    die "Please run as root (put sudo before bash)."
  fi
fi

have() { command -v "$1" >/dev/null 2>&1; }
HAS_SYSTEMD=0; [ -d /run/systemd/system ] && have systemctl && HAS_SYSTEMD=1

install_node() {
  if have node && [ "$(node -p 'process.versions.node.split(".")[0]')" -ge 18 ]; then return; fi
  say "Installing Node.js (LTS)"
  if have apt-get; then
    apt-get update -y && apt-get install -y curl ca-certificates
    curl -fsSL https://deb.nodesource.com/setup_lts.x | bash -
    apt-get install -y nodejs
  elif have dnf; then
    curl -fsSL https://rpm.nodesource.com/setup_lts.x | bash -
    dnf install -y nodejs
  elif have yum; then
    curl -fsSL https://rpm.nodesource.com/setup_lts.x | bash -
    yum install -y nodejs
  else
    die "Could not install Node.js automatically. Install Node.js 18+ and run this again."
  fi
}

install_docker() {
  if have docker; then return; fi
  say "Installing Docker"
  curl -fsSL https://get.docker.com | sh
  [ "$HAS_SYSTEMD" = "1" ] && systemctl enable --now docker || true
}

if [ "${SKIP_DEPS:-0}" != "1" ]; then
  have curl || die "curl is required"
  install_node
  install_docker
fi
have node || die "Node.js is not installed"
have tar  || die "tar is required"

say "Downloading the agent from $PANEL"
mkdir -p "$DIR" "$DATA"
curl -fsSL "$PANEL/install/agent.tgz" | tar xz -C "$DIR" || die "Could not download the agent. Is the panel address correct and reachable from this machine?"

say "Installing dependencies"
cd "$DIR"
npm install --omit=dev --no-audit --no-fund --loglevel=error

say "Configuring"
npm run configure --silent -- --panel "$PANEL" --key "$KEY" --name "$NAME" --data-dir "$DATA"

if [ "${SKIP_SERVICE:-0}" = "1" ]; then
  say "Done (service step skipped). Start with:  cd $DIR && npm start"
  exit 0
fi

if [ "$HAS_SYSTEMD" = "1" ]; then
  say "Creating the phbai-agent service"
  cat > /etc/systemd/system/phbai-agent.service <<UNIT
[Unit]
Description=PHBAI node agent
After=network-online.target docker.service
Wants=network-online.target
Requires=docker.service

[Service]
WorkingDirectory=$DIR
ExecStart=$(command -v node) src/index.js
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
UNIT
  systemctl daemon-reload
  systemctl enable --now phbai-agent
  say "Agent is running. It should show as Online in the panel within a few seconds."
  echo "    Logs:  journalctl -u phbai-agent -f"
else
  say "systemd was not found, so no service was created."
  echo "    Start the agent with:   cd $DIR && npm start"
  echo "    Or in the background:   cd $DIR && nohup npm start > agent.log 2>&1 &"
fi
