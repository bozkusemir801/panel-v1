/** Loads the real page + real app.js in jsdom against a real panel process and clicks through it. */
const assert = require('assert');
const fs = require('fs'), os = require('os'), path = require('path'), http = require('http');
const { spawn } = require('child_process');
const { JSDOM } = require('jsdom');

const ROOT = path.join(__dirname, '..');
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'phbai-ui-'));
Object.assign(process.env, { DATA_DIR: path.join(tmp, 'storage'), CONFIG_DIR: path.join(tmp, 'config') });
const users = require(path.join(ROOT, 'src/handlers/users'));
const serversStore = require(path.join(ROOT, 'src/handlers/servers'));

const PORT = 5079, BASE = `http://localhost:${PORT}`;
let pass = 0; const ok = (m) => { pass++; console.log('  ok  ' + m); };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const until = async (fn, ms = 5000) => { const t0 = Date.now(); for (;;) { const v = await fn(); if (v) return v; if (Date.now() - t0 > ms) throw new Error('timed out: ' + fn); await sleep(40); } };

const JAR = Buffer.concat([Buffer.from([0x50, 0x4b, 3, 4]), Buffer.alloc(50, 1)]);
let mport;
const market = http.createServer((req, res) => {
  const u = new URL(req.url, 'http://x'); const json = (o) => { res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(o)); };
  if (u.pathname === '/v2/search') return json({ hits: [{ project_id: 'abc12345', title: 'Cool<b>Plugin</b>', author: 'dev', description: 'desc', downloads: 1500, icon_url: null }] });
  if (/\/version$/.test(u.pathname)) return json([{ version_type: 'release', files: [{ primary: true, filename: 'Cool.jar', url: `http://127.0.0.1:${mport}/f.jar` }] }]);
  if (u.pathname === '/f.jar') { res.writeHead(200); return res.end(JAR); }
  res.writeHead(404); res.end();
});

async function login(u, p) {
  const r = await fetch(BASE + '/auth/login', { method: 'POST', redirect: 'manual', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: `username=${u}&password=${p}` });
  return r.headers.get('set-cookie').split(';')[0];
}
const api = async (cookie, method, p, body) => { const r = await fetch(BASE + '/api' + p, { method, headers: { 'Content-Type': 'application/json', Cookie: cookie }, body: body ? JSON.stringify(body) : undefined }); return r.json().catch(() => ({})); };

/** Open the panel as a user, like a browser would. */
async function openApp(cookie) {
  let html = await (await fetch(BASE + '/', { headers: { Cookie: cookie } })).text();
  html = html.replace(/<script[^>]+src=[^>]*><\/script>/g, '').replace(/<link[^>]*>/g, '');       // no network for fonts / socket.io
  const emitted = [];
  const dom = new JSDOM(html, { url: BASE + '/', runScripts: 'dangerously', pretendToBeVisual: true, beforeParse(w) {
    w.fetch = (u, o = {}) => fetch(new URL(u, BASE), { ...o, headers: { ...(o.headers || {}), Cookie: cookie } });
    w.XMLHttpRequest = class {
      constructor() { this.upload = {}; this.headers = {}; }
      open(m, u) { this.m = m; this.u = u; }
      setRequestHeader(k, v) { this.headers[k] = v; }
      abort() { this.onabort && this.onabort(); }
      send(body) { (async () => {
        const buf = await new Promise((res, rej) => { const r = new w.FileReader(); r.onload = () => res(Buffer.from(r.result)); r.onerror = rej; r.readAsArrayBuffer(body); });
        const r = await fetch(new URL(this.u, BASE), { method: this.m, headers: { ...this.headers, Cookie: cookie }, body: buf });
        this.status = r.status; this.responseText = await r.text();
        if (this.upload.onprogress) this.upload.onprogress({ loaded: buf.length });
        this.onload && this.onload();
      })().catch(() => this.onerror && this.onerror()); }
    };
    w.io = () => ({ emit: (...a) => emitted.push(a), on() {}, off() {} });
    w.prompt = () => w.__prompt; w.confirm = () => true; w.alert = () => {};
    w.addEventListener('error', (e) => { throw e.error || new Error(e.message); });
  } });
  const w = dom.window;
  w.eval(fs.readFileSync(path.join(ROOT, 'src/public/js/app.js'), 'utf8'));
  w.emitted = emitted;
  return w;
}
const text = (w, sel) => (w.document.querySelector(sel) || {}).textContent || '';
const loaded = (w) => until(() => !text(w, '#page-content').includes('Loading…'));
async function go(w, page) { w.nav(page); await sleep(30); await loaded(w); const t = text(w, '#page-content'); assert.ok(!/Error:/.test(t), `page ${page} shows an error: ${t.slice(0, 160)}`); return t; }
const click = (w, el) => el.dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
const q = (w, sel) => w.document.querySelector(sel);
const qa = (w, sel) => [...w.document.querySelectorAll(sel)];

(async () => {
  await new Promise((r) => market.listen(0, '127.0.0.1', r)); mport = market.address().port;
  const admin = users.create({ username: 'boss', email: 'b@x.io', password: 'secret1' }); users.update(admin.id, { role: 'admin', ram: null, cpu: null, disk: null });
  users.create({ username: 'bob', email: 'bob@x.io', password: 'secret2' });
  const panel = spawn('node', ['src/index.js'], { cwd: ROOT, env: { ...process.env, PORT, MODRINTH_API_URL: `http://127.0.0.1:${mport}/v2`, SESSION_SECRET: 'ui' } });
  let plog = ''; panel.stdout.on('data', (d) => plog += d); panel.stderr.on('data', (d) => plog += d);
  for (let i = 0; i < 50 && !plog.includes('running'); i++) await sleep(150);
  const windows = [];
  try {
    const adminC = await login('boss', 'secret1'), bobC = await login('bob', 'secret2');

    /* seed: a hostile server name, a normal server with files */
    const evil = await api(bobC, 'POST', '/servers', { name: '<img src=x onerror=__xss=1>', type: 'paper', version: '1.21.4', port: 25601, ram: 1, cpu: 10 });
    const srv = await api(bobC, 'POST', '/servers', { name: 'Survival', type: 'paper', version: '1.21.4', port: 25602, ram: 2, cpu: 50 });
    const post = (p, b) => api(bobC, 'POST', `/servers/${srv.id}/files/${p}`, b);
    await post('write', { path: 'server.properties', content: 'motd=Hello\nmax-players=20\n' }); await post('write', { path: 'plugins/readme.txt', content: 'inside folder' });
    await post('write', { path: '<b>weird.txt', content: 'x' }); await post('mkdir', { path: 'world' });

    /* ═══ a normal user ═══ */
    const w = await openApp(bobC); windows.push(w); await loaded(w);
    const nav = qa(w, '.ni').map((n) => n.dataset.page);
    assert.deepStrictEqual(nav.sort(), ['afk', 'dashboard', 'servers', 'shop']); ok('sidebar of a normal user: Dashboard, Servers, Shop, AFK only (no Nodes, Settings, Users, Players)');
    assert.strictEqual(text(w, '.sb-name'), 'PHBAI Panel'); assert.ok(!/1234/.test(w.document.body.textContent));
    let t = await go(w, 'dashboard'); assert.ok(t.includes('Survival')); assert.ok(t.includes('3 GB') && t.includes('/ 4 GB') && t.includes('60%') && t.includes('/ 100%'), t.slice(0, 300)); ok('dashboard shows servers and the RAM/CPU pool (3 of 4 GB, 60 of 100%)');
    assert.strictEqual(w.__xss, undefined); assert.strictEqual(qa(w, '#page-content img').length, 0); assert.ok(t.includes('<img src=x')); ok('a server named with HTML is shown as plain text (it used to execute: stored XSS)');
    w.nav('settings'); await sleep(50); assert.strictEqual(text(w, '#pg-title'), 'Dashboard'); ok('typing the Settings page into the app does nothing for a normal user');

    t = await go(w, 'shop'); assert.ok(t.includes('3 / 4 GB') && t.includes('60 / 100%')); assert.ok(!t.includes('—')); ok('shop shows real coins/RAM/CPU instead of "—"');
    t = await go(w, 'afk'); assert.ok(t.includes('Claim 50 coins') && t.includes('24 hours') && !t.includes('Publisher ID')); ok('AFK: "Claim 50 coins", every 24 hours, no admin ad form for a normal user');
    click(w, q(w, '#afk-claim button')); await until(() => text(w, '#afk-claim').includes('Next reward in')); assert.strictEqual(text(w, '#sb-coins'), '50'); ok('claiming gives 50 coins and starts the 24h countdown');

    /* new server modal */
    await go(w, 'servers'); await w.openNewServer(); await until(() => q(w, '#ns-ver option[value="26.3"]'));
    assert.deepStrictEqual(qa(w, '#ns-type option').map((o) => o.value), ['paper', 'spigot', 'purpur', 'fabric', 'forge', 'vanilla']); assert.ok(text(w, '.modal-meta').includes('1 GB') && text(w, '.modal-meta').includes('40%'));
    assert.strictEqual(q(w, '#ns-disk').disabled, true); assert.ok(q(w, '#ns-disk').value.includes('10')); ok('new-server form: 6 types, version list loads, quota hint (1 GB / 40% left), disk is fixed at 10 GB');
    q(w, '#ns-type').value = 'vanilla'; q(w, '#ns-type').dispatchEvent(new w.Event('change')); await until(() => q(w, '#ns-ver option[value="1.8.8"]')); ok('changing the type reloads the version list');
    q(w, '#ns-name').value = 'Too big'; q(w, '#ns-port').value = '25603'; q(w, '#ns-ram').value = '1'; q(w, '#ns-cpu').value = '50'; w.submitNewServer(); await sleep(250);
    assert.ok(qa(w, '.toast').some((x) => /Not enough CPU/.test(x.textContent))); ok('asking for more CPU than left shows the error in a toast');
    w.closeModal('ns-modal');

    /* server modal: tabs */
    await w.openServerModal(srv.id); await until(() => q(w, '#srv-modal'));
    assert.deepStrictEqual(qa(w, '.modal-tab').map((x) => x.textContent), ['Console', 'Files', 'Plugins', 'Players', 'Startup', 'Version', 'Backups']); ok('server window has Console, Files, Plugins, Players, Startup, Version, Backups');
    w.switchMTab('files'); await until(() => q(w, '#tab-files .file-table'));
    let rows = qa(w, '#tab-files .fm-row').map((r) => text(w, `#tab-files .fm-row:nth-child(${[...r.parentNode.children].indexOf(r) + 1}) .fn`).trim());
    assert.deepStrictEqual(rows.sort(), ['<b>weird.txt', 'plugins', 'server.properties', 'world']); assert.strictEqual(qa(w, '#tab-files b').length, 0); ok('file manager lists the files (folders first), HTML in file names stays text');
    click(w, q(w, '#tab-files .fm-row[data-path="plugins"]')); await until(() => q(w, '#tab-files .fm-row[data-path="plugins/readme.txt"]'));
    assert.ok(text(w, '.fm-crumbs').includes('plugins') && q(w, '#tab-files .fm-row[data-path=""]')); ok('clicking a folder opens it (breadcrumb + ".." row appear)');
    click(w, q(w, '#tab-files .fm-row[data-path="plugins/readme.txt"]')); await until(() => q(w, '#editor')); assert.strictEqual(q(w, '#editor').value, 'inside folder'); ok('clicking a file opens the editor with its content');
    q(w, '#editor').value = 'edited!'; q(w, '#editor').dispatchEvent(new w.Event('input')); click(w, q(w, '[data-act="save"]')); await until(() => qa(w, '.toast').some((x) => x.textContent === 'Saved.'));
    assert.strictEqual(fs.readFileSync(path.join(tmp, 'storage/servers', srv.id, 'plugins/readme.txt'), 'utf8'), 'edited!'); ok('Save writes the file to disk');
    click(w, q(w, '[data-act="closeedit"]')); await until(() => q(w, '#tab-files .file-table')); w.__prompt = 'notes.yml'; click(w, q(w, '[data-act="newfile"]')); await until(() => q(w, '#editor')); assert.ok(fs.existsSync(path.join(tmp, 'storage/servers', srv.id, 'plugins/notes.yml'))); ok('"New file" creates it in the current folder and opens the editor');
    click(w, q(w, '[data-act="closeedit"]')); await until(() => q(w, '#tab-files .file-table')); w.__prompt = 'sub'; click(w, q(w, '[data-act="newdir"]')); await until(() => q(w, '#tab-files .fm-row[data-path="plugins/sub"]')); ok('"New folder" works');
    click(w, q(w, '[data-act="del"][data-path="plugins/notes.yml"]')); await until(() => !q(w, '#tab-files .fm-row[data-path="plugins/notes.yml"]')); assert.ok(!fs.existsSync(path.join(tmp, 'storage/servers', srv.id, 'plugins/notes.yml'))); ok('Delete removes the file');


    /* upload from the computer (we are inside plugins/ in the Files tab) */
    const sroot = path.join(tmp, 'storage/servers', srv.id), mkFile = (name, text) => new w.File([text], name);
    assert.ok(q(w, '[data-act="upload-files"]') && q(w, '[data-act="upload-folder"]') && q(w, '#up-folder').hasAttribute('webkitdirectory') && /Drag files or a whole folder/.test(text(w, '#tab-files'))); ok('Files tab has "Upload files" and "Upload folder" buttons and a drag & drop hint');
    await w.uploadFiles([{ file: mkFile('a.txt', 'AAA'), rel: 'a.txt' }, { file: mkFile('b.bin', 'BBB'), rel: 'mods/x/b.bin' }], ['empty/dir']);
    assert.strictEqual(fs.readFileSync(path.join(sroot, 'plugins/a.txt'), 'utf8'), 'AAA'); assert.strictEqual(fs.readFileSync(path.join(sroot, 'plugins/mods/x/b.bin'), 'utf8'), 'BBB'); assert.ok(fs.statSync(path.join(sroot, 'plugins/empty/dir')).isDirectory());
    assert.ok(q(w, '#tab-files .fm-row[data-path="plugins/a.txt"]') && q(w, '#tab-files .fm-row[data-path="plugins/mods"]')); assert.strictEqual(text(w, '#up-box'), ''); assert.ok(qa(w, '.toast').some((x) => x.textContent === 'Uploaded 2 files.'));
    ok('uploadFiles puts files (with sub-folders and an empty folder) into the folder you are looking at, then refreshes the list');
    const inp = q(w, '#up-folder'); const f1 = mkFile('level.dat', 'LV'); Object.defineProperty(f1, 'webkitRelativePath', { value: 'myworld/level.dat' }); const f2 = mkFile('r.mca', 'RR'); Object.defineProperty(f2, 'webkitRelativePath', { value: 'myworld/region/r.mca' });
    Object.defineProperty(inp, 'files', { value: [f1, f2], configurable: true }); inp.dispatchEvent(new w.Event('change'));
    await until(() => fs.existsSync(path.join(sroot, 'plugins/myworld/region/r.mca'))); ok('"Upload folder" (browser folder picker) keeps the folder structure: myworld/level.dat, myworld/region/r.mca');
    const fileEntry = (name, t) => ({ isFile: true, isDirectory: false, name, file: (ok2) => ok2(mkFile(name, t)) });
    const dirEntry = (name, kids) => { let done = false; return { isFile: false, isDirectory: true, name, createReader: () => ({ readEntries: (ok2) => { if (done) return ok2([]); done = true; ok2(kids); } }) }; };
    const dt = { items: [{ webkitGetAsEntry: () => dirEntry('pack', [fileEntry('p.txt', '1'), dirEntry('sub', [fileEntry('q.txt', '2')]), dirEntry('hollow', [])]) }, { webkitGetAsEntry: () => fileEntry('top.txt', '3') }] };
    const got = await w.collectDropped(dt); assert.deepStrictEqual(Array.from(got.items, (i) => i.rel).sort(), ['pack/p.txt', 'pack/sub/q.txt', 'top.txt']); assert.deepStrictEqual(Array.from(got.dirs), ['pack/hollow']);
    await w.uploadFiles(got.items, got.dirs); assert.strictEqual(fs.readFileSync(path.join(sroot, 'plugins/pack/sub/q.txt'), 'utf8'), '2'); assert.ok(fs.statSync(path.join(sroot, 'plugins/pack/hollow')).isDirectory());
    ok('drag & drop of a folder tree is read recursively (nested folders and an empty folder included) and uploaded');
    await w.uploadFiles([{ file: mkFile('x', '1'), rel: '../evil' }]); assert.ok(qa(w, '.toast').some((x) => /Invalid file or folder name/.test(x.textContent)) && !fs.existsSync(path.join(sroot, 'evil'))); ok('a refused upload shows the server\'s reason in a toast');

    w.switchMTab('plugins'); await until(() => q(w, '#pl-results .pl-card')); assert.ok(text(w, '#pl-results').includes('Cool<b>Plugin</b>') && qa(w, '#pl-results b').length === 0); assert.deepStrictEqual(qa(w, '#pl-source option').map((o) => o.value), ['modrinth', 'spiget']);
    click(w, q(w, '[data-act="install"]')); await until(() => qa(w, '#pl-installed .pl-inst').length === 1); assert.ok(fs.existsSync(path.join(tmp, 'storage/servers', srv.id, 'plugins/Cool.jar'))); ok('Plugins tab: search results appear (Modrinth + Spigot sources), Install puts the jar in plugins/ and lists it');
    click(w, q(w, '[data-act="rmplugin"]')); await until(() => !qa(w, '#pl-installed .pl-inst').length); ok('installed plugin can be removed');

    w.switchMTab('players'); await until(() => /offline/.test(text(w, '#tab-players'))); ok('Players tab (moved here from the sidebar) tells you the server is offline');
    w.switchMTab('startup'); await until(() => q(w, '#st-motd')); q(w, '#st-motd').value = 'Welcome!'; q(w, '#st-max').value = '35'; w.saveStartup(); await until(async () => (await api(bobC, 'GET', '/servers')).find((s) => s.id === srv.id).startup.maxPlayers === 35);
    assert.strictEqual((await api(bobC, 'GET', '/servers')).find((s) => s.id === srv.id).startup.motd, 'Welcome!'); ok('Startup tab saves MOTD / max players');
    w.switchMTab('version'); await until(() => q(w, '#vs-ver option[value="26.3"]')); q(w, '#vs-type').value = 'purpur'; q(w, '#vs-type').dispatchEvent(new w.Event('change')); await until(() => q(w, '#vs-ver option[value="1.21.4"]')); q(w, '#vs-ver').value = '1.21.4'; w.saveVersion();
    await until(async () => (await api(bobC, 'GET', '/servers')).find((s) => s.id === srv.id).type === 'purpur'); assert.ok(text(w, '#srv-meta').includes('Purpur')); ok('Version tab switches Paper -> Purpur and updates the header');
    w.switchMTab('backup'); await until(() => /No backups yet/.test(text(w, '#tab-backup'))); w.closeModal('srv-modal');


    /* a start in progress, then a failed start with its reason */
    serversStore.update(srv.id, { status: 'starting', lastError: null });
    t = await go(w, 'servers'); assert.ok(qa(w, '.sc .s-wait').length === 1 && /Starting/.test(text(w, '.sc .s-wait'))); ok('a server that is starting shows a yellow "Starting…" badge');
    serversStore.update(srv.id, { status: 'offline', lastError: 'Disk limit reached (10.2 of 10 GB used). Delete some files first.' });
    await until(() => qa(w, '.toast').some((x) => /could not start: Disk limit reached/.test(x.textContent)), 9000); ok('when the start fails, a message tells you WHY (it used to disappear)');
    await w.openServerModal(srv.id); await until(() => q(w, '#srv-modal')); assert.ok(/The last start failed/.test(text(w, '#tab-console .warn')) && /Disk limit reached/.test(text(w, '#tab-console .warn'))); w.closeModal('srv-modal'); ok('the server window keeps showing the reason of the last failed start');

    /* ═══ the admin ═══ */
    const a = await openApp(adminC); windows.push(a); await loaded(a);
    assert.deepStrictEqual(qa(a, '.ni').map((n) => n.dataset.page).sort(), ['adminservers', 'afk', 'dashboard', 'nodes', 'servers', 'settings', 'shop', 'users']); ok('admin sidebar: everything, including All Servers, Nodes, Users, Settings');
    t = await go(a, 'servers'); assert.ok(!t.includes('Survival') && t.includes('No servers yet')); ok('admin\'s own Servers page does not list other people\'s servers');
    t = await go(a, 'adminservers'); assert.ok(t.includes('Survival') && t.includes('bob') && t.includes('Purpur')); assert.strictEqual(qa(a, '#page-content img').length, 0); ok('"All Servers" (moderation) lists them with the owner');
    t = await go(a, 'settings'); assert.ok(t.includes('RAM POOL') && t.includes('DISK PER SERVER') && t.includes('COINS PER CLAIM'));
    q(a, '#set-name').value = 'My Cloud'; q(a, '#set-ram').value = '6'; q(a, '#set-afk').value = '80'; click(a, q(a, '#set-save')); await until(async () => (await api(adminC, 'GET', '/settings')).panelName === 'My Cloud');
    const s2 = await api(adminC, 'GET', '/settings'); assert.deepStrictEqual([s2.defaultRam, s2.afkReward], [6, 80]); assert.strictEqual(text(a, '.sb-name'), 'My Cloud'); ok('Settings page saves and the sidebar name updates at once');
    t = await go(a, 'afk'); assert.ok(t.includes('Publisher ID') && t.includes('Ad slot ID') && t.includes('adsense.google.com') && t.includes('Claim 80 coins')); q(a, '#ads-client').value = 'ca-pub-1234567890123456'; q(a, '#ads-slot').value = '555'; a.saveAds();
    await until(async () => (await api(adminC, 'GET', '/settings')).adSlotId === '555'); ok('AFK page for admins explains where to find the AdSense IDs and saves them');
    await go(a, 'users'); assert.ok(text(a, '#page-content').includes('scripts/user.js add'));
    t = await go(a, 'nodes'); assert.ok(t.includes('Add a node')); q(a, '#node-name').value = 'Germany-1'; await a.addNode(); await until(() => q(a, '#cmd-auto'));
    const cmd = text(a, '#cmd-auto'); assert.ok(cmd.startsWith(`curl -sSL ${BASE}/install/agent.sh | sudo bash -s -- --panel ${BASE} --key phb_`) && cmd.includes("--name 'Germany-1'"), cmd); ok('adding a node shows the ready-to-paste curl command with the key');

    console.log(`\n  ${pass} UI checks passed\n`);
  } catch (e) { console.error('\n  FAILED:', e.message, '\n', (e.stack || '').split('\n').slice(1, 4).join('\n'), '\n--- panel log ---\n', plog.slice(-1200)); process.exitCode = 1; }
  finally { windows.forEach((w) => { try { w.close(); } catch {} }); panel.kill(); market.close(); fs.rmSync(tmp, { recursive: true, force: true }); setTimeout(() => process.exit(), 200); }
})();
