/**
 * End-to-end: real panel process + fake Docker daemon (unix socket) + fake Modrinth/Spiget +
 * real node agent (fake Docker) + the real agent installer script.
 */
const assert = require('assert');
const fs = require('fs'), os = require('os'), path = require('path'), http = require('http');
const zlib = require('zlib');
const { PassThrough } = require('stream');
const { spawn, execFileSync } = require('child_process');

const ROOT = path.join(__dirname, '..');
const { io } = require(path.join(ROOT, 'agent/node_modules/socket.io-client'));
const { createAgent } = require(path.join(ROOT, 'agent/src/agent'));

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'phbai-e2e-'));
const DATA = path.join(tmp, 'storage'), CONF = path.join(tmp, 'config'), SOCK = path.join(tmp, 'docker.sock');
Object.assign(process.env, { DATA_DIR: DATA, CONFIG_DIR: CONF, MAX_UPLOAD_MB: '1' });
const users = require(path.join(ROOT, 'src/handlers/users'));

const PORT = 5077, BASE = `http://localhost:${PORT}`, GB = 1024 ** 3;
let pass = 0;
const ok = (m) => { pass++; console.log('  ok  ' + m); };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const until = async (fn, ms = 6000) => { const t0 = Date.now(); for (;;) { const v = await fn(); if (v) return v; if (Date.now() - t0 > ms) throw new Error('timed out waiting'); await sleep(100); } };

/* ───────── fake Docker daemon (what the PANEL talks to for local servers) ───────── */
const containers = new Map(); const dlog = [];
const frame = (txt) => { const b = Buffer.from(txt); const h = Buffer.alloc(8); h[0] = 1; h.writeUInt32BE(b.length, 4); return Buffer.concat([h, b]); };
const dockerd = http.createServer((req, res) => {
  const u = new URL(req.url, 'http://x'); const p = u.pathname.replace(/^\/v[\d.]+/, '');
  let body = ''; req.on('data', (d) => body += d);
  req.on('end', () => {
    const send = (c, o) => { res.writeHead(c, { 'Content-Type': 'application/json' }); res.end(o === undefined ? '' : JSON.stringify(o)); };
    dlog.push(`${req.method} ${p}`);
    let m;
    if (req.method === 'GET' && /^\/images\/.+\/json$/.test(p)) return send(200, {});
    if (req.method === 'POST' && p === '/containers/create') {
      const name = u.searchParams.get('name');
      if (containers.has(name)) return send(409, { message: `Conflict. The container name "/${name}" is already in use by container "x".` });
      containers.set(name, { cfg: JSON.parse(body), running: false, id: 'id_' + name });
      return send(201, { Id: 'id_' + name, Warnings: [] });
    }
    const find = (k) => containers.get(k) || [...containers.values()].find((c) => c.id === k);
    if ((m = p.match(/^\/containers\/([^/]+)\/(start|stop|restart)$/)) && req.method === 'POST') {
      const c = find(m[1]); if (!c) return send(404, { message: 'No such container' });
      c.running = m[2] !== 'stop'; return send(204);
    }
    if (req.method === 'DELETE' && (m = p.match(/^\/containers\/([^/]+)$/))) {
      if (!containers.has(m[1])) return send(404, { message: 'No such container' });
      containers.delete(m[1]); return send(204);
    }
    if (req.method === 'GET' && (m = p.match(/^\/containers\/([^/]+)\/logs$/))) {
      if (!find(m[1])) return send(404, { message: 'No such container' });
      res.writeHead(200, { 'Content-Type': 'application/vnd.docker.raw-stream' }); return res.end(frame('[boot] local line\n'));
    }
    send(404, { message: 'fake daemon: not implemented ' + p });
  });
});

/* ───────── fake Modrinth + Spiget ───────── */
const JAR = Buffer.concat([Buffer.from([0x50, 0x4b, 3, 4]), Buffer.alloc(200, 1)]);
let mport, lastSearch = '';
const market = http.createServer((req, res) => {
  const u = new URL(req.url, 'http://x'); const p = u.pathname;
  const json = (o) => { res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(o)); };
  const self = `http://127.0.0.1:${mport}`;
  if (p === '/v2/search') { lastSearch = decodeURIComponent(u.search); return json({ hits: [{ project_id: 'abc12345', title: 'CoolPlugin', author: 'dev', description: 'A cool plugin', downloads: 1234, icon_url: null }] }); }
  let m;
  if ((m = p.match(/^\/v2\/project\/([^/]+)\/version$/))) {
    lastSearch = decodeURIComponent(u.search);
    const files = { abc12345: [{ primary: true, filename: 'CoolPlugin-1.0.jar', url: `${self}/files/CoolPlugin-1.0.jar` }],
                    htmlhtml1: [{ primary: true, filename: 'Blocked.jar', url: `${self}/files/blocked.jar` }],
                    evil00001: [{ primary: true, filename: 'Evil.jar', url: 'https://evil.example.com/x.jar' }] }[m[1]];
    return json(files ? [{ version_type: 'release', files }] : []);
  }
  if (p === '/files/CoolPlugin-1.0.jar') { res.writeHead(200); return res.end(JAR); }
  if (p === '/files/blocked.jar') { res.writeHead(200); return res.end('<html>cloudflare says no</html>'); }
  if (p === '/spiget/search/resources/free') return json([
    { id: 1, name: 'FreePlugin', tag: 'free', downloads: 5, external: false, premium: false, file: { type: '.jar' } },
    { id: 2, name: 'PaidPlugin', tag: 'paid', downloads: 9, external: false, premium: true, file: { type: '.jar' } }]);
  if (p === '/spiget/resources/1') return json({ id: 1, name: 'FreePlugin', external: false, premium: false, file: { type: '.jar' } });
  if (p === '/spiget/resources/1/download') { res.writeHead(302, { Location: `${self}/files/CoolPlugin-1.0.jar` }); return res.end(); }
  res.writeHead(404); res.end('nope');
});

/* ───────── fake Docker for the AGENT (remote node) ───────── */
const calls = [];
const agentDocker = {
  getImage: () => ({ inspect: async () => ({}) }), pull: (i, cb) => cb(null, {}),
  modem: { followProgress: (s, cb) => cb(), demuxStream: (stream, out) => stream.on('data', (d) => out.write(d)) },
  createContainer: async (o) => { calls.push(['create', o]); return { id: 'cid123', start: async () => calls.push(['start']) }; },
  version: async () => ({ Version: '27.0.0-fake' }), followStream: null,
  getContainer: (name) => ({
    remove: async () => calls.push(['remove', name]), stop: async () => calls.push(['stop', name]), restart: async () => calls.push(['restart', name]),
    stats: async () => ({ cpu_stats: { cpu_usage: { total_usage: 200 }, system_cpu_usage: 1000, online_cpus: 2 }, precpu_stats: { cpu_usage: { total_usage: 100 }, system_cpu_usage: 500 }, memory_stats: { usage: 512 * 1024 * 1024 } }),
    exec: async (o) => { calls.push(['exec', o.Cmd]); const txt = o.Cmd[1] === 'list' ? 'There are 2 of a max of 20 players online: Steve, Alex\n' : 'ok\n';
      return { start: async () => { const pt = new PassThrough(); setImmediate(() => { pt.write(txt); pt.end(); }); return pt; } }; },
    logs: async (o) => { if (o.follow) { agentDocker.followStream = new PassThrough(); return agentDocker.followStream; } return frame('[boot] line one\n[boot] line two\n'); },
  }),
};

/* ───────── http helpers ───────── */
async function login(username, password) {
  const r = await fetch(BASE + '/auth/login', { method: 'POST', redirect: 'manual', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: `username=${encodeURIComponent(username)}&password=${encodeURIComponent(password)}` });
  assert.strictEqual(r.status, 302, 'login failed for ' + username);
  return r.headers.get('set-cookie').split(';')[0];
}
const api = async (cookie, method, p, body) => {
  const r = await fetch(BASE + '/api' + p, { method, headers: { 'Content-Type': 'application/json', ...(cookie ? { Cookie: cookie } : {}) }, body: body ? JSON.stringify(body) : undefined });
  const text = await r.text(); let data; try { data = JSON.parse(text); } catch { data = text; }
  return { status: r.status, data };
};
const page = async (cookie, p = '/') => (await fetch(BASE + p, { headers: cookie ? { Cookie: cookie } : {}, redirect: 'manual' })).text();
const sock = (cookie) => { const s = io(BASE, { extraHeaders: cookie ? { cookie } : {}, reconnection: false, forceNew: true, transports: ['polling'] }); s.on('connect_error', (e) => { s.lastError = e.message; }); return s; };
const once = (s, ev, ms = 4000) => new Promise((res, rej) => { const t = setTimeout(() => rej(new Error('timeout waiting ' + ev + (s.lastError ? ' (connect_error: ' + s.lastError + ')' : ''))), ms); s.once(ev, (...a) => { clearTimeout(t); res(a.length > 1 ? a : a[0]); }); });
const mk = (c, o) => api(c, 'POST', '/servers', { name: 'S', type: 'paper', version: '1.21.4', port: 25600, ram: 1, cpu: 10, ...o });

const startWait = async (c, id) => {          // start now runs in the background: wait for the outcome
  const http = await api(c, 'POST', `/servers/${id}/start`);
  if (http.status !== 200) return { http };
  const srv = await until(async () => { const x = (await api(c, 'GET', '/servers')).data.find((y) => y.id === id); return x && x.status !== 'starting' ? x : null; }, 15000);
  return { http, srv };
};
const sparse = (file, size) => { fs.mkdirSync(path.dirname(file), { recursive: true }); fs.writeFileSync(file, ''); fs.truncateSync(file, size); };   // instant, takes no real disk
const section = (t) => console.log('\n  ' + t);

(async () => {
  dockerd.listen(SOCK);
  await new Promise((r) => market.listen(0, '127.0.0.1', r)); mport = market.address().port;

  /* seed accounts, then start the panel */
  const admin = users.create({ username: 'boss', email: 'b@x.io', password: 'secret1' });
  users.update(admin.id, { role: 'admin', ram: null, cpu: null, disk: null });
  users.create({ username: 'bob', email: 'bob@x.io', password: 'secret2' });

  const panel = spawn('node', ['src/index.js'], { cwd: ROOT, env: { ...process.env, PORT, DOCKER_SOCKET: SOCK, HOST_DATA_DIR: '/srv/host-storage',
    MODRINTH_API_URL: `http://127.0.0.1:${mport}/v2`, SPIGET_API_URL: `http://127.0.0.1:${mport}/spiget`, SESSION_SECRET: 'e2e-secret' } });
  let plog = ''; panel.stdout.on('data', (d) => plog += d); panel.stderr.on('data', (d) => plog += d);
  for (let i = 0; i < 50 && !plog.includes('running'); i++) await sleep(150);
  assert.ok(plog.includes('running'), 'panel did not start:\n' + plog);

  let agent, installed;
  try {
    /* ═════ login page, branding, API auth ═════ */
    section('Login page, branding and API auth');
    const loginHtml = await page(null, '/auth/login');
    assert.ok(!loginHtml.includes('1234') && !/Default:/i.test(loginHtml)); assert.ok(loginHtml.includes('PHBAI Panel') && !loginHtml.includes('PHPanel'));
    ok('login page: "Default: admin / 1234" is gone and the panel is called PHBAI Panel');
    const noAuth = await fetch(BASE + '/api/me'); assert.strictEqual(noAuth.status, 401); ok('API without a session answers 401 JSON (it used to redirect)');

    const adminC = await login('boss', 'secret1');
    const bobC   = await login('bob', 'secret2');

    /* ═════ admin-only pages ═════ */
    section('Normal users cannot reach admin pages');
    const bobHtml = await page(bobC), adminHtml = await page(adminC);
    for (const p of ['nodes', 'settings', 'adminservers', 'users']) { assert.ok(!bobHtml.includes(`data-page="${p}"`), 'bob sees ' + p); assert.ok(adminHtml.includes(`data-page="${p}"`), 'admin lacks ' + p); }
    assert.ok(!adminHtml.includes('data-page="players"')); ok('sidebar: Nodes/Settings/Users/All Servers only for admins, Players page is gone');
    for (const [m, p, b] of [['GET', '/settings'], ['POST', '/settings', {}], ['POST', '/nodes', { name: 'xx' }], ['GET', '/servers/all'], ['GET', '/users']]) assert.strictEqual((await api(bobC, m, p, b)).status, 403, p);
    ok('API: settings / node creation / all-servers / user list return 403 for a normal user');

    /* ═════ privilege escalation fix ═════ */
    section('Profile endpoint');
    await api(bobC, 'PATCH', '/users/me', { role: 'admin', coins: 99999, ram: 999, cpu: 9999 });
    let me = (await api(bobC, 'GET', '/me')).data;
    assert.deepStrictEqual([me.role, me.coins, me.ram, me.cpu], ['user', 0, 4, 100]); ok('PATCH /users/me can no longer set role / coins / ram (was a full privilege escalation)');
    assert.strictEqual((await api(bobC, 'PATCH', '/users/me', { username: '<img src=x onerror=alert(1)>' })).status, 400); ok('usernames are restricted to safe characters');

    /* ═════ quotas ═════ */
    section('Resource limits');
    const s1 = await mk(bobC, { name: 'A', ram: 2, cpu: 50, port: 25601 }); assert.strictEqual(s1.status, 200);
    assert.strictEqual(s1.data.disk, 10); ok('first server (2 GB, 50%) created, disk is 10 GB');
    const s2 = await mk(bobC, { name: 'B', ram: 1, cpu: 50, port: 25602, disk: 500, type: 'spigot' }); assert.strictEqual(s2.status, 200);
    assert.strictEqual(s2.data.disk, 10); assert.strictEqual(s2.data.type, 'spigot'); ok('a user cannot choose the disk size: always 10 GB (500 ignored); spigot works');
    const noRam = await mk(bobC, { ram: 2, cpu: 10, port: 25603 }); assert.strictEqual(noRam.status, 400); assert.ok(/Not enough RAM.*1 GB left/.test(noRam.data.error), noRam.data.error);
    const noCpu = await mk(bobC, { ram: 1, cpu: 10, port: 25603 }); assert.strictEqual(noCpu.status, 400); assert.ok(/Not enough CPU/.test(noCpu.data.error), noCpu.data.error);
    ok('3rd server refused when RAM is used up ("1 GB left") and when CPU is used up (this was the bug: they opened anyway)');
    for (const bad of [{ ram: 'abc' }, { ram: -1 }, { ram: 0 }, { ram: 1.5 }, { cpu: 'x' }, { cpu: 5 }, { port: 80 }, { port: 'x' }, { name: '' }, { name: 'x'.repeat(33) }, { type: 'evil' }, { version: '1.21.4;rm' }])
      assert.strictEqual((await mk(bobC, { port: 25610, ...bad })).status, 400, JSON.stringify(bad));
    ok('garbage input (NaN, negatives, bad type/version/port/name) is rejected (NaN used to slip past the RAM check)');
    assert.strictEqual((await mk(bobC, { port: 25601 })).status, 409); ok('a port that another server already uses returns 409');
    assert.strictEqual((await mk(adminC, { port: PORT })).status, 409); ok('the panel\'s own port cannot be given to a server');

    for (const type of ['paper', 'spigot', 'purpur', 'fabric', 'forge', 'vanilla']) {
      const r = await mk(adminC, { type, port: 26000 + Object.keys({ paper: 0, spigot: 0, purpur: 0, fabric: 0, forge: 0, vanilla: 0 }).indexOf(type), version: '1.21.4' }); assert.strictEqual(r.status, 200, type);
    }
    ok('admin can create paper, spigot, purpur, fabric, forge and vanilla servers (no limits)');
    const ver = (await api(bobC, 'GET', '/versions/paper')).data; assert.ok(ver.versions.includes('26.3') && ver.versions.includes('1.21.4') && ver.versions[0] === '26.3'); assert.strictEqual((await api(bobC, 'GET', '/versions/evil')).status, 404);
    const vanilla = (await api(bobC, 'GET', '/versions/vanilla')).data; assert.ok(vanilla.versions.includes('1.8.8')); const purp = (await api(bobC, 'GET', '/versions/purpur')).data; assert.ok(!purp.versions.includes('1.8.8'));
    ok('version lists work per type (newest first, 26.x included, old versions only where the type supports them)');

    /* ═════ admin cannot see everyone's servers ═════ */
    section('Server privacy');
    const mine = (await api(adminC, 'GET', '/servers')).data; assert.ok(mine.length === 6 && mine.every((s) => s.name === 'S')); assert.ok(!mine.some((s) => s.name === 'A'));
    ok('the admin\'s server list shows only the admin\'s own servers');
    const all = (await api(adminC, 'GET', '/servers/all')).data; assert.ok(all.some((s) => s.name === 'A' && s.ownerName === 'bob')); assert.ok(all.every((s) => !('startup' in s) && !('containerId' in s)));
    ok('moderation list "All Servers" (admin only) shows owner + status but no internals');
    assert.strictEqual((await api(adminC, 'GET', `/servers/${s1.data.id}/files`)).status, 403);
    assert.strictEqual((await api(adminC, 'POST', `/servers/${s1.data.id}/start`)).status, 403);
    assert.strictEqual((await api(adminC, 'POST', `/servers/${s1.data.id}/command`, { cmd: 'list' })).status, 403);
    assert.strictEqual((await api(adminC, 'GET', `/servers/${s1.data.id}/plugins`)).status, 403);
    ok('admin gets 403 on another user\'s files, start, console command and plugins');
    assert.strictEqual((await api(bobC, 'POST', `/servers/${all.find((s) => s.name === 'S').id}/stop`)).status, 403); ok('and bob cannot touch the admin\'s servers either');

    /* ═════ local server lifecycle against the fake Docker daemon ═════ */
    section('Local server start / stop (fake Docker daemon)');
    const L = (await mk(adminC, { name: 'Local', port: 26100, ram: 2, cpu: 150, disk: 1, startup: { motd: 'Hello', maxPlayers: 30, jvmOpts: '-XX:+UseG1GC' } })).data;
    const big = path.join(DATA, 'servers', L.id, 'big.bin'); sparse(big, Math.floor(1.5 * GB));
    const tooBig = await startWait(adminC, L.id); assert.strictEqual(tooBig.http.data.status, 'starting'); assert.strictEqual(tooBig.srv.status, 'offline'); assert.ok(/Disk limit reached/.test(tooBig.srv.lastError), tooBig.srv.lastError);
    assert.strictEqual(containers.size, 0); ok('start answers at once with "starting"; with files over the disk limit it ends offline and the reason is stored (lastError)');
    fs.rmSync(big);
    { const st = await startWait(adminC, L.id); assert.strictEqual(st.srv.status, 'running'); assert.strictEqual(st.srv.lastError, null); }
    const cname = 'phpanel_' + L.id.slice(0, 8); const cc = containers.get(cname).cfg;
    assert.strictEqual(cc.Image, 'itzg/minecraft-server:java21');
    for (const e of ['TYPE=PAPER', 'VERSION=1.21.4', 'MEMORY=1740M', 'MAX_PLAYERS=30', 'MOTD=Hello', 'JVM_OPTS=-XX:+UseG1GC', 'ONLINE_MODE=FALSE']) assert.ok(cc.Env.includes(e), e);
    assert.strictEqual(cc.HostConfig.Binds[0], `/srv/host-storage/servers/${L.id}:/data`); assert.strictEqual(cc.HostConfig.CpuQuota, 150000); assert.strictEqual(cc.HostConfig.Memory, 2 * GB);
    ok('container is created with the right image, env, 85% heap, CPU quota and the HOST path for the data folder (this is why the file manager was empty)');
    { const st = await startWait(adminC, L.id); assert.strictEqual(st.srv.status, 'running'); assert.strictEqual(st.srv.lastError, null); } assert.strictEqual(containers.size, 1);
    assert.ok(dlog.filter((l) => l === `DELETE /containers/${cname}`).length >= 2); ok('starting again with the old container still there works: it is removed first (this was the "409 name already in use" error)');
    await api(adminC, 'PATCH', `/servers/${L.id}`, { version: '26.3' }); await startWait(adminC, L.id);
    assert.strictEqual(containers.get(cname).cfg.Image, 'itzg/minecraft-server:java25'); ok('Minecraft 26.3 automatically runs on the Java 25 image');
    await api(adminC, 'PATCH', `/servers/${L.id}`, { version: '1.21.4' });
    const lock = (await api(adminC, 'GET', '/servers')).data.find((s) => s.id === L.id); assert.strictEqual(lock.status, 'running');
    assert.strictEqual((await api(adminC, 'POST', `/servers/${L.id}/stop`)).status, 200);
    const after = (await api(adminC, 'GET', '/servers')).data.find((s) => s.id === L.id); assert.deepStrictEqual([after.status, after.containerId], ['offline', null]); assert.strictEqual(containers.size, 0);
    ok('stop removes the container and clears the stored container id');

    /* ═════ startup + version + rename ═════ */
    section('Startup, Version and rename');
    const up = await api(adminC, 'PATCH', `/servers/${L.id}`, { name: 'Renamed', startup: { motd: 'New MOTD', maxPlayers: 40, onlineMode: true } });
    assert.deepStrictEqual([up.data.name, up.data.startup.motd, up.data.startup.maxPlayers, up.data.startup.onlineMode, up.data.startup.jvmOpts], ['Renamed', 'New MOTD', 40, true, '-XX:+UseG1GC']);
    assert.strictEqual((await api(adminC, 'PATCH', `/servers/${L.id}`, { startup: { jvmOpts: '-Xmx1G; rm -rf /' } })).status, 400);
    assert.strictEqual((await api(adminC, 'PATCH', `/servers/${L.id}`, { type: 'evil' })).status, 400);
    assert.strictEqual((await api(bobC, 'PATCH', `/servers/${L.id}`, { name: 'hacked' })).status, 403);
    ok('startup settings save (other fields kept), bad JVM flags / types are rejected, others cannot edit');
    await startWait(adminC, L.id); assert.ok(containers.get(cname).cfg.Env.includes('ONLINE_MODE=TRUE') && containers.get(cname).cfg.Env.includes('MOTD=New MOTD')); await api(adminC, 'POST', `/servers/${L.id}/stop`);
    ok('saved startup settings are used on the next start');

    /* ═════ local files + plugins ═════ */
    section('File manager and plugin install (local server)');
    const f = (p, b) => api(adminC, 'POST', `/servers/${L.id}/files/${p}`, b);
    assert.strictEqual((await f('write', { path: 'server.properties', content: 'motd=hi\n' })).status, 200);
    assert.strictEqual((await f('mkdir', { path: 'plugins/sub' })).status, 200);
    assert.strictEqual((await api(adminC, 'GET', `/servers/${L.id}/files/read?path=server.properties`)).data, 'motd=hi\n');
    const listing = (await api(adminC, 'GET', `/servers/${L.id}/files?path=plugins`)).data; assert.deepStrictEqual(listing.map((x) => [x.name, x.isDir]), [['sub', true]]);
    ok('create file, create folder, read, list inside a folder');
    for (const p of ['../../etc/passwd', '../x', 'plugins/../../x']) { assert.strictEqual((await f('write', { path: p, content: 'x' })).status, 400, p); assert.strictEqual((await api(adminC, 'GET', `/servers/${L.id}/files/read?path=${encodeURIComponent(p)}`)).status, 400); }
    assert.strictEqual((await f('delete', { path: '' })).status, 400); assert.strictEqual((await f('delete', { path: '/' })).status, 400);
    ok('../ traversal blocked for write/read; deleting the server root is refused');
    fs.writeFileSync(path.join(DATA, 'servers', L.id, 'world.dat'), Buffer.from([1, 0, 2, 0])); assert.strictEqual((await api(adminC, 'GET', `/servers/${L.id}/files/read?path=world.dat`)).status, 400); ok('binary files cannot be opened as text');
    assert.strictEqual((await f('delete', { path: 'plugins' })).status, 200); assert.ok(!fs.existsSync(path.join(DATA, 'servers', L.id, 'plugins'))); ok('delete a folder with its contents');

    const sr = (await api(adminC, 'GET', '/plugins/search?source=modrinth&q=cool&type=paper&version=1.21.4')).data.results; assert.strictEqual(sr[0].title, 'CoolPlugin');
    assert.ok(lastSearch.includes('categories:paper') && lastSearch.includes('categories:bukkit') && lastSearch.includes('versions:1.21.4')); ok('Modrinth search filters by the server\'s loader and Minecraft version');
    assert.strictEqual((await api(adminC, 'GET', '/plugins/search?source=modrinth&q=x&type=vanilla&version=1.21.4')).status, 400); assert.strictEqual((await api(adminC, 'GET', '/plugins/search?source=spiget&q=x&type=fabric&version=1.21.4')).status, 400);
    const sp = (await api(adminC, 'GET', '/plugins/search?source=spiget&q=free&type=paper&version=1.21.4')).data.results; assert.deepStrictEqual(sp.map((x) => x.title), ['FreePlugin']); ok('Spigot search hides paid plugins; vanilla / Fabric are refused sensibly');

    const inst = await api(adminC, 'POST', `/servers/${L.id}/plugins/install`, { source: 'modrinth', id: 'abc12345' }); assert.strictEqual(inst.status, 200, JSON.stringify(inst.data));
    assert.ok(lastSearch.includes('game_versions') && lastSearch.includes('1.21.4'));
    assert.ok(fs.readFileSync(path.join(DATA, 'servers', L.id, 'plugins', 'CoolPlugin-1.0.jar')).subarray(0, 4).equals(Buffer.from([0x50, 0x4b, 3, 4]))); ok('Modrinth install downloads the jar into plugins/');
    assert.strictEqual((await api(adminC, 'POST', `/servers/${L.id}/plugins/install`, { source: 'spiget', id: '1' })).status, 200); assert.ok(fs.existsSync(path.join(DATA, 'servers', L.id, 'plugins', 'FreePlugin-1.jar'))); ok('Spigot (Spiget) install follows the redirect and saves the jar');
    const pl = (await api(adminC, 'GET', `/servers/${L.id}/plugins`)).data; assert.deepStrictEqual(pl.files.map((x) => x.name).sort(), ['CoolPlugin-1.0.jar', 'FreePlugin-1.jar']); assert.strictEqual(pl.folder, 'plugins');
    for (const [id, re] of [['htmlhtml1', /not a valid \.jar/], ['evil00001', /blocked/], ['nothing01', /No version/]]) { const r = await api(adminC, 'POST', `/servers/${L.id}/plugins/install`, { source: 'modrinth', id }); assert.strictEqual(r.status, 400); assert.ok(re.test(r.data.error), r.data.error); }
    assert.ok(!fs.readdirSync(path.join(DATA, 'servers', L.id, 'plugins')).some((n) => n.endsWith('.part') || n === 'Blocked.jar' || n === 'Evil.jar')); ok('a non-jar download, a foreign host and an incompatible version are all refused and leave nothing behind');
    assert.strictEqual((await api(adminC, 'POST', `/servers/${L.id}/plugins/install`, { source: 'modrinth', id: '../../x' })).status, 400); assert.strictEqual((await api(adminC, 'POST', `/servers/${L.id}/plugins/install`, { source: 'nope', id: 'abc12345' })).status, 400);
    assert.strictEqual((await api(adminC, 'DELETE', `/servers/${L.id}/plugins/..%2F..%2Fserver.properties`)).status, 400);
    assert.strictEqual((await api(adminC, 'DELETE', `/servers/${L.id}/plugins/CoolPlugin-1.0.jar`)).status, 200); assert.ok(!fs.existsSync(path.join(DATA, 'servers', L.id, 'plugins', 'CoolPlugin-1.0.jar'))); ok('bad ids/sources/file names are rejected; removing a plugin works');
    const van = (await mk(adminC, { type: 'vanilla', port: 26200 })).data; assert.strictEqual((await api(adminC, 'POST', `/servers/${van.id}/plugins/install`, { source: 'modrinth', id: 'abc12345' })).status, 400); assert.strictEqual((await api(adminC, 'GET', `/servers/${van.id}/plugins`)).data.supported, false);
    const fab = (await mk(adminC, { type: 'fabric', port: 26201 })).data; await api(adminC, 'POST', `/servers/${fab.id}/plugins/install`, { source: 'modrinth', id: 'abc12345' }); assert.ok(fs.existsSync(path.join(DATA, 'servers', fab.id, 'mods', 'CoolPlugin-1.0.jar'))); assert.ok(lastSearch.includes('fabric')); ok('vanilla has no plugins; Fabric installs into mods/ with the fabric loader');

    /* ═════ uploads from the user's computer ═════ */
    section('Upload files and folders (local server)');
    const put = (c, id, rel, body) => fetch(`${BASE}/api/servers/${id}/files/upload?path=${encodeURIComponent(rel)}`, { method: 'PUT', headers: { 'Content-Type': 'application/octet-stream', ...(c ? { Cookie: c } : {}) }, body })
      .then(async (r) => ({ status: r.status, data: await r.json().catch(() => ({})) }));
    const lroot = path.join(DATA, 'servers', L.id);
    assert.strictEqual((await put(adminC, L.id, 'plugins/hello.txt', 'hello')).status, 200); assert.strictEqual(fs.readFileSync(path.join(lroot, 'plugins/hello.txt'), 'utf8'), 'hello');
    for (const [rel, txt] of [['world/region/r.0.0.mca', 'A'], ['world/level.dat', 'B'], ['world/data/deep/x.json', '{}']]) assert.strictEqual((await put(adminC, L.id, rel, txt)).status, 200, rel);
    assert.strictEqual(fs.readFileSync(path.join(lroot, 'world/data/deep/x.json'), 'utf8'), '{}'); ok('a file and a whole folder tree (world/region/…, world/data/deep/…) are uploaded with their structure');
    await put(adminC, L.id, 'plugins/hello.txt', 'changed'); assert.strictEqual(fs.readFileSync(path.join(lroot, 'plugins/hello.txt'), 'utf8'), 'changed');
    const bin = Buffer.from(Array.from({ length: 300000 }, (_, i) => (i * 7 + 3) % 256)); await put(adminC, L.id, 'mods/data.bin', bin); assert.ok(fs.readFileSync(path.join(lroot, 'mods/data.bin')).equals(bin));
    assert.ok(!fs.readdirSync(path.join(lroot, 'plugins')).some((n) => n.includes('.upload-'))); ok('uploading again overwrites; binary files arrive byte for byte; no temporary files are left');
    for (const rel of ['../evil.txt', 'a/../../evil.txt', 'a//b', 'a/./b', 'x\\y', '', '..']) assert.strictEqual((await put(adminC, L.id, rel, 'x')).status, 400, JSON.stringify(rel));
    assert.ok(!fs.existsSync(path.join(DATA, 'servers', 'evil.txt')) && !fs.existsSync(path.join(DATA, 'evil.txt'))); ok('"..", empty parts, backslashes and "." in the upload path are rejected, nothing escapes the server folder');
    const tooLarge = await put(adminC, L.id, 'big.bin', Buffer.alloc(2 * 1024 * 1024, 1)); assert.strictEqual(tooLarge.status, 413); assert.ok(/too large/.test(tooLarge.data.error)); assert.ok(!fs.existsSync(path.join(lroot, 'big.bin'))); assert.ok(!fs.readdirSync(lroot).some((n) => n.includes('.upload-'))); ok('a file over the size limit is refused with 413 (and the browser still receives the message) and leaves nothing behind');
    const D = (await mk(adminC, { name: 'DiskTest', port: 26300, disk: 1 })).data; sparse(path.join(DATA, 'servers', D.id, 'fill.bin'), GB - 100 * 1024);
    const full = await put(adminC, D.id, 'new.bin', Buffer.alloc(200 * 1024, 1)); assert.strictEqual(full.status, 400); assert.ok(/Disk limit reached/.test(full.data.error), full.data.error); assert.ok(!fs.existsSync(path.join(DATA, 'servers', D.id, 'new.bin')));
    assert.strictEqual((await put(adminC, D.id, 'fits.bin', Buffer.alloc(50 * 1024, 1))).status, 200); ok('the disk limit is enforced on uploads: 200 KB refused when only 100 KB is free, 50 KB accepted');
    assert.strictEqual((await put(bobC, L.id, 'x.txt', 'x')).status, 403); assert.strictEqual((await put(adminC, s1.data.id, 'x.txt', 'x')).status, 403); assert.strictEqual((await put(null, L.id, 'x.txt', 'x')).status, 401); ok('only the owner can upload (an admin cannot upload into someone else\'s server; no session = 401)');

    /* ═════ delete ═════ */
    section('Deleting servers');
    const del = (await mk(bobC, { name: 'Gone', ram: 1, cpu: 10, port: 25700 })); assert.strictEqual(del.status, 400); // bob is out of pool
    assert.strictEqual((await api(bobC, 'DELETE', `/servers/${s2.data.id}`)).status, 200); assert.ok(!fs.existsSync(path.join(DATA, 'servers', s2.data.id)));
    assert.strictEqual((await mk(bobC, { name: 'Gone', ram: 1, cpu: 10, port: 25700 })).status, 200); ok('owners can delete their own server (files removed) and the freed RAM can be used again');

    /* ═════ AFK + settings ═════ */
    section('AFK coins and settings');
    let afk = (await api(bobC, 'GET', '/afk')).data; assert.deepStrictEqual([afk.reward, afk.intervalHours, afk.canClaim], [50, 24, true]);
    const claim = await api(bobC, 'POST', '/afk/claim'); assert.strictEqual(claim.status, 200); assert.strictEqual(claim.data.coins, 50);
    const again = await api(bobC, 'POST', '/afk/claim'); assert.strictEqual(again.status, 429);
    afk = (await api(bobC, 'GET', '/afk')).data; assert.strictEqual(afk.canClaim, false); const hrs = (Date.parse(afk.nextClaimAt) - Date.now()) / 3.6e6; assert.ok(hrs > 23.9 && hrs <= 24);
    ok('AFK: 50 coins, second claim refused (429), next claim in ~24 h');
    assert.strictEqual((await api(adminC, 'POST', '/settings', { afkReward: 75, afkIntervalHours: 12 })).status, 200);
    users.update(users.findByUsername('bob').id, { lastAfkClaim: new Date(Date.now() - 13 * 3.6e6).toISOString() });
    const c2 = await api(bobC, 'POST', '/afk/claim'); assert.strictEqual(c2.data.earned, 75); assert.strictEqual(c2.data.coins, 125); ok('reward and interval come from Settings and apply immediately');
    for (const bad of [{ defaultRam: 0 }, { afkReward: -5 }, { panelName: '<b>x</b>' }, { adClientId: 'javascript:alert(1)' }, { afkIntervalHours: 'x' }]) assert.strictEqual((await api(adminC, 'POST', '/settings', bad)).status, 400, JSON.stringify(bad));
    ok('settings validation rejects bad values');
    assert.strictEqual((await api(adminC, 'POST', '/settings', { panelName: 'My Host', registrationOpen: false, adClientId: 'ca-pub-1234567890123456', adSlotId: '987654321' })).status, 200);
    assert.ok((await page(adminC)).includes('<title>My Host</title>')); assert.ok((await page(null, '/auth/login')).includes('My Host')); assert.ok(!(await page(null, '/auth/login')).includes('Create Account')); ok('panel name changes everywhere at once; closing registration hides the sign-up tab');
    const reg = await fetch(BASE + '/auth/register', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: 'username=newbie&password=secret1&email=n%40x.io' }); assert.strictEqual(reg.status, 403); assert.ok(!users.findByUsername('newbie')); ok('registration is really closed (not just hidden)');
    await api(adminC, 'POST', '/settings', { panelName: 'PHBAI Panel', registrationOpen: true });
    assert.ok((await api(bobC, 'GET', '/afk')).data.ads.clientId === 'ca-pub-1234567890123456'); ok('ads settings reach the AFK page');
    /* shop */
    assert.strictEqual((await api(bobC, 'POST', '/shop/buy', { item: 'ram-1' })).status, 400);       // 125 coins < 200
    users.update(users.findByUsername('bob').id, { coins: 1000 });
    const bought = (await api(bobC, 'POST', '/shop/buy', { item: 'ram-1' })).data; assert.deepStrictEqual([bought.coins, bought.ram], [800, 5]);
    assert.strictEqual((await api(bobC, 'POST', '/shop/buy', { item: 'free-ram' })).status, 400);
    me = (await api(bobC, 'GET', '/me')).data; assert.deepStrictEqual([me.coins, me.ram, me.usedRam, me.usedCpu], [800, 5, 3, 60]); ok('shop: not enough coins refused, purchase adds RAM, /me shows pool and usage (the Shop page was showing "—")');

    /* ═════ nodes: create, connect, run a server remotely ═════ */
    section('Nodes (add in the panel, agent connects)');
    const created = await api(adminC, 'POST', '/nodes', { name: 'Test Node' }); assert.strictEqual(created.status, 200);
    const token = created.data.token, nodeId = created.data.node.id; assert.ok(token.startsWith('phb_'));
    assert.strictEqual((await api(adminC, 'POST', '/nodes', { name: 'test node' })).status, 400); assert.strictEqual((await api(adminC, 'POST', '/nodes', { name: 'x' })).status, 400);
    const listed = (await api(adminC, 'GET', '/nodes')).data; assert.ok(!JSON.stringify(listed).includes(token) && !JSON.stringify(listed).includes('tokenHash')); assert.strictEqual(listed[0].online, false);
    assert.ok(!fs.readFileSync(path.join(DATA, 'nodes', 'nodes.json'), 'utf8').includes(token)); ok('add a node: key is shown once and only its hash is stored');
    const bad = io(BASE + '/agent', { auth: { token: 'phb_nottherealkey' }, reconnection: false, forceNew: true }); assert.strictEqual((await once(bad, 'connect_error')).message, 'invalid token'); bad.close();
    const agentData = path.join(tmp, 'agent-data');
    agent = createAgent({ config: { panelUrl: BASE, agentKey: token, name: 'agent-says-this', dataDir: agentData, allowedDownloadOrigins: [`http://127.0.0.1:${mport}`] }, docker: agentDocker, log: () => {} }); agent.connect();
    const n1 = await until(async () => { const l = (await api(adminC, 'GET', '/nodes')).data[0]; return l.online && l.docker ? l : null; });
    assert.deepStrictEqual([n1.name, n1.docker], ['Test Node', '27.0.0-fake']); ok('agent connects with the key; the node keeps the name the admin chose; Docker version is shown');
    assert.deepStrictEqual(Object.keys((await api(bobC, 'GET', '/nodes')).data[0]).sort(), ['id', 'name', 'online']);

    const R = (await mk(bobC, { name: 'Remote', ram: 1, cpu: 10, port: 25800, nodeId, type: 'purpur', startup: { motd: 'Remote MOTD' } })).data; assert.strictEqual(R.nodeId, nodeId);
    const rbig = path.join(agentData, 'servers', R.id, 'huge.bin'); sparse(rbig, 11 * GB);
    const rTooBig = await startWait(bobC, R.id); assert.strictEqual(rTooBig.srv.status, 'offline'); assert.ok(/Disk limit reached/.test(rTooBig.srv.lastError)); fs.rmSync(rbig);
    const rs = await startWait(bobC, R.id); assert.strictEqual(rs.srv.status, 'running', JSON.stringify(rs.srv));
    const rc = calls.find((c) => c[0] === 'create')[1];
    assert.strictEqual(rc.Image, 'itzg/minecraft-server:java21'); for (const e of ['TYPE=PURPUR', 'MEMORY=870M', 'MOTD=Remote MOTD']) assert.ok(rc.Env.includes(e), e);
    assert.strictEqual(rc.HostConfig.Binds[0], `${agentData}/servers/${R.id}:/data`); ok('remote start: Purpur container, startup MOTD, 85% heap, disk limit enforced on the node too');
    assert.deepStrictEqual((await api(bobC, 'GET', `/servers/${R.id}/stats`)).data, { cpu: '40.0', ram: '512' });
    assert.strictEqual((await api(bobC, 'POST', `/servers/${R.id}/command`, { cmd: 'say hi' })).data.output, 'ok'); assert.deepStrictEqual(calls.filter((c) => c[0] === 'exec').pop()[1], ['rcon-cli', 'say hi']);
    const players = (await api(bobC, 'GET', `/servers/${R.id}/players`)).data; assert.deepStrictEqual([players.online, players.count, players.max, players.players], [true, 2, 20, ['Steve', 'Alex']]);
    ok('stats, console command and the Players tab data work through the node');

    const rf = (m, p, b) => api(bobC, m, `/servers/${R.id}/${p}`, b);
    assert.strictEqual((await rf('POST', 'files/write', { path: 'server.properties', content: 'motd=x' })).status, 200); assert.strictEqual((await rf('POST', 'files/mkdir', { path: 'plugins/deep' })).status, 200);
    assert.strictEqual((await rf('GET', 'files/read?path=server.properties')).data, 'motd=x'); assert.deepStrictEqual((await rf('GET', 'files?path=plugins')).data.map((x) => x.name), ['deep']);
    assert.strictEqual((await rf('POST', 'files/write', { path: '../../pwned', content: 'x' })).status, 400); assert.strictEqual((await rf('POST', 'files/delete', { path: '' })).status, 400);
    assert.strictEqual((await rf('POST', 'files/delete', { path: 'plugins/deep' })).status, 200); assert.ok(!fs.existsSync(path.join(agentData, 'servers', R.id, 'plugins', 'deep')));
    ok('file manager on the node: write, read, list, mkdir, delete; traversal and root delete refused');
    assert.strictEqual((await rf('POST', 'plugins/install', { source: 'modrinth', id: 'abc12345' })).status, 200); assert.ok(fs.existsSync(path.join(agentData, 'servers', R.id, 'plugins', 'CoolPlugin-1.0.jar')));
    assert.strictEqual((await rf('GET', 'plugins')).data.files[0].name, 'CoolPlugin-1.0.jar'); assert.strictEqual((await rf('DELETE', 'plugins/CoolPlugin-1.0.jar')).status, 200);
    assert.strictEqual((await rf('POST', 'plugins/install', { source: 'modrinth', id: 'evil00001' })).status, 400); ok('plugin install/list/remove on the node (the agent downloads and re-checks the host itself)');

    const rroot = path.join(agentData, 'servers', R.id);
    const big900 = Buffer.from(Array.from({ length: 900 * 1024 }, (_, i) => (i * 13 + 5) % 256));
    assert.strictEqual((await put(bobC, R.id, 'world/region/r.1.1.mca', big900)).status, 200); assert.ok(fs.readFileSync(path.join(rroot, 'world/region/r.1.1.mca')).equals(big900));
    assert.strictEqual((await put(bobC, R.id, 'world/level.dat', 'tiny')).status, 200); assert.strictEqual((await put(bobC, R.id, 'empty.txt', '')).status, 200); assert.strictEqual(fs.statSync(path.join(rroot, 'empty.txt')).size, 0);
    ok('upload to a node: a 900 KB file (sent in 2 pieces) arrives byte for byte, folders are created, empty files work');
    for (const rel of ['../evil', 'a/../../evil', 'a//b']) assert.strictEqual((await put(bobC, R.id, rel, 'x')).status, 400, rel); assert.ok(!fs.existsSync(path.join(agentData, 'servers', 'evil')) && !fs.existsSync(path.join(agentData, 'evil')));
    const rLarge = await put(bobC, R.id, 'large.bin', Buffer.alloc(2 * 1024 * 1024, 1)); assert.strictEqual(rLarge.status, 413); assert.ok(!fs.readdirSync(rroot).some((n) => n.includes('.upload-') || n === 'large.bin'));
    const R2 = (await mk(bobC, { name: 'R2', ram: 1, cpu: 10, port: 25802, nodeId })).data; sparse(path.join(agentData, 'servers', R2.id, 'fill.bin'), 10 * GB - 100 * 1024);
    const rFull = await put(bobC, R2.id, 'new.bin', Buffer.alloc(200 * 1024, 1)); assert.strictEqual(rFull.status, 400); assert.ok(/Disk limit reached/.test(rFull.data.error), rFull.data.error);
    assert.strictEqual((await put(bobC, R2.id, 'fits.bin', Buffer.alloc(50 * 1024, 1))).status, 200); assert.strictEqual((await api(bobC, 'DELETE', `/servers/${R2.id}`)).status, 200);
    ok('node uploads: ../ refused, over-size file refused (no leftovers), the disk limit is enforced on the node too');

    const s1c = sock(bobC); await once(s1c, 'connect'); s1c.emit('join-server', R.id);
    assert.deepStrictEqual(await once(s1c, 'log-history'), ['[boot] line one', '[boot] line two']); await until(() => agentDocker.followStream);
    const gotLine = once(s1c, 'log-line'); agentDocker.followStream.write(frame('[Server] Done (3.2s)!\n')); assert.strictEqual(await gotLine, '[Server] Done (3.2s)!');
    ok('live console of a remote server reaches the browser, without frame-header garbage');
    s1c.emit('exec-cmd', { serverId: R.id, cmd: 'list' }); assert.ok((await once(s1c, 'cmd-result')).includes('players online')); s1c.close();
    const anon = sock(null); assert.strictEqual((await once(anon, 'connect_error')).message, 'unauthorized'); anon.close();
    const adminSock = sock(adminC); await once(adminSock, 'connect'); adminSock.emit('exec-cmd', { serverId: R.id, cmd: 'stop' }); assert.strictEqual(await once(adminSock, 'cmd-result'), 'Server not found'); adminSock.close();
    ok('console sockets: anonymous refused, and even an admin cannot use someone else\'s console');

    // local console history + stop/restart
    await startWait(adminC, L.id); const ls = sock(adminC); await once(ls, 'connect'); ls.emit('join-server', L.id);
    assert.deepStrictEqual(await once(ls, 'log-history'), ['[boot] local line']); ls.close(); await api(adminC, 'POST', `/servers/${L.id}/stop`); ok('local console history is decoded correctly');
    assert.strictEqual((await api(bobC, 'POST', `/servers/${R.id}/restart`)).status, 200); assert.strictEqual((await api(adminC, 'POST', `/servers/${R.id}/stop`)).status, 200);
    assert.ok(calls.some((c) => c[0] === 'restart') && calls.some((c) => c[0] === 'stop')); assert.strictEqual((await api(bobC, 'GET', '/servers')).data.find((x) => x.id === R.id).status, 'offline'); ok('restart, and an admin can stop a user\'s server (moderation)');
    assert.strictEqual((await api(bobC, 'POST', `/servers/${R.id}/backups`)).status, 501); ok('remote backups give a clear 501');

    assert.strictEqual((await api(bobC, 'DELETE', `/servers/${R.id}`)).status, 200); assert.ok(!fs.existsSync(path.join(agentData, 'servers', R.id))); assert.ok(calls.some((c) => c[0] === 'remove')); ok('deleting a remote server also wipes its files on the node');

    /* offline node + removal rules */
    const B = (await mk(adminC, { name: 'RemoteB', port: 25801, nodeId })).data;
    agent.stop(); await until(async () => !(await api(adminC, 'GET', '/nodes')).data[0].online);
    const off = await startWait(adminC, B.id); assert.deepStrictEqual([off.srv.status, off.srv.lastError], ['offline', 'Node is offline']);
    assert.strictEqual((await api(adminC, 'DELETE', `/nodes/${nodeId}`)).status, 400);
    assert.strictEqual((await api(adminC, 'DELETE', `/servers/${B.id}`)).status, 500); assert.strictEqual((await api(adminC, 'DELETE', `/servers/${B.id}?force=1`)).status, 200);
    ok('offline node: start says "Node is offline"; node with servers cannot be removed; admin can force-remove a stuck server record');

    /* regenerate key */
    agent = createAgent({ config: { panelUrl: BASE, agentKey: token, name: 'a', dataDir: agentData }, docker: agentDocker, log: () => {} }); agent.connect(); await until(async () => (await api(adminC, 'GET', '/nodes')).data[0].online);
    const regen = await api(adminC, 'POST', `/nodes/${nodeId}/token`); assert.strictEqual(regen.status, 200); assert.notStrictEqual(regen.data.token, token);
    await until(async () => !(await api(adminC, 'GET', '/nodes')).data[0].online); agent.stop();
    const oldTok = io(BASE + '/agent', { auth: { token }, reconnection: false, forceNew: true }); assert.strictEqual((await once(oldTok, 'connect_error')).message, 'invalid token'); oldTok.close();
    const newTok = io(BASE + '/agent', { auth: { token: regen.data.token }, reconnection: false, forceNew: true }); await once(newTok, 'connect'); newTok.close();
    ok('"New key" disconnects the agent at once, the old key stops working, the new one works');
    assert.strictEqual((await api(adminC, 'DELETE', `/nodes/${nodeId}`)).status, 200); assert.strictEqual((await api(adminC, 'GET', '/nodes')).data.length, 0); ok('empty node can be removed');

    /* ═════ the real installer script + real agent against the real panel ═════ */
    section('curl installer + agent');
    const sh = await (await fetch(BASE + '/install/agent.sh')).text(); assert.ok(sh.startsWith('#!/usr/bin/env bash'));
    const tgz = Buffer.from(await (await fetch(BASE + '/install/agent.tgz')).arrayBuffer()); const tar = zlib.gunzipSync(tgz);
    const names = []; for (let off = 0; off + 512 <= tar.length && tar[off] !== 0;) { names.push(tar.toString('utf8', off, off + 100).replace(/\0.*$/, '')); off += 512 + Math.ceil(parseInt(tar.toString('utf8', off + 124, off + 135), 8) / 512) * 512; }
    for (const need of ['package.json', 'src/agent.js', 'src/index.js', 'scripts/configure.js']) assert.ok(names.includes(need), 'missing ' + need + ' in ' + names);
    assert.ok(!names.some((n) => /node_modules|^test\/|config\/agent\.json|^data\//.test(n)), 'unwanted files: ' + names.filter((n) => /node_modules|^test\/|agent\.json|^data\//.test(n)));
    ok('panel serves the install script and the agent source (no node_modules, no tests)');
    const n2 = (await api(adminC, 'POST', '/nodes', { name: 'Installed Node' })).data; const dir = path.join(tmp, 'opt-agent');
    const out = execFileSync('bash', [path.join(ROOT, 'scripts/install-agent.sh'), '--panel', BASE, '--key', n2.token, '--name', 'Installed Node'],
      { env: { ...process.env, SKIP_DEPS: '1', SKIP_SERVICE: '1', PHBAI_INSTALL_DIR: dir, PHBAI_DATA_DIR: path.join(tmp, 'agent2-data') }, encoding: 'utf8', timeout: 120000 });
    assert.ok(out.includes('Done')); const cfg = JSON.parse(fs.readFileSync(path.join(dir, 'config/agent.json'), 'utf8'));
    assert.deepStrictEqual([cfg.panelUrl, cfg.agentKey, cfg.name], [BASE, n2.token, 'Installed Node']); assert.ok(fs.existsSync(path.join(dir, 'node_modules/socket.io-client')));
    ok('install-agent.sh downloads, installs dependencies and writes the config');
    installed = spawn('node', ['src/index.js'], { cwd: dir, env: { ...process.env, DOCKER_SOCKET: path.join(tmp, 'no-such.sock') } });
    const nn = await until(async () => { const l = (await api(adminC, 'GET', '/nodes')).data.find((x) => x.name === 'Installed Node'); return l && l.online && l.dockerError ? l : null; }, 15000);
    assert.ok(nn.agentVersion); installed.kill(); ok('the installed agent connects to the panel by itself and reports that Docker is not reachable on that machine');

    /* ═════ terminal user management ═════ */
    section('Terminal user tool');
    const cli = (...a) => execFileSync('node', ['scripts/user.js', ...a], { cwd: ROOT, env: process.env, encoding: 'utf8' });
    assert.ok(cli('add', 'cliadmin', 'pass1234', '--admin').includes('ADMIN')); const cc2 = await login('cliadmin', 'pass1234'); assert.strictEqual((await api(cc2, 'GET', '/me')).data.role, 'admin');
    assert.ok(cli('list').includes('cliadmin')); cli('passwd', 'cliadmin', 'newpass99'); await login('cliadmin', 'newpass99');
    cli('demote', 'cliadmin'); me = (await api(cc2, 'GET', '/me')).data; assert.deepStrictEqual([me.role, me.ram, me.cpu], ['user', 4, 100]); assert.strictEqual((await api(cc2, 'GET', '/settings')).status, 403);
    ok('add --admin / list / passwd / demote work and take effect on a live session');
    cli('admin', 'cliadmin'); assert.strictEqual((await api(cc2, 'GET', '/settings')).status, 200); cli('add', 'plain', 'secret77'); assert.strictEqual((await api(await login('plain', 'secret77'), 'GET', '/me')).data.role, 'user');
    assert.throws(() => cli('add', 'x', 'secret77'), /Username/); assert.throws(() => cli('add', 'plain', 'secret77'), /taken/); assert.throws(() => cli('delete', 'bob'), /owns servers/); cli('delete', 'plain');
    ok('promote, plain user, validation errors, and deleting a user who still owns servers is refused');

    /* ═════ brute force protection (keep last: it blocks this IP for 15 minutes) ═════ */
    section('Login rate limit');
    let blocked = 0; for (let i = 0; i < 25 && !blocked; i++) { const r = await fetch(BASE + '/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: 'username=nobody&password=wrongwrong' }); if (r.status === 429) { blocked = i + 1; assert.ok((await r.text()).includes('Too many attempts')); } }
    assert.ok(blocked > 0 && blocked <= 16, 'blocked after ' + blocked); ok(`password guessing is stopped after ${blocked} tries`);

    console.log(`\n  ${pass} end-to-end checks passed\n`);
  } catch (e) {
    console.error('\n  FAILED:', e.message, '\n', (e.stack || '').split('\n').slice(1, 5).join('\n'), '\n--- panel log (tail) ---\n', plog.slice(-1800));
    process.exitCode = 1;
  } finally {
    try { agent && agent.stop(); } catch {}
    try { installed && installed.kill(); } catch {}
    panel.kill(); dockerd.close(); market.close();
    fs.rmSync(tmp, { recursive: true, force: true });
    setTimeout(() => process.exit(), 300);
  }
})();
