// Isolated: never touches the real storage/ or config/ folders
const fs = require('fs'), os = require('os'), path = require('path'), assert = require('assert');
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'phbai-unit-'));
process.env.DATA_DIR = path.join(tmp, 'storage');
process.env.CONFIG_DIR = path.join(tmp, 'config');

const settings = require('../src/handlers/settings');
const users    = require('../src/handlers/users');
const servers  = require('../src/handlers/servers');
const versions = require('../src/handlers/versions');
const docker   = require('../src/handlers/docker');
const { parsePlayers } = require('../src/handlers/players');
const { safeJoin } = require('../src/handlers/safepath');

let n = 0;
const t = (name, fn) => { try { fn(); } catch (e) { console.error('  FAIL ' + name + '\n   ', e.message); process.exitCode = 1; return; } n++; console.log('  ok  ' + name); };

/* settings */
t('settings: defaults are 4 GB / 1 CPU / 10 GB, name PHBAI Panel, AFK 50 coins / 24 h', () => {
  const s = settings.get();
  assert.deepStrictEqual([s.defaultRam, s.defaultCpu, s.defaultDisk, s.afkReward, s.afkIntervalHours, s.panelName], [4, 100, 10, 50, 24, 'PHBAI Panel']);
});
t('settings: update validates and ignores unknown keys', () => {
  assert.throws(() => settings.update({ defaultRam: 0 }), /defaultRam/);
  assert.throws(() => settings.update({ afkReward: 'lots' }), /afkReward/);
  assert.throws(() => settings.update({ adClientId: '<script>' }), /adClientId/);
  settings.update({ afkReward: 75, evil: 'x', sessionSecret: 'nope' });
  assert.strictEqual(settings.get().afkReward, 75);
  assert.ok(!fs.readFileSync(path.join(process.env.CONFIG_DIR, 'panel.json'), 'utf8').includes('nope'));
  settings.update({ afkReward: 50 });
});
t('settings: old default name "PHPanel" is shown as PHBAI Panel', () => {
  fs.writeFileSync(path.join(process.env.CONFIG_DIR, 'panel.json'), JSON.stringify({ panelName: 'PHPanel', port: 5001 }));
  assert.strictEqual(settings.get().panelName, 'PHBAI Panel');
  settings.update({ panelName: 'My Host' });
  assert.strictEqual(JSON.parse(fs.readFileSync(path.join(process.env.CONFIG_DIR, 'panel.json'))).port, 5001);   // other keys survive
  settings.update({ panelName: 'PHBAI Panel' });
});

/* users */
t('users: new user gets the configured pool', () => {
  const u = users.create({ username: 'alice', email: 'a@x.io', password: 'secret1' });
  assert.deepStrictEqual([u.role, u.ram, u.cpu, u.disk, u.coins], ['user', 4, 100, 10, 0]);
});
t('users: validation (name, password, email, duplicates ignoring case)', () => {
  assert.throws(() => users.create({ username: 'a', password: 'secret1' }), /Username/);
  assert.throws(() => users.create({ username: '<script>alert(1)</script>', password: 'secret1' }), /Username/);
  assert.throws(() => users.create({ username: 'bobby', password: '123' }), /Password/);
  assert.throws(() => users.create({ username: 'bobby', password: 'secret1', email: 'nope' }), /email/);
  assert.throws(() => users.create({ username: 'ALICE', password: 'secret1' }), /taken/);
  assert.ok(users.findByUsername('Alice'));
});
t('users: updateProfile only changes username/email/password', () => {
  const u = users.findByUsername('alice');
  users.updateProfile(u.id, { username: 'alice2', role: 'admin', coins: 99999, ram: 999 });
  const after = users.findById(u.id);
  assert.deepStrictEqual([after.username, after.role, after.coins, after.ram], ['alice2', 'user', 0, 4]);
  assert.throws(() => users.updateProfile(u.id, { password: '12' }), /Password/);
});

/* servers */
t('servers: startup settings are validated', () => {
  assert.deepStrictEqual(servers.sanitizeStartup({ motd: 'Hi', maxPlayers: '30', onlineMode: 'true', jvmOpts: '-XX:+UseG1GC -Dx=1' }), { motd: 'Hi', maxPlayers: 30, onlineMode: true, jvmOpts: '-XX:+UseG1GC -Dx=1' });
  assert.throws(() => servers.sanitizeStartup({ jvmOpts: '-Xmx1G; rm -rf /' }), /not allowed/);
  assert.throws(() => servers.sanitizeStartup({ jvmOpts: '$(reboot)' }), /not allowed/);
  assert.throws(() => servers.sanitizeStartup({ maxPlayers: 0 }), /Max players/);
  assert.throws(() => servers.sanitizeStartup({ motd: 'x'.repeat(101) }), /100/);
  assert.strictEqual(servers.sanitizeStartup({ motd: 'a\nb\x00c' }).motd, 'abc');
});
t('servers: updateStatus can clear the container id (stop used to leave a stale one)', () => {
  const s = servers.create({ name: 'x', type: 'paper', version: '1.21.4', port: 25565, ram: 1, cpu: 100, disk: 10, ownerId: 'o' });
  servers.updateStatus(s.id, 'running', 'cid');
  assert.strictEqual(servers.findById(s.id).containerId, 'cid');
  servers.updateStatus(s.id, 'starting');
  assert.strictEqual(servers.findById(s.id).containerId, 'cid');       // untouched
  servers.updateStatus(s.id, 'offline', null);
  assert.strictEqual(servers.findById(s.id).containerId, null);
});

/* versions */
t('versions: Java image per Minecraft version (26.x needs Java 25)', () => {
  const want = { '26.3': 'java25', '26.1': 'java25', LATEST: 'java25', '1.21.8': 'java21', '1.20.6': 'java21', '1.20.5': 'java21', '1.20.4': 'java17', '1.18.2': 'java17', '1.17.1': 'java17', '1.16.5': 'java8-multiarch', '1.8.8': 'java8-multiarch' };
  for (const [v, tag] of Object.entries(want)) assert.strictEqual(versions.imageFor(v), 'itzg/minecraft-server:' + tag, v);
});
t('versions: ordering treats 26.x as newer than 1.21.x', () => {
  assert.deepStrictEqual(versions.newestFirst(['1.9', '1.21.4', '26.1', '1.21', '1.21.10', 'junk', '26.3']), ['26.3', '26.1', '1.21.10', '1.21.4', '1.21', '1.9']);
});
t('versions: version strings are validated strictly', () => {
  for (const ok of ['1.21.4', '26.3', 'LATEST', '1.8']) assert.ok(versions.VERSION_RE.test(ok), ok);
  for (const bad of ['1.21.4\nEULA=FALSE', '../x', '1.21.4; ls', '', 'latest', '1.2.3.4']) assert.ok(!versions.VERSION_RE.test(bad), JSON.stringify(bad));
});
t('versions: all six types are known', () => assert.deepStrictEqual(Object.keys(versions.TYPES).sort(), ['fabric', 'forge', 'paper', 'purpur', 'spigot', 'vanilla']));

/* docker env */
t('docker: container env uses startup settings and 85% heap', () => {
  const env = docker.buildEnv({ type: 'purpur', version: '1.21.4', ram: 2, startup: { motd: 'Hello', maxPlayers: 30, onlineMode: true, jvmOpts: '-XX:+UseG1GC' } });
  for (const e of ['TYPE=PURPUR', 'VERSION=1.21.4', 'MEMORY=1740M', 'MAX_PLAYERS=30', 'ONLINE_MODE=TRUE', 'MOTD=Hello', 'JVM_OPTS=-XX:+UseG1GC', 'EULA=TRUE']) assert.ok(env.includes(e), e);
  assert.ok(!docker.buildEnv({ type: 'paper', version: '1.21.4', ram: 1, startup: {} }).some((e) => e.startsWith('JVM_OPTS')));
});
t('docker: log frames are decoded', () => {
  const b = Buffer.from('hello\n'); const h = Buffer.alloc(8); h[0] = 1; h.writeUInt32BE(b.length, 4);
  assert.strictEqual(docker.demuxBuffer(Buffer.concat([h, b])), 'hello\n');
});

/* players, paths */
t('players: parses the list command', () => {
  assert.deepStrictEqual(parsePlayers('There are 2 of a max of 20 players online: Steve, Alex'), { count: 2, max: 20, players: ['Steve', 'Alex'] });
  assert.deepStrictEqual(parsePlayers('\x1b[0mThere are 0 of a max of 20 players online:'), { count: 0, max: 20, players: [] });
  assert.deepStrictEqual(parsePlayers('garbage'), { count: 0, max: null, players: [] });
  assert.deepStrictEqual(parsePlayers('There are 1 of a max of 20 players online: x; rm -rf').players, []);   // not a valid name
});
t('safepath: blocks traversal', () => {
  const root = path.join(tmp, 'r'); fs.mkdirSync(root);
  assert.throws(() => safeJoin(root, '../x'));
  assert.ok(safeJoin(root, 'plugins/a.jar'));
});

fs.rmSync(tmp, { recursive: true, force: true });
console.log(`\n  ${n} unit tests passed\n`);
