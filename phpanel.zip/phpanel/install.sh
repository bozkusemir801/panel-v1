#!/usr/bin/env bash
# PHBAI Panel installer (Docker).
#   Inside the project folder:   bash install.sh
#   From anywhere (needs git):   curl -sSL https://raw.githubusercontent.com/OWNER/REPO/main/install.sh | bash -s -- --repo https://github.com/OWNER/REPO.git
# Optional: --admin-user NAME --admin-pass PASSWORD   (creates the first administrator)
set -euo pipefail

REPO=""; DIR="phbai-panel"; ADMIN_USER=""; ADMIN_PASS=""; PORT="${PORT:-5001}"

say() { printf '\n\033[1;36m==>\033[0m %s\n' "$*"; }
die() { printf '\n\033[1;31mError:\033[0m %s\n\n' "$*" >&2; exit 1; }
have() { command -v "$1" >/dev/null 2>&1; }

while [ $# -gt 0 ]; do
  case "$1" in
    --repo) REPO="${2:-}"; shift 2 ;;
    --dir)  DIR="${2:-}";  shift 2 ;;
    --admin-user) ADMIN_USER="${2:-}"; shift 2 ;;
    --admin-pass) ADMIN_PASS="${2:-}"; shift 2 ;;
    --port) PORT="${2:-}"; shift 2 ;;
    *) die "Unknown option: $1" ;;
  esac
done

# 1. Docker
if ! have docker; then
  say "Installing Docker"
  have curl || die "curl is required"
  curl -fsSL https://get.docker.com | sh
  have systemctl && systemctl enable --now docker || true
fi
docker compose version >/dev/null 2>&1 || die "Docker Compose v2 is missing. Install the 'docker-compose-plugin' package."

# 2. Project files
if [ ! -f docker-compose.yml ]; then
  [ -n "$REPO" ] || die "Run this inside the panel folder, or pass --repo <git url>."
  have git || die "git is required to use --repo"
  say "Downloading the panel"
  git clone --depth 1 "$REPO" "$DIR"
  cd "$DIR"
fi

# 3. Settings: random session secret, and the real host path of ./storage
#    (the panel asks Docker to mount game server folders, and Docker needs the HOST path)
if [ ! -f .env ]; then
  say "Creating .env"
  SECRET="$( (have openssl && openssl rand -hex 32) || head -c 32 /dev/urandom | od -An -tx1 | tr -d ' \n')"
  printf 'SESSION_SECRET=%s\nHOST_DATA_DIR=%s/storage\nPORT=%s\n' "$SECRET" "$(pwd)" "$PORT" > .env
  chmod 600 .env
fi
mkdir -p storage config

# 4. Start
say "Building and starting the panel (first time takes a few minutes)"
docker compose up -d --build

say "Waiting for the panel"
for _ in $(seq 1 60); do
  curl -fsS -o /dev/null "http://localhost:${PORT}/auth/login" 2>/dev/null && break
  curl -fsS -o /dev/null "http://localhost:${PORT}/setup" 2>/dev/null && break
  sleep 2
done

# 5. First administrator
if [ -n "$ADMIN_USER" ] && [ -n "$ADMIN_PASS" ]; then
  say "Creating administrator \"$ADMIN_USER\""
  docker compose exec -T phpanel node scripts/user.js add "$ADMIN_USER" "$ADMIN_PASS" --admin
elif [ -t 0 ] || [ -e /dev/tty ]; then
  printf '\nCreate the administrator now? [Y/n] '; read -r ans </dev/tty || ans="n"
  if [ "${ans:-Y}" != "n" ] && [ "${ans:-Y}" != "N" ]; then
    printf 'Username: '; read -r ADMIN_USER </dev/tty
    printf 'Password (min 6): '; read -rs ADMIN_PASS </dev/tty; echo
    docker compose exec -T phpanel node scripts/user.js add "$ADMIN_USER" "$ADMIN_PASS" --admin
  fi
fi

say "Done!  Open  http://localhost:${PORT}"
echo "    Add users later:  docker compose exec phpanel node scripts/user.js add NAME PASSWORD [--admin]"
echo "    Logs:             docker compose logs -f"
