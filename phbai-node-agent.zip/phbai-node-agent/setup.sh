#!/usr/bin/env bash
# PHBAI node agent: kurulum sihirbazı / setup wizard
#
#   bash setup.sh                 -> asks for the panel address and key, installs and starts the agent
#   bash setup.sh --panel https://PANEL --key phb_KEY --name node-1      (no questions)
#   bash setup.sh --service       -> (root) also create a systemd service so it starts at boot
#   bash setup.sh stop | start | status | logs
set -euo pipefail
cd "$(dirname "$0")"

say()  { printf '\n\033[1;36m==>\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33m!\033[0m %s\n' "$*"; }
die()  { printf '\n\033[1;31mHata / Error:\033[0m %s\n\n' "$*" >&2; exit 1; }
have() { command -v "$1" >/dev/null 2>&1; }

ACTION=install
case "${1:-}" in install|start|stop|logs|status) ACTION="$1"; shift ;; esac

PIDFILE="agent.pid"; LOGFILE="agent.log"
is_running() { [ -f "$PIDFILE" ] && kill -0 "$(cat "$PIDFILE")" 2>/dev/null; }
stop_agent() { if is_running; then kill "$(cat "$PIDFILE")" 2>/dev/null || true; sleep 1; rm -f "$PIDFILE"; echo "Agent durduruldu / stopped."; else echo "Agent çalışmıyor / not running."; fi; }
start_agent() {
  [ -f config/agent.json ] || die "Önce kurulum yapın / run the setup first:  bash setup.sh"
  is_running && stop_agent >/dev/null
  : > "$LOGFILE"
  nohup node src/index.js >> "$LOGFILE" 2>&1 &
  echo $! > "$PIDFILE"
}
wait_connected() {
  for _ in $(seq 1 20); do
    if grep -q "Connected to" "$LOGFILE" 2>/dev/null; then return 0; fi
    if grep -q "rejected the token" "$LOGFILE" 2>/dev/null; then return 2; fi
    sleep 1
  done
  return 1
}

case "$ACTION" in
  stop)   stop_agent; exit 0 ;;
  logs)   exec tail -n 60 -f "$LOGFILE" ;;
  status) if is_running; then echo "Çalışıyor / running (pid $(cat "$PIDFILE"))"; tail -n 5 "$LOGFILE"; else echo "Çalışmıyor / not running"; fi; exit 0 ;;
  start)  start_agent; echo "Başlatıldı / started. Logs:  bash setup.sh logs"; exit 0 ;;
esac

PANEL=""; KEY=""; NAME=""; SERVICE=0
while [ $# -gt 0 ]; do
  case "$1" in
    --panel) PANEL="${2:-}"; shift 2 ;;
    --key)   KEY="${2:-}";   shift 2 ;;
    --name)  NAME="${2:-}";  shift 2 ;;
    --service) SERVICE=1; shift ;;
    *) die "Bilinmeyen seçenek / unknown option: $1" ;;
  esac
done

ask() {  # ask VAR "question"
  local var="$1" q="$2"
  if [ -z "${!var}" ] && (: </dev/tty) 2>/dev/null; then read -r -p "$q" "$var" </dev/tty || true; fi
}
ask PANEL "Panel adresi / Panel address (örn. https://panelim.com veya http://1.2.3.4:5001): "
ask KEY   "Node anahtarı / Node key (panelde Nodes -> Add node, 'phb_' ile başlar): "
[ -n "$NAME" ] || NAME="$(hostname)"
[ -n "$PANEL" ] && [ -n "$KEY" ] || die "Panel adresi ve anahtar gerekli / panel address and key are required."
PANEL="${PANEL%/}"
case "$PANEL" in http://*|https://*) ;; *) die "Panel adresi http:// veya https:// ile başlamalı / must start with http:// or https://" ;; esac

# 1. Node.js
have node || die "Node.js yok / Node.js is missing. Ubuntu/Debian:  curl -fsSL https://deb.nodesource.com/setup_lts.x | sudo -E bash - && sudo apt-get install -y nodejs"
[ "$(node -p 'process.versions.node.split(".")[0]')" -ge 18 ] || die "Node.js 18 veya üstü gerekli / Node.js 18+ is required (you have $(node -v))."

# 2. Docker (warn only: the panel will show "Docker not reachable" until it works)
if ! have docker; then
  warn "Docker kurulu değil / Docker is not installed. Install it with:  curl -fsSL https://get.docker.com | sudo sh"
elif ! docker info >/dev/null 2>&1; then
  warn "Docker çalışmıyor ya da erişilemiyor / Docker is not running or not reachable by this user (try 'sudo' or add yourself to the docker group)."
  warn "Port hatası (docker-proxy) alırsanız / if you get a docker-proxy port error:  echo '{\"userland-proxy\": false}' | sudo tee /etc/docker/daemon.json  and restart Docker."
fi

# 3. Install + configure
say "Bağımlılıklar kuruluyor / Installing dependencies"
npm install --omit=dev --no-audit --no-fund --loglevel=error
say "Ayarlanıyor / Configuring"
npm run configure --silent -- --panel "$PANEL" --key "$KEY" --name "$NAME" --data-dir "${PHBAI_DATA_DIR:-$PWD/data}"

# 4. Run
if [ "$SERVICE" = "1" ]; then
  [ "$(id -u)" -eq 0 ] || die "--service için root gerekli / --service needs root:  sudo bash setup.sh --service"
  have systemctl && [ -d /run/systemd/system ] || die "systemd bulunamadı / systemd not found."
  stop_agent >/dev/null || true
  cat > /etc/systemd/system/phbai-agent.service <<UNIT
[Unit]
Description=PHBAI node agent
After=network-online.target docker.service
Wants=network-online.target

[Service]
WorkingDirectory=$PWD
ExecStart=$(command -v node) src/index.js
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
UNIT
  systemctl daemon-reload && systemctl enable --now phbai-agent
  say "Servis oluşturuldu / service created. Logs:  journalctl -u phbai-agent -f"
  exit 0
fi

say "Agent başlatılıyor / Starting the agent"
start_agent
set +e; wait_connected; rc=$?; set -e
echo; tail -n 6 "$LOGFILE" | sed 's/^/    /'
echo
if [ "$rc" = "0" ]; then
  say "Bağlandı! / Connected! Panelde Nodes sayfasında 'Online' görünmeli."
elif [ "$rc" = "2" ]; then
  die "Panel anahtarı reddetti / the panel rejected the key. Panelde 'New key' ile yeni anahtar alın ve tekrar çalıştırın: bash setup.sh"
else
  warn "Henüz bağlanamadı / not connected yet. Panel adresi doğru ve bu makineden erişilebilir mi? Kontrol:  curl -I $PANEL/auth/login"
  warn "Loglar / logs:  bash setup.sh logs"
fi
echo "    Durdur / stop:   bash setup.sh stop"
echo "    Başlat / start:  bash setup.sh start"
echo "    Açılışta otomatik / at boot (root):  sudo bash setup.sh --service"
