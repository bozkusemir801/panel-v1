# PHBAI Node Agent

Lets a PHBAI Panel run Minecraft servers on **this** machine. It connects out to the panel and carries out the Docker
commands the panel sends. Needs **Node.js 18+** and **Docker** on this machine.

## Install (3 steps)
1. In the panel open **Nodes -> Add node**, type a name. The panel shows a key that starts with `phb_`.
2. Copy this folder to the machine and run:
   ```bash
   bash setup.sh
   ```
   It asks for the panel address and the key, installs everything and starts the agent.
3. In the panel, the node shows **Online**. Pick it when creating a server.

No questions: `bash setup.sh --panel https://YOUR_PANEL --key phb_KEY --name node-1`

## Day to day
```bash
bash setup.sh status     # running?
bash setup.sh logs       # live log
bash setup.sh stop       # stop
bash setup.sh start      # start again
sudo bash setup.sh --service   # start automatically at boot (systemd)
```

## Good to know
* Run it directly on the machine, not in a container: server data lives in `./data` (or `--data-dir`).
* Open the Minecraft ports you give your servers in this machine's firewall.
* Use HTTPS for the panel address when the node is on another network; the key is sent while connecting.
* If Docker says `docker-proxy: no such file or directory` when a server starts:
  `echo '{"userland-proxy": false}' | sudo tee /etc/docker/daemon.json` and restart Docker.
* The agent re-checks everything it receives, keeps file access inside `data/servers/<id>`, and only downloads plugins
  from Modrinth and Spigot hosts.
* Tests: `npm test`.
