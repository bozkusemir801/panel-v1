const fs   = require('fs');
const path = require('path');

/**
 * Resolve `rel` inside `root` and make sure the result cannot escape it,
 * neither with ".." nor through symlinks. Throws on any attempt.
 */
function safeJoin(root, rel) {
  const base = fs.existsSync(root) ? fs.realpathSync(root) : path.resolve(root);
  const clean = String(rel || '').replace(/\0/g, '').replace(/^[/\\]+/, '');
  const target = path.resolve(base, clean);

  if (target !== base && !target.startsWith(base + path.sep)) {
    throw new Error('Path is outside the server directory');
  }

  // Follow symlinks: check the real location of the target, or of its
  // closest existing parent when the target doesn't exist yet (writes).
  let probe = target;
  while (!fs.existsSync(probe) && probe !== base) probe = path.dirname(probe);
  if (fs.existsSync(probe)) {
    const real = fs.realpathSync(probe);
    if (real !== base && !real.startsWith(base + path.sep)) {
      throw new Error('Path is outside the server directory');
    }
  }
  return target;
}

module.exports = { safeJoin };
