const fs   = require('fs');
const os   = require('os');
const path = require('path');

const file = path.join(__dirname, '..', 'config', 'agent.json');

function load() {
  let f = {};
  if (fs.existsSync(file)) {
    try { f = JSON.parse(fs.readFileSync(file, 'utf8')); }
    catch (e) { throw new Error(`config/agent.json is not valid JSON: ${e.message}`); }
  }
  const cfg = {
    panelUrl:     process.env.PHPANEL_URL    || f.panelUrl,
    agentKey:     process.env.PHPANEL_KEY    || f.agentKey,
    name:         process.env.PHPANEL_NAME   || f.name || os.hostname(),
    dataDir:      path.resolve(process.env.PHPANEL_DATA_DIR || f.dataDir || path.join(__dirname, '..', 'data')),
    dockerSocket: process.env.DOCKER_SOCKET  || f.dockerSocket || '/var/run/docker.sock',
  };
  if (!cfg.panelUrl || !cfg.agentKey) {
    throw new Error('Agent is not configured. Run: npm run configure -- --panel <URL> --key <TOKEN>');
  }
  return cfg;
}

module.exports = { load };
