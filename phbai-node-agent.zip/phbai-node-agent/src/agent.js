const fs   = require('fs');
const os   = require('os');
const path = require('path');
const { PassThrough, Readable, Transform } = require('stream');
const { pipeline } = require('stream/promises');
const { io } = require('socket.io-client');
const { safeJoin } = require('./safepath');

const VERSION = require('../package.json').version;

const TYPES = { paper: 'PAPER', spigot: 'SPIGOT', purpur: 'PURPUR', fabric: 'FABRIC', forge: 'FORGE', vanilla: 'VANILLA' };

const ID_RE  = /^[A-Za-z0-9-]{8,64}$/;
const VER_RE = /^(LATEST|\d{1,2}\.\d{1,2}(\.\d{1,2})?)$/;
const MAX_FILE = 2 * 1024 * 1024;       // 2 MB (text files)
const MAX_DOWNLOAD = 100 * 1024 * 1024; // 100 MB (plugin jars)
const MAX_UPLOAD = Math.floor(Number(process.env.MAX_UPLOAD_MB || 500) * 1024 * 1024);   // per uploaded file
const GB = 1024 * 1024 * 1024;

// Where plugins/mods may be downloaded from (the panel decides the URL, we double-check it)
const ALLOWED_HOSTS = new Set(['cdn.modrinth.com', 'api.modrinth.com', 'api.spiget.org', 'cdn.spiget.org', 'spigotmc.org', 'www.spigotmc.org']);

/** Which itzg/minecraft-server tag (Java version) can run this Minecraft version. Same rules as the panel. */
function javaTag(version) {
  if (version === 'LATEST') return 'java25';
  const [maj, min = 0, patch = 0] = String(version).split('.').map(Number);
  if (maj >= 26) return 'java25';
  if (min <= 16) return 'java8-multiarch';
  if (min <= 19) return 'java17';
  if (min === 20) return patch >= 5 ? 'java21' : 'java17';
  return 'java21';
}
const imageFor = (version) => `itzg/minecraft-server:${javaTag(version)}`;
const heapMb = (ram) => Math.floor(ram * 1024 * 0.85);

const intIn = (v, min, max, label) => {
  const n = Number.parseInt(v, 10);
  if (!Number.isFinite(n) || n < min || n > max) throw new Error(`Invalid ${label}`);
  return n;
};

function cleanStartup(st = {}) {
  const motd = String(st.motd ?? 'A Minecraft Server').replace(/[\x00-\x1f\x7f]/g, '').trim().slice(0, 100) || 'A Minecraft Server';
  const jvm  = String(st.jvmOpts ?? '').trim();
  if (jvm.length > 300 || !/^[A-Za-z0-9 _.:=,+\-\/@%]*$/.test(jvm)) throw new Error('Invalid JVM flags');
  return { motd, maxPlayers: intIn(st.maxPlayers ?? 20, 1, 1000, 'max players'), onlineMode: st.onlineMode === true, jvmOpts: jvm };
}

/** Never trust what arrives over the wire, even from the panel. */
function cleanSrv(srv, full = false) {
  if (!srv || typeof srv.id !== 'string' || !ID_RE.test(srv.id)) throw new Error('Invalid server id');
  const out = { id: srv.id, containerName: `phpanel_${srv.id.slice(0, 8)}` };
  if (full) {
    if (!Object.prototype.hasOwnProperty.call(TYPES, srv.type)) throw new Error('Unsupported server type');
    if (!VER_RE.test(String(srv.version))) throw new Error('Invalid version');
    out.type    = srv.type;
    out.version = String(srv.version);
    out.port    = intIn(srv.port, 1, 65535, 'port');
    out.ram     = intIn(srv.ram, 1, 256, 'ram');
    out.cpu     = intIn(srv.cpu, 10, 100000, 'cpu');
    out.disk    = intIn(srv.disk ?? 10, 1, 1000, 'disk');
    out.startup = cleanStartup(srv.startup);
  }
  return out;
}

function buildEnv(s) {
  const env = [
    'EULA=TRUE', `TYPE=${TYPES[s.type]}`, `VERSION=${s.version}`, `MEMORY=${heapMb(s.ram)}M`,
    `MAX_PLAYERS=${s.startup.maxPlayers}`, `ONLINE_MODE=${s.startup.onlineMode ? 'TRUE' : 'FALSE'}`, `MOTD=${s.startup.motd}`,
  ];
  if (s.startup.jvmOpts) env.push(`JVM_OPTS=${s.startup.jvmOpts}`);
  return env;
}

function dirSize(dir) {
  let total = 0;
  const stack = [dir];
  while (stack.length) {
    const d = stack.pop();
    let entries; try { entries = fs.readdirSync(d); } catch { continue; }
    for (const name of entries) {
      let st; try { st = fs.lstatSync(path.join(d, name)); } catch { continue; }
      if (st.isSymbolicLink()) continue;
      if (st.isDirectory()) stack.push(path.join(d, name)); else total += st.size;
    }
  }
  return total;
}

/** Docker log buffers (non-TTY) are framed: [stream,0,0,0,size(4 bytes BE)] + payload. */
function demuxBuffer(buf) {
  if (!Buffer.isBuffer(buf)) return String(buf);
  if (buf.length < 8 || buf[0] > 2 || buf[1] !== 0 || buf[2] !== 0 || buf[3] !== 0) return buf.toString('utf8');
  let out = '';
  let i = 0;
  while (i + 8 <= buf.length) {
    const size = buf.readUInt32BE(i + 4);
    out += buf.slice(i + 8, i + 8 + size).toString('utf8');
    i += 8 + size;
  }
  return out;
}

const cleanLine = (s) => s.replace(/[\x00-\x08\x0b\x0c\x0e-\x1f]/g, '').trimEnd();

function createAgent({ config, docker, log = console.log }) {
  const serversRoot = path.join(config.dataDir, 'servers');
  const followers   = new Map(); // serverId -> stream
  let socket = null;

  const serverDir = (id) => path.join(serversRoot, id);

  async function ensureImage(image) {
    try { await docker.getImage(image).inspect(); return; } catch {}
    log(`[agent] Pulling ${image} …`);
    await new Promise((res, rej) => {
      docker.pull(image, (err, stream) => {
        if (err) return rej(err);
        docker.modem.followProgress(stream, (e) => (e ? rej(e) : res()));
      });
    });
  }

  async function removeContainer(name) {
    try { await docker.getContainer(name).remove({ force: true }); }
    catch (e) { if (e.statusCode !== 404) throw e; }
  }

  const extraOrigins = (config.allowedDownloadOrigins || []).map((o) => new URL(o).origin);
  const allowedUrl = (u) => (u.protocol === 'https:' && ALLOWED_HOSTS.has(u.hostname)) || extraOrigins.includes(u.origin);

  async function downloadJar(url, dest) {
    let res, cur = url;
    for (let hop = 0; hop < 4; hop++) {
      const u = new URL(cur);
      if (!allowedUrl(u)) throw new Error('Download blocked: host is not allowed');
      res = await fetch(u, { redirect: 'manual', headers: { 'User-Agent': `PHBAI-Agent/${VERSION}` }, signal: AbortSignal.timeout(120000) });
      if ([301, 302, 303, 307, 308].includes(res.status) && res.headers.get('location')) { cur = new URL(res.headers.get('location'), u).toString(); continue; }
      break;
    }
    if (!res.ok) throw new Error(`Download failed (HTTP ${res.status})`);
    const tmp = dest + '.part';
    let size = 0;
    const limit = new Transform({ transform(chunk, _e, cb) { size += chunk.length; cb(size > MAX_DOWNLOAD ? new Error('File is too large') : null, chunk); } });
    try {
      await pipeline(Readable.fromWeb(res.body), limit, fs.createWriteStream(tmp));
      const fd = fs.openSync(tmp, 'r'); const head = Buffer.alloc(4); fs.readSync(fd, head, 0, 4, 0); fs.closeSync(fd);
      if (head.toString('hex') !== '504b0304') throw new Error('The download is not a valid .jar (the site may have blocked it).');
      fs.renameSync(tmp, dest);
    } catch (e) { fs.rmSync(tmp, { force: true }); throw e; }
  }

  /* ─────────── RPC methods ─────────── */
  const methods = Object.create(null);

  methods.ping = async () => ({ ok: true });

  methods['server.start'] = async ({ srv }) => {
    const s = cleanSrv(srv, true);
    const dataDir = serverDir(s.id);
    fs.mkdirSync(dataDir, { recursive: true });

    const used = dirSize(dataDir);
    if (used > s.disk * GB) throw new Error(`Disk limit reached (${(used / GB).toFixed(1)} of ${s.disk} GB used). Delete some files first.`);

    const image = imageFor(s.version);
    await ensureImage(image);
    await removeContainer(s.containerName); // leftover from a crash

    const container = await docker.createContainer({
      name:  s.containerName,
      Image: image,
      Env:   buildEnv(s),
      ExposedPorts: { '25565/tcp': {} },
      HostConfig: {
        Memory:    s.ram * GB,
        CpuPeriod: 100000,
        CpuQuota:  s.cpu * 1000,
        Binds:     [`${dataDir}:/data`],
        PortBindings: { '25565/tcp': [{ HostPort: String(s.port) }] },
        RestartPolicy: { Name: 'unless-stopped' },
      },
    });
    await container.start();
    return { containerId: container.id };
  };

  methods['server.stop'] = async ({ srv }) => {
    const s = cleanSrv(srv);
    const c = docker.getContainer(s.containerName);
    try { await c.stop({ t: 10 }); }
    catch (e) { if (![304, 404].includes(e.statusCode)) throw e; }
    await removeContainer(s.containerName);
    detach(s.id);
    return { ok: true };
  };

  methods['server.destroy'] = async ({ srv }) => {
    const s = cleanSrv(srv);
    await removeContainer(s.containerName);
    detach(s.id);
    fs.rmSync(serverDir(s.id), { recursive: true, force: true });
    return { ok: true };
  };

  methods['server.restart'] = async ({ srv }) => {
    const s = cleanSrv(srv);
    await docker.getContainer(s.containerName).restart();
    return { ok: true };
  };

  methods['server.stats'] = async ({ srv }) => {
    const s = cleanSrv(srv);
    try {
      const st = await docker.getContainer(s.containerName).stats({ stream: false });
      const cpuDelta = st.cpu_stats.cpu_usage.total_usage - st.precpu_stats.cpu_usage.total_usage;
      const sysDelta = st.cpu_stats.system_cpu_usage      - st.precpu_stats.system_cpu_usage;
      const cpu = sysDelta > 0 ? (cpuDelta / sysDelta) * (st.cpu_stats.online_cpus || 1) * 100 : 0;
      const ram = (st.memory_stats.usage || 0) / 1024 / 1024;
      return { cpu: cpu.toFixed(1), ram: ram.toFixed(0) };
    } catch { return null; }
  };

  methods['server.exec'] = async ({ srv, cmd }) => {
    const s = cleanSrv(srv);
    if (typeof cmd !== 'string' || !cmd.trim() || cmd.length > 500) throw new Error('Invalid command');
    const exec = await docker.getContainer(s.containerName).exec({
      Cmd: ['rcon-cli', cmd], AttachStdout: true, AttachStderr: true, Tty: true,
    });
    const stream = await exec.start({ hijack: true, stdin: false, Tty: true });
    return new Promise((resolve) => {
      let out = '';
      const done = () => resolve(out.trim());
      const timer = setTimeout(() => { try { stream.destroy(); } catch {} done(); }, 15000);
      stream.on('data', (d) => { out += d.toString(); });
      stream.on('end',  () => { clearTimeout(timer); done(); });
      stream.on('error', () => { clearTimeout(timer); done(); });
    });
  };

  methods['server.logs'] = async ({ srv, tail }) => {
    const s = cleanSrv(srv);
    const n = Math.min(Math.max(Number.parseInt(tail, 10) || 100, 1), 1000);
    try {
      const buf = await docker.getContainer(s.containerName).logs({ stdout: true, stderr: true, tail: n });
      return demuxBuffer(buf).split('\n').map(cleanLine).filter(Boolean);
    } catch { return []; }
  };

  /* Live console: push every new log line to the panel */
  function detach(serverId) {
    const f = followers.get(serverId);
    if (f) { try { f.destroy(); } catch {} followers.delete(serverId); }
  }

  methods['logs.attach'] = async ({ srv }) => {
    const s = cleanSrv(srv);
    if (followers.has(s.id)) return { ok: true, already: true };
    const raw = await docker.getContainer(s.containerName).logs({
      follow: true, stdout: true, stderr: true, since: Math.floor(Date.now() / 1000) - 5,
    });
    const out = new PassThrough();
    docker.modem.demuxStream(raw, out, out);

    let pending = '';
    out.on('data', (chunk) => {
      pending += chunk.toString('utf8');
      const lines = pending.split('\n');
      pending = lines.pop();
      for (const l of lines) {
        const line = cleanLine(l);
        if (line && socket) socket.emit('log-line', { serverId: s.id, line });
      }
    });
    const stop = () => { if (followers.get(s.id) === raw) followers.delete(s.id); };
    raw.on('end', stop); raw.on('close', stop); raw.on('error', stop);
    followers.set(s.id, raw);
    return { ok: true };
  };

  methods['logs.detach'] = async ({ srv }) => {
    detach(cleanSrv(srv).id);
    return { ok: true };
  };

  /* Files (confined to the server's own data directory) */
  methods['files.list'] = async ({ serverId, path: rel }) => {
    const s = cleanSrv({ id: serverId });
    const dir = safeJoin(serverDir(s.id), rel);
    if (!fs.existsSync(dir) || !fs.statSync(dir).isDirectory()) return [];
    return fs.readdirSync(dir).map((name) => {
      const st = fs.statSync(path.join(dir, name));
      return { name, isDir: st.isDirectory(), size: st.size, mtime: st.mtime };
    });
  };

  methods['files.read'] = async ({ serverId, path: rel }) => {
    const s = cleanSrv({ id: serverId });
    const p = safeJoin(serverDir(s.id), rel);
    if (!fs.existsSync(p) || !fs.statSync(p).isFile()) throw new Error('File not found');
    if (fs.statSync(p).size > MAX_FILE) throw new Error('File is too large to edit (max 2 MB)');
    const buf = fs.readFileSync(p);
    if (buf.includes(0)) throw new Error('This looks like a binary file and cannot be edited as text');
    return buf.toString('utf8');
  };

  methods['files.mkdir'] = async ({ serverId, path: rel }) => {
    const s = cleanSrv({ id: serverId });
    if (typeof rel !== 'string' || !rel) throw new Error('Path required');
    fs.mkdirSync(safeJoin(serverDir(s.id), rel), { recursive: true });
    return { ok: true };
  };

  methods['files.delete'] = async ({ serverId, path: rel }) => {
    const s = cleanSrv({ id: serverId });
    if (typeof rel !== 'string' || !rel.replace(/^[/\\]+/, '')) throw new Error('Refusing to delete the server root');
    const p = safeJoin(serverDir(s.id), rel);
    if (!fs.existsSync(p)) throw new Error('Not found');
    fs.rmSync(p, { recursive: true, force: true });
    return { ok: true };
  };

  methods['files.download'] = async ({ serverId, dir, filename, url }) => {
    const s = cleanSrv({ id: serverId });
    if (!['plugins', 'mods'].includes(dir)) throw new Error('Invalid folder');
    if (!/^[\w .+()\-]{1,100}\.jar$/.test(filename || '')) throw new Error('Invalid file name');
    const target = safeJoin(serverDir(s.id), `${dir}/${filename}`);
    fs.mkdirSync(path.dirname(target), { recursive: true });
    await downloadJar(url, target);
    return { ok: true, file: filename };
  };

  /* Upload from the user's computer, sent by the panel in pieces. The partial file lives in <name>.upload-part until the last piece. */
  const usage = new Map();   // serverId -> { size, at }
  const usedBytes = (id) => {
    const c = usage.get(id);
    if (c && Date.now() - c.at < 10000) return c.size;
    const size = dirSize(serverDir(id));
    usage.set(id, { size, at: Date.now() });
    return size;
  };

  methods['files.upload'] = async ({ serverId, path: rel, offset, data, last, total, limitBytes }) => {
    const s = cleanSrv({ id: serverId });
    if (typeof rel !== 'string' || !rel) throw new Error('Path required');
    const parts = rel.replace(/^[/\\]+/, '').split('/');
    if (parts.some((p) => !p || p === '.' || p === '..' || p.length > 255 || /[\x00-\x1f\\]/.test(p))) throw new Error('Invalid file or folder name in the upload');
    const chunk = Buffer.isBuffer(data) ? data : Buffer.from(data || []);
    offset = Number(offset) || 0;
    const limit = Number.isFinite(Number(limitBytes)) ? Math.min(Number(limitBytes), 1000 * GB) : 10 * GB;

    const target = safeJoin(serverDir(s.id), rel);
    const tmp = target + '.upload-part';
    if (offset === 0) {
      fs.mkdirSync(path.dirname(target), { recursive: true });
      if (fs.existsSync(target) && fs.statSync(target).isDirectory()) throw new Error('A folder with this name already exists');
      const used = usedBytes(s.id);
      if (used + Math.max(Number(total) || 0, chunk.length) > limit) throw new Error(`Disk limit reached (${(used / GB).toFixed(1)} of ${(limit / GB).toFixed(0)} GB used). Delete some files first.`);
      fs.writeFileSync(tmp, '');
    } else if (!fs.existsSync(tmp) || fs.statSync(tmp).size !== offset) {
      fs.rmSync(tmp, { force: true });
      throw new Error('Upload pieces arrived out of order');
    }
    if (offset + chunk.length > MAX_UPLOAD) { fs.rmSync(tmp, { force: true }); throw new Error(`File is too large (max ${Math.round(MAX_UPLOAD / 1024 / 1024)} MB per file)`); }
    if (usedBytes(s.id) + offset + chunk.length > limit) { fs.rmSync(tmp, { force: true }); throw new Error('Disk limit reached. Delete some files first.'); }
    fs.appendFileSync(tmp, chunk);
    if (last) {
      fs.renameSync(tmp, target);
      const c = usage.get(s.id); if (c) c.size += offset + chunk.length;
    }
    return { ok: true };
  };

  methods['files.uploadAbort'] = async ({ serverId, path: rel }) => {
    const s = cleanSrv({ id: serverId });
    if (typeof rel !== 'string' || !rel) return { ok: true };
    try { fs.rmSync(safeJoin(serverDir(s.id), rel) + '.upload-part', { force: true }); } catch {}
    return { ok: true };
  };

  methods['files.write'] = async ({ serverId, path: rel, content }) => {
    const s = cleanSrv({ id: serverId });
    if (typeof rel !== 'string' || !rel) throw new Error('Path required');
    const text = typeof content === 'string' ? content : '';
    if (Buffer.byteLength(text) > MAX_FILE) throw new Error('Content is too large (max 2 MB)');
    const p = safeJoin(serverDir(s.id), rel);
    fs.mkdirSync(path.dirname(p), { recursive: true });
    fs.writeFileSync(p, text);
    return { ok: true };
  };

  /* ─────────── Connection to the panel ─────────── */
  async function hello() {
    const info = {
      name: config.name, hostname: os.hostname(), platform: `${os.platform()} ${os.arch()}`,
      agentVersion: VERSION, docker: null, dockerError: null,
    };
    try { info.docker = (await docker.version()).Version || 'unknown'; }
    catch (e) { info.dockerError = e.message; }
    return info;
  }

  function connect() {
    socket = io(config.panelUrl.replace(/\/+$/, '') + '/agent', {
      auth: { token: config.agentKey, name: config.name, hostname: os.hostname(), platform: `${os.platform()} ${os.arch()}`, agentVersion: VERSION },
      reconnection: true,
      reconnectionDelay: 2000,
      reconnectionDelayMax: 30000,
    });

    socket.on('connect', async () => {
      log(`[agent] Connected to ${config.panelUrl} as "${config.name}"`);
      const info = await hello();
      if (info.dockerError) log(`[agent] WARNING: Docker is not reachable: ${info.dockerError}`);
      else log(`[agent] Docker ${info.docker} OK`);
      socket.emit('hello', info);
    });

    socket.on('connect_error', (err) => {
      if (err.message === 'invalid token') log('[agent] The panel rejected the token. Generate a new one on the Nodes page and run configure again.');
      else log(`[agent] Cannot reach panel: ${err.message} (retrying…)`);
    });

    socket.on('disconnect', (reason) => {
      log(`[agent] Disconnected (${reason})`);
      for (const id of [...followers.keys()]) detach(id);
    });

    socket.on('rpc', async (msg, ack) => {
      if (typeof ack !== 'function') return;
      const fn = msg && typeof msg.method === 'string' ? methods[msg.method] : null;
      if (!fn) return ack({ error: `Unknown method: ${msg && msg.method}` });
      try { ack({ result: await fn(msg.params || {}) }); }
      catch (e) { log(`[agent] ${msg.method} failed: ${e.message}`); ack({ error: e.message }); }
    });

    return socket;
  }

  function stop() {
    for (const id of [...followers.keys()]) detach(id);
    if (socket) socket.close();
  }

  return { connect, stop, methods };
}

module.exports = { createAgent, cleanSrv, demuxBuffer, javaTag, buildEnv, dirSize };
