#!/usr/bin/env node
const Dockerode = require('dockerode');
const { load } = require('./config');
const { createAgent } = require('./agent');

let config;
try { config = load(); }
catch (e) { console.error(`\n  ${e.message}\n`); process.exit(1); }

console.log(`\n  PHBAI node agent`);
console.log(`  Panel    : ${config.panelUrl}`);
console.log(`  Data dir : ${config.dataDir}`);
console.log(`  Docker   : ${config.dockerSocket}\n`);

const docker = new Dockerode({ socketPath: config.dockerSocket });
const agent  = createAgent({ config, docker });
agent.connect();

const quit = () => { agent.stop(); process.exit(0); };
process.on('SIGINT', quit);
process.on('SIGTERM', quit);
