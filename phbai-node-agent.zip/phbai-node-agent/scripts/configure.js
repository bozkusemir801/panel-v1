#!/usr/bin/env node
/**
 * PHBAI Node Agent configurator
 * Usage: npm run configure -- --panel https://panel.example.com --key YOUR_TOKEN [--name my-node] [--data-dir /srv/phpanel] [--docker-socket /var/run/docker.sock]
 */
const fs   = require('fs');
const path = require('path');
const args = process.argv.slice(2);

const getArg = (name) => {
  const i = args.indexOf('--' + name);
  return i !== -1 && args[i + 1] && !args[i + 1].startsWith('--') ? args[i + 1] : null;
};

const panel = getArg('panel');
const key   = getArg('key');

if (!panel || !key) {
  console.error('\n  Usage: npm run configure -- --panel <URL> --key <TOKEN> [--name <node name>] [--data-dir <path>]\n');
  console.error('  Example:');
  console.error('    npm run configure -- --panel http://1.2.3.4:5001 --key fe670ba8-18ac-4fd5-9600-000f82264915 --name node-1\n');
  process.exit(1);
}
if (!/^https?:\/\//i.test(panel)) {
  console.error('\n  --panel must start with http:// or https://\n');
  process.exit(1);
}

const cfgDir  = path.join(__dirname, '..', 'config');
const cfgFile = path.join(cfgDir, 'agent.json');
fs.mkdirSync(cfgDir, { recursive: true });

let existing = {};
if (fs.existsSync(cfgFile)) {
  try { existing = JSON.parse(fs.readFileSync(cfgFile, 'utf8')); } catch {}
}

const cfg = {
  ...existing,
  panelUrl:     panel.replace(/\/+$/, ''),
  agentKey:     key,
  name:         getArg('name')          || existing.name         || require('os').hostname(),
  dataDir:      path.resolve(getArg('data-dir') || existing.dataDir || path.join(__dirname, '..', 'data')),
  dockerSocket: getArg('docker-socket') || existing.dockerSocket || '/var/run/docker.sock',
  configuredAt: new Date().toISOString(),
};

fs.writeFileSync(cfgFile, JSON.stringify(cfg, null, 2), { mode: 0o600 });

console.log('\n  PHBAI node agent configured!');
console.log(`  Panel   : ${cfg.panelUrl}`);
console.log(`  Name    : ${cfg.name}`);
console.log(`  Data dir: ${cfg.dataDir}`);
console.log(`  Config  : ${cfgFile}`);
console.log('\n  Start it with:  npm start\n');
